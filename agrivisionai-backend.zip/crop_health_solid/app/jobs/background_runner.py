"""
BackgroundJobRunner: runs jobs on a background thread for the HTTP API.

The API wants to answer "202 accepted" immediately and let the analysis run in
the background, while limiting how many analyses can be waiting at once. That
queue/limit/thread logic used to live inside the router file; it now lives
here, so the router only has to deal with HTTP.
"""
from __future__ import annotations

import gc
import threading
import uuid
from concurrent.futures import Future, ThreadPoolExecutor

from app.domain.exceptions import TooManyJobsError
from app.domain.interfaces import JobRunRepository
from app.domain.models import CropHealthJobRequest, CropHealthJobResult, JobStatus
from app.jobs.crop_health_job import CropHealthJob
from app.logging_config import get_logger

log = get_logger(__name__)


class BackgroundJobRunner:
    def __init__(
        self,
        job: CropHealthJob,
        job_runs: JobRunRepository,
        max_pending: int = 3,
        max_workers: int = 1,
    ) -> None:
        self._job = job
        self._job_runs = job_runs
        self._max_pending = max_pending
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="crop-health")
        self._lock = threading.Lock()
        self._pending = 0
        self._active: set[uuid.UUID] = set()  # queued or running, until the FINAL result is saved

    def is_active(self, job_id: uuid.UUID) -> bool:
        with self._lock:
            return job_id in self._active

    def submit(self, request: CropHealthJobRequest) -> Future:
        """Record the run and start it in the background.
        Raises TooManyJobsError when the server is already busy."""
        with self._lock:
            if self._pending >= self._max_pending:
                raise TooManyJobsError(
                    "The server is busy with other analyses. Please try again in a minute."
                )
            self._pending += 1
            self._active.add(request.job_id)
        try:
            self._job_runs.create_job_run(
                job_id=request.job_id,
                field_id=request.field_id,
                trigger_source=request.trigger_source.value,
                period_start=request.date_range.start,
                period_end=request.date_range.end,
            )
            return self._executor.submit(self._execute, request)
        except Exception:
            self._release(request.job_id)
            raise

    def _execute(self, request: CropHealthJobRequest) -> CropHealthJobResult:
        try:
            return self._job.run(request)
        except Exception as exc:
            log.error("job.unexpected_failure", job_id=str(request.job_id), error=repr(exc))
            self._job_runs.complete_job_run(
                job_id=request.job_id,
                status=JobStatus.FAILED,
                result_json=None,
                error="The analysis failed unexpectedly. Please try again.",
            )
            raise
        finally:
            self._release(request.job_id)
            gc.collect()

    def _release(self, job_id: uuid.UUID) -> None:
        with self._lock:
            self._pending -= 1
            self._active.discard(job_id)
