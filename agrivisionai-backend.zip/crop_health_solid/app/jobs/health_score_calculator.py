"""
HealthScoreCalculator: satellite imagery -> NDVI -> 0-100 health score.

Each step of the pipeline is its own small method, so you can read the
`calculate()` method top to bottom like a recipe:

    find scenes -> drop cloudy ones -> get cropland mask -> score each scene
    -> combine into one composite -> build photos -> assemble the result

Everything it needs (imagery, mask, raster maths, photos) is handed in through
the constructor as an *interface*, so this class never imports rasterio, Planet
Insights or any other concrete tool.

Raises ImageryFetchError / ScoringError (both CropHealthError) on failure;
deciding what to do about a failure is the caller's job, not this class's.
"""
from __future__ import annotations

import gc
import time
from concurrent.futures import ThreadPoolExecutor

from app.domain.exceptions import ImageryFetchError, ScoringError
from app.domain.interfaces import (
    CroplandMaskProvider,
    ImageryProvider,
    SceneAnalyzer,
    ScenePreviewBuilder,
)
from app.domain.models import (
    DateRange,
    FieldBoundary,
    HealthScoreResult,
    SatelliteImage,
    SceneRef,
    ScenePreview,
)
from app.domain.scoring import (
    DEFAULT_CLOUD_COVER_THRESHOLD_PCT,
    composite_ndvi,
    filter_scenes_by_cloud_cover,
    ndvi_to_health_score,
)
from app.logging_config import get_logger

log = get_logger(__name__)

# Sentinel-2 L2A band names for red and near-infrared.
SENTINEL_SOURCE = "sentinel-2"
RED_BAND = "B04"
NIR_BAND = "B08"


class HealthScoreCalculator:
    def __init__(
        self,
        imagery: ImageryProvider,
        cropland_mask: CroplandMaskProvider,
        scene_analyzer: SceneAnalyzer,
        preview_builder: ScenePreviewBuilder,
        cloud_cover_threshold_pct: float = DEFAULT_CLOUD_COVER_THRESHOLD_PCT,
        max_workers: int = 2,
        max_previews: int = 2,
    ) -> None:
        # max_workers: scenes handled at the same time. Keep it small, each
        # running scene holds its downloaded bands in memory and Planet Insights
        # rate-limits requests per account.
        self._imagery = imagery
        self._cropland_mask = cropland_mask
        self._analyzer = scene_analyzer
        self._preview_builder = preview_builder
        self._cloud_threshold = cloud_cover_threshold_pct or DEFAULT_CLOUD_COVER_THRESHOLD_PCT
        self._max_workers = max_workers
        self._max_previews = max_previews

    # ------------------------------------------------------------------ #
    # The recipe
    # ------------------------------------------------------------------ #

    def calculate(self, field: FieldBoundary, date_range: DateRange) -> HealthScoreResult:
        scenes = self._find_scenes(field, date_range)
        clear_scenes = self._drop_cloudy_scenes(scenes)

        # Same field for every scene, so download the mask only once.
        mask_bytes = self._cropland_mask.get_mask(field.geojson_polygon)

        scored = self._score_scenes(clear_scenes, field, mask_bytes)
        used_scenes = [scene for scene, _ in scored]
        ndvi_means = [mean for _, mean in scored]

        ndvi_mean, ndvi_min, ndvi_max = composite_ndvi(ndvi_means)
        previews = self._build_previews(used_scenes, field)

        return self._assemble_result(
            field, date_range, used_scenes, previews, (ndvi_mean, ndvi_min, ndvi_max)
        )

    # ------------------------------------------------------------------ #
    # Steps
    # ------------------------------------------------------------------ #

    def _find_scenes(self, field: FieldBoundary, date_range: DateRange) -> list[SceneRef]:
        scenes = self._imagery.search(field.geojson_polygon, date_range)
        if not scenes:
            raise ImageryFetchError(
                f"No scenes found for field {field.field_id} in "
                f"{date_range.start}..{date_range.end}",
                field_id=field.field_id,
            )
        return scenes

    def _drop_cloudy_scenes(self, scenes: list[SceneRef]) -> list[SceneRef]:
        # A scene with unknown cloud cover is treated as fully cloudy (100%).
        # (`is None` matters: a clear 0% scene must NOT be treated as 100%.)
        cloud_by_scene = [
            (s.scene_id, 100.0 if s.cloud_cover_pct is None else s.cloud_cover_pct)
            for s in scenes
        ]
        surviving_ids = set(filter_scenes_by_cloud_cover(cloud_by_scene, self._cloud_threshold))
        return [s for s in scenes if s.scene_id in surviving_ids]

    def _score_scenes(
        self, scenes: list[SceneRef], field: FieldBoundary, mask_bytes: bytes
    ) -> list[tuple[SceneRef, float]]:
        """Mean NDVI per scene. Scenes with no usable pixels are skipped."""
        started = time.monotonic()

        def score_one(scene: SceneRef) -> tuple[SceneRef, float | None]:
            bands = self._imagery.fetch_bands(scene, [RED_BAND, NIR_BAND])
            mean = self._analyzer.mean_ndvi(
                bands[RED_BAND], bands[NIR_BAND], field.geojson_polygon, mask_bytes
            )
            return scene, mean

        with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
            results = list(pool.map(score_one, scenes))

        scored = [(scene, mean) for scene, mean in results if mean is not None]
        if not scored:
            raise ScoringError("None of the satellite scenes had usable pixels for this field")

        log.info(
            "pipeline.scenes_done",
            scenes=len(scored),
            seconds=round(time.monotonic() - started, 1),
        )
        gc.collect()  # release the big raster arrays before building photos
        return scored

    def _build_previews(
        self, scenes: list[SceneRef], field: FieldBoundary
    ) -> list[tuple[SceneRef, ScenePreview]]:
        """True-colour photos of the newest scenes. Never fails the score."""
        started = time.monotonic()
        newest = sorted(scenes, key=lambda s: s.sensed_at, reverse=True)[: self._max_previews]

        def photo(scene: SceneRef) -> tuple[SceneRef, ScenePreview | None]:
            try:
                return scene, self._preview_builder.build(scene, field.geojson_polygon)
            except Exception:  # noqa: BLE001 - a missing photo must never fail the score
                return scene, None

        with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
            results = list(pool.map(photo, newest))

        previews = [(scene, preview) for scene, preview in results if preview is not None]
        if any(p.source != SENTINEL_SOURCE for _, p in previews):
            # A basemap photo is the same picture whichever scene we asked
            # for, so keep just one instead of showing duplicates.
            previews = previews[:1]
        gc.collect()
        log.info(
            "pipeline.photos_done",
            photos=len(previews),
            seconds=round(time.monotonic() - started, 1),
        )
        return previews

    def _assemble_result(
        self,
        field: FieldBoundary,
        date_range: DateRange,
        used_scenes: list[SceneRef],
        previews: list[tuple[SceneRef, ScenePreview]],
        ndvi_stats: tuple[float, float, float],
    ) -> HealthScoreResult:
        ndvi_mean, ndvi_min, ndvi_max = ndvi_stats
        avg_cloud_cover = sum(s.cloud_cover_pct or 0 for s in used_scenes) / len(used_scenes)

        # The older single-image fields describe the clearest picture.
        best = self._clearest_preview(previews)

        return HealthScoreResult(
            field_id=field.field_id,
            period_start=date_range.start,
            period_end=date_range.end,
            ndvi_mean=ndvi_mean,
            ndvi_min=ndvi_min,
            ndvi_max=ndvi_max,
            health_score=ndvi_to_health_score(ndvi_mean),
            cloud_cover_pct=round(avg_cloud_cover, 2),
            scenes_used=[s.scene_id for s in used_scenes],
            cropland_mask_source=self._cropland_mask.source_name,
            # Map-tile output is not implemented yet (see README).
            ndvi_tile_url=None,
            health_score_tile_url=None,
            satellite_images=[
                SatelliteImage(
                    data_url=preview.data_url,
                    bounds=preview.bounds,
                    # Only a Sentinel photo really comes from this scene.
                    scene_date=scene.sensed_at.date() if preview.source == SENTINEL_SOURCE else None,
                    cloud_cover_pct=scene.cloud_cover_pct if preview.source == SENTINEL_SOURCE else None,
                    scene_id=scene.scene_id if preview.source == SENTINEL_SOURCE else None,
                    source=preview.source,
                )
                for scene, preview in previews
            ],
            satellite_image_data_url=best[1].data_url if best else None,
            satellite_image_bounds=best[1].bounds if best else None,
            satellite_image_scene_date=(
                best[0].sensed_at.date() if best and best[1].source == SENTINEL_SOURCE else None
            ),
            satellite_image_cloud_cover_pct=(
                best[0].cloud_cover_pct if best and best[1].source == SENTINEL_SOURCE else None
            ),
        )

    @staticmethod
    def _clearest_preview(
        previews: list[tuple[SceneRef, ScenePreview]],
    ) -> tuple[SceneRef, ScenePreview] | None:
        if not previews:
            return None
        return min(
            previews,
            key=lambda pair: pair[0].cloud_cover_pct if pair[0].cloud_cover_pct is not None else 100.0,
        )
