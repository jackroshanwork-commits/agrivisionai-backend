"""
FarmerNotifier: finds the farmer's phone and sends them the push notification.

A notification problem must never turn a successful job into a failed one, so
every failure here is logged and returned as a result object, not raised.
"""
from __future__ import annotations

from app.domain.exceptions import NotificationDeliveryError
from app.domain.interfaces import DeviceTokenRepository, NotificationProvider
from app.domain.models import (
    FieldBoundary,
    NotificationSendResult,
    PushNotificationPayload,
    ReasoningResult,
)
from app.logging_config import get_logger

log = get_logger(__name__)


def build_push_payload(field: FieldBoundary, reasoning: ReasoningResult) -> PushNotificationPayload:
    """Pure function: what the notification says. Easy to unit test."""
    return PushNotificationPayload(
        farmer_id=field.farmer_id,
        field_id=field.field_id,
        title=f"{field.name}: crop health {reasoning.risk_level.value}",
        body=reasoning.message_farmer_language,
        risk_level=reasoning.risk_level,
        # Opens the field's crop-health screen when the farmer taps it.
        deep_link=f"agrivisionai://field/{field.field_id}/crop-health",
        data={
            "likely_cause": reasoning.likely_cause,
            "generated_by": reasoning.generated_by,
        },
    )


class FarmerNotifier:
    def __init__(self, device_tokens: DeviceTokenRepository, provider: NotificationProvider) -> None:
        self._device_tokens = device_tokens
        self._provider = provider

    def notify(self, field: FieldBoundary, reasoning: ReasoningResult) -> NotificationSendResult | None:
        """Returns None when there is nobody to notify (no device registered)."""
        device_token = self._device_tokens.get_active_device_token(field.farmer_id)
        if not device_token:
            # Normal state: the farmer hasn't opened the app / allowed notifications yet.
            log.info("notification.skipped_no_device_token", field_id=str(field.field_id))
            return None

        payload = build_push_payload(field, reasoning)
        try:
            result = self._provider.send_push(device_token, payload)
        except NotificationDeliveryError as exc:
            log.error("notification.send_failed", **exc.to_log_context())
            return NotificationSendResult(
                farmer_id=field.farmer_id,
                field_id=field.field_id,
                delivered=False,
                error=exc.message,
            )

        if result.stale_token:
            # App uninstalled / token rotated: stop using it next time.
            self._device_tokens.deregister_device_token(field.farmer_id, device_token)
            log.info("notification.stale_token_deregistered", farmer_id=str(field.farmer_id))

        log.info(
            "notification.dispatched",
            field_id=str(field.field_id),
            delivered=result.delivered,
            risk_level=reasoning.risk_level.value,
        )
        return result
