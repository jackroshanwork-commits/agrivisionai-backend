"""
ReasoningContextGatherer: collects the extra facts (weather, soil, previous
score) the reasoning step wants, and packs them into a `ReasoningInput`.

Weather and soil are OPTIONAL. If one of them fails we log it and carry on
with `None`, because a farmer should still get an advisory even if NASA POWER
is having a bad day.
"""
from __future__ import annotations

from typing import Callable, TypeVar

from app.domain.exceptions import CropHealthError
from app.domain.interfaces import (
    SoilHealthProvider,
    WeatherForecastProvider,
    WeatherHistoryProvider,
)
from app.domain.models import DateRange, FieldBoundary, HealthScoreResult, ReasoningInput
from app.logging_config import get_logger

log = get_logger(__name__)

T = TypeVar("T")


class ReasoningContextGatherer:
    def __init__(
        self,
        weather_history: WeatherHistoryProvider,
        weather_forecast: WeatherForecastProvider,
        soil_health: SoilHealthProvider,
    ) -> None:
        self._weather_history = weather_history
        self._weather_forecast = weather_forecast
        self._soil_health = soil_health

    def build_input(
        self,
        field: FieldBoundary,
        health_score: HealthScoreResult,
        previous_score: HealthScoreResult | None,
        date_range: DateRange,
    ) -> ReasoningInput:
        return ReasoningInput(
            field_id=field.field_id,
            health_score=health_score,
            previous_health_score=previous_score,
            weather_history=self._optional(
                "weather_history",
                field,
                lambda: self._weather_history.get_history(field, date_range),
            ),
            weather_forecast=self._optional(
                "weather_forecast",
                field,
                lambda: self._weather_forecast.get_forecast(field),
            ),
            soil_health=self._optional(
                "soil_health",
                field,
                lambda: self._soil_health.get_latest(field.field_id),
            ),
        )

    @staticmethod
    def _optional(name: str, field: FieldBoundary, fetch: Callable[[], T]) -> T | None:
        """Run `fetch`; on a known failure log it and return None."""
        try:
            return fetch()
        except CropHealthError as exc:
            log.error(f"{name}_failed", field_id=str(field.field_id), error=exc.message)
            return None
