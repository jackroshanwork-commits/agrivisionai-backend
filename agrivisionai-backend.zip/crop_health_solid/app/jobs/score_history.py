"""Looks up a field's last successful health score."""
from __future__ import annotations

import uuid

from app.domain.interfaces import JobRunRepository
from app.domain.models import HealthScoreResult


class ScoreHistory:
    """Small wrapper so the rest of the code asks for a `HealthScoreResult`
    instead of digging through the raw JSON a job run stored."""

    def __init__(self, job_runs: JobRunRepository) -> None:
        self._job_runs = job_runs

    def last_score(self, field_id: uuid.UUID) -> HealthScoreResult | None:
        last_result = self._job_runs.get_last_successful_result(field_id)
        if last_result and last_result.get("health_score"):
            return HealthScoreResult(**last_result["health_score"])
        return None
