"""
CropHealthJob: the one "what does a job run do?" use case.

Read `run()` top to bottom, it is the whole story:

    1. load the field
    2. remember the previous score (so we can compare against it later)
    3. calculate the new health score        <- if this fails, serve the old score
    4. save the new score right away         <- later steps can't lose it
    5. ask the reasoning engine for advice   <- best effort
    6. notify the farmer if needed           <- best effort
    7. save and return the final result

This class does NOT know how imagery is downloaded, which LLM is used, or how
push notifications are sent. It only talks to small interfaces that are handed
in through `__init__` (Dependency Inversion). Tests give it simple fakes.

Both the HTTP API and the Lambda worker call the same `run()`, so there is
exactly one implementation of "what a job run does".
"""
from __future__ import annotations

from datetime import datetime, timezone

from app.domain.exceptions import CropHealthError
from app.domain.interfaces import FieldRepository, JobRunRepository, ReasoningProvider
from app.domain.models import (
    CropHealthJobRequest,
    CropHealthJobResult,
    FieldBoundary,
    HealthScoreResult,
    JobStatus,
    NotificationSendResult,
    ReasoningResult,
)
from app.jobs.farmer_notifier import FarmerNotifier
from app.jobs.health_score_calculator import HealthScoreCalculator
from app.jobs.reasoning_context import ReasoningContextGatherer
from app.jobs.score_history import ScoreHistory
from app.logging_config import get_logger

log = get_logger(__name__)


def _now() -> datetime:
    return datetime.now(timezone.utc)


class CropHealthJob:
    def __init__(
        self,
        fields: FieldRepository,
        job_runs: JobRunRepository,
        score_history: ScoreHistory,
        calculator: HealthScoreCalculator,
        context_gatherer: ReasoningContextGatherer,
        reasoner: ReasoningProvider,
        notifier: FarmerNotifier,
    ) -> None:
        self._fields = fields
        self._job_runs = job_runs
        self._score_history = score_history
        self._calculator = calculator
        self._context = context_gatherer
        self._reasoner = reasoner
        self._notifier = notifier

    # ------------------------------------------------------------------ #
    # The story
    # ------------------------------------------------------------------ #

    def run(self, request: CropHealthJobRequest) -> CropHealthJobResult:
        started_at = _now()
        log.info(
            "job.started",
            job_id=str(request.job_id),
            field_id=str(request.field_id),
            trigger_source=request.trigger_source,
        )

        # 1. Load the field.
        try:
            field = self._fields.get_field(request.field_id)
        except CropHealthError as exc:
            log.error("job.field_load_failed", **exc.to_log_context())
            return self._finish(self._failure(request, started_at, exc.message))

        # 2. Read the previous score BEFORE saving a new one,
        #    otherwise we would end up comparing the new score with itself.
        previous_score = self._score_history.last_score(field.field_id)

        # 3. Calculate the new health score.
        try:
            health_score = self._calculator.calculate(field, request.date_range)
        except CropHealthError as exc:
            log.error("job.health_score_failed", **exc.to_log_context())
            return self._finish(self._failure(request, started_at, exc.message, previous_score))

        # 4. Save it straight away so a crash in the optional steps can't lose it.
        self._save_score(request, health_score)

        # 5 + 6. Optional steps: advice and notification.
        reasoning, notification = self._advise_and_notify(
            request, field, health_score, previous_score
        )

        # 7. Save and return the final result.
        log.info("job.completed", job_id=str(request.job_id), field_id=str(field.field_id))
        return self._finish(
            CropHealthJobResult(
                job_id=request.job_id,
                field_id=field.field_id,
                status=JobStatus.SUCCEEDED,
                health_score=health_score,
                reasoning=reasoning,
                notification=notification,
                started_at=started_at,
                finished_at=_now(),
            )
        )

    # ------------------------------------------------------------------ #
    # Helpers (each does one small thing)
    # ------------------------------------------------------------------ #

    def _advise_and_notify(
        self,
        request: CropHealthJobRequest,
        field: FieldBoundary,
        health_score: HealthScoreResult,
        previous_score: HealthScoreResult | None,
    ) -> tuple[ReasoningResult | None, NotificationSendResult | None]:
        """Best effort: a failure here must NOT invalidate the saved score."""
        reasoning: ReasoningResult | None = None
        notification: NotificationSendResult | None = None
        try:
            reasoning_input = self._context.build_input(
                field, health_score, previous_score, request.date_range
            )
            reasoning = self._reasoner.reason(reasoning_input)
            log.info(
                "reasoning.completed",
                field_id=str(field.field_id),
                generated_by=reasoning.generated_by,
                risk_level=reasoning.risk_level,
                should_notify=reasoning.should_notify,
            )
            if reasoning.should_notify:
                notification = self._notifier.notify(field, reasoning)
        except CropHealthError as exc:
            log.error(
                "job.reasoning_or_notification_failed",
                job_id=str(request.job_id),
                field_id=str(field.field_id),
                error=exc.message,
            )
        return reasoning, notification

    def _save_score(self, request: CropHealthJobRequest, health_score: HealthScoreResult) -> None:
        self._job_runs.complete_job_run(
            job_id=request.job_id,
            status=JobStatus.SUCCEEDED,
            result_json={
                "job_id": str(request.job_id),
                "field_id": str(request.field_id),
                "status": JobStatus.SUCCEEDED.value,
                "health_score": health_score.model_dump(mode="json"),
            },
            error=None,
        )

    def _finish(self, result: CropHealthJobResult) -> CropHealthJobResult:
        """Store the final result, then hand it back to the caller."""
        self._job_runs.complete_job_run(
            job_id=result.job_id,
            status=result.status,
            result_json=result.model_dump(mode="json"),
            error=result.error,
        )
        return result

    @staticmethod
    def _failure(
        request: CropHealthJobRequest,
        started_at: datetime,
        message: str,
        stale_score: HealthScoreResult | None = None,
    ) -> CropHealthJobResult:
        """A failed result. If we have an older good score, serve it with the error."""
        if stale_score is not None:
            log.warning("job.degraded_serving_stale_score", job_id=str(request.job_id))
            message = f"{message} (serving last successful score; refresh pending)"
        return CropHealthJobResult(
            job_id=request.job_id,
            field_id=request.field_id,
            status=JobStatus.FAILED,
            health_score=stale_score,
            error=message,
            started_at=started_at,
            finished_at=_now(),
        )
