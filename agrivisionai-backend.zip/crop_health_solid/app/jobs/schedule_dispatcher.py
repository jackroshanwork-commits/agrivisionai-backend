"""
ScheduleDispatcher: once a day, find fields that are due and queue a job each.

One EventBridge rule calls this (NOT one rule per field). It only decides
*what is due* and puts messages on the queue; the worker does the real work.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from croniter import croniter

from app.domain.exceptions import CropHealthError
from app.domain.interfaces import JobQueue, ScheduleRepository
from app.domain.models import CropHealthJobRequest, DateRange, JobTriggerSource
from app.logging_config import get_logger

log = get_logger(__name__)


def last_full_month(today: date) -> DateRange:
    """e.g. today = 2026-10-13 -> 2026-09-01 .. 2026-09-30"""
    first_of_this_month = today.replace(day=1)
    last_day_prev_month = first_of_this_month - timedelta(days=1)
    return DateRange(start=last_day_prev_month.replace(day=1), end=last_day_prev_month)


def next_due_at(cron_expression: str, as_of: datetime) -> datetime:
    return croniter(cron_expression, as_of).get_next(datetime)


class ScheduleDispatcher:
    def __init__(self, schedules: ScheduleRepository, queue: JobQueue) -> None:
        self._schedules = schedules
        self._queue = queue

    def run(self, as_of: datetime | None = None) -> int:
        """Returns the number of jobs queued."""
        as_of = as_of or datetime.now(timezone.utc)
        due = self._schedules.get_due_schedules(as_of)
        log.info("dispatcher.due_schedules", count=len(due), as_of=as_of.isoformat())

        queued = 0
        for schedule in due:
            request = CropHealthJobRequest(
                field_id=schedule.field_id,
                date_range=last_full_month(as_of.date()),
                trigger_source=JobTriggerSource.SCHEDULE,
            )
            try:
                self._queue.enqueue(request)
            except CropHealthError:
                # One bad field must not stop the others. It stays "due" and is retried tomorrow.
                log.error("dispatcher.enqueue_failed", field_id=str(schedule.field_id))
                continue

            queued += 1
            self._schedules.mark_schedule_run(
                schedule.field_id, next_due_at(schedule.cron_expression, as_of)
            )

        log.info("dispatcher.completed", enqueued=queued)
        return queued
