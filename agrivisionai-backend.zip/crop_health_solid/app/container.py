"""
The composition root: the ONE place where concrete classes are chosen and
connected to each other.

Everywhere else in the code asks for an interface ("give me an
ImageryProvider"); this file decides which real class that is, based on
Settings. Build things here ONCE per process (FastAPI startup, or module level
in a Lambda so warm containers reuse them).
"""
from __future__ import annotations

from dataclasses import dataclass

from app.config import Settings
from app.domain.interfaces import FieldRepository, JobQueue, JobRunRepository, ScenePreviewBuilder
from app.jobs.background_runner import BackgroundJobRunner
from app.jobs.crop_health_job import CropHealthJob
from app.jobs.farmer_notifier import FarmerNotifier
from app.jobs.health_score_calculator import HealthScoreCalculator
from app.jobs.reasoning_context import ReasoningContextGatherer
from app.jobs.schedule_dispatcher import ScheduleDispatcher
from app.jobs.score_history import ScoreHistory
from app.providers.factories import (
    cropland_mask_registry,
    imagery_registry,
    notification_registry,
    reasoning_registry,
    soil_registry,
    weather_forecast_registry,
    weather_history_registry,
)
from app.providers.imagery.high_res_preview import EsriPreviewBuilder, FallbackPreviewBuilder
from app.providers.imagery.planet_insights_provider import PlanetInsightsImageryProvider
from app.providers.imagery.planet_preview import PlanetPreviewBuilder
from app.providers.imagery.raster_scene_analyzer import RasterSceneAnalyzer
from app.providers.imagery.true_color_preview import TrueColorPreviewBuilder
from app.providers.persistence.db import Database
from app.providers.persistence.repositories.device_token_repository import SqlDeviceTokenRepository
from app.providers.persistence.repositories.field_repository import SqlFieldRepository
from app.providers.persistence.repositories.job_run_repository import SqlJobRunRepository
from app.providers.persistence.repositories.schedule_repository import SqlScheduleRepository
from app.providers.queue.sqs_job_queue import SqsJobQueue
from app.providers.reasoning.fallback_provider import FallbackReasoningProvider
from app.providers.reasoning.rule_based_provider import RuleBasedReasoningProvider


@dataclass(frozen=True)
class Container:
    """What the entry points (API, worker) actually need, nothing more."""

    fields: FieldRepository
    job_runs: JobRunRepository
    crop_health_job: CropHealthJob
    job_runner: BackgroundJobRunner


def build_job_queue(settings: Settings) -> JobQueue:
    return SqsJobQueue(settings.job_queue_url, settings.aws_region)


def build_schedule_dispatcher(settings: Settings) -> ScheduleDispatcher:
    """The dispatcher Lambda only needs schedules + a queue, so it doesn't
    build the imagery/LLM/notification providers at all."""
    schedules = SqlScheduleRepository(Database(settings))
    return ScheduleDispatcher(schedules, build_job_queue(settings))


def build_preview_builder(settings: Settings, imagery) -> ScenePreviewBuilder:
    """Pick the field-photo source from settings (the only place that decides)."""
    sentinel = TrueColorPreviewBuilder(imagery)
    if settings.preview_source == "sentinel":
        return sentinel
    esri = EsriPreviewBuilder(long_side_px=settings.preview_long_side_px)
    if settings.preview_source == "esri":
        return esri
    basemap_then_sentinel = FallbackPreviewBuilder(primary=esri, fallback=sentinel)
    if settings.preview_source == "planet" and settings.planet_imagery_collection_id:
        # Your Planet photo first; Esri, then Sentinel-2 if Planet has nothing.
        planet = (
            imagery
            if isinstance(imagery, PlanetInsightsImageryProvider)
            else imagery_registry.create("planet_insights", settings)
        )
        return FallbackPreviewBuilder(
            primary=PlanetPreviewBuilder(
                planet,
                settings.planet_imagery_collection_id,
                long_side_px=settings.preview_long_side_px,
                lookback_days=settings.planet_photo_lookback_days,
            ),
            fallback=basemap_then_sentinel,
        )
    return basemap_then_sentinel


def build_container(settings: Settings) -> Container:
    db = Database(settings)
    fields = SqlFieldRepository(db)
    job_runs = SqlJobRunRepository(db)
    device_tokens = SqlDeviceTokenRepository(db)

    imagery = imagery_registry.create(settings.imagery_provider, settings)
    cropland_mask = cropland_mask_registry.create(settings.cropland_mask_provider, settings)

    calculator = HealthScoreCalculator(
        imagery=imagery,
        cropland_mask=cropland_mask,
        scene_analyzer=RasterSceneAnalyzer(),
        preview_builder=build_preview_builder(settings, imagery),
        cloud_cover_threshold_pct=settings.cloud_cover_threshold_pct,
    )
    context_gatherer = ReasoningContextGatherer(
        weather_history=weather_history_registry.create(settings.weather_history_provider, settings),
        weather_forecast=weather_forecast_registry.create(settings.weather_provider, settings),
        soil_health=soil_registry.create(settings.soil_provider, db),
    )
    # The job just sees "a ReasoningProvider". That it is really "Groq, and if
    # Groq fails then rules" is invisible to it.
    reasoner = FallbackReasoningProvider(
        primary=reasoning_registry.create(settings.reasoning_provider, settings),
        fallback=RuleBasedReasoningProvider(),
    )
    notifier = FarmerNotifier(
        device_tokens, notification_registry.create(settings.notification_provider, settings)
    )

    job = CropHealthJob(
        fields=fields,
        job_runs=job_runs,
        score_history=ScoreHistory(job_runs),
        calculator=calculator,
        context_gatherer=context_gatherer,
        reasoner=reasoner,
        notifier=notifier,
    )
    return Container(
        fields=fields,
        job_runs=job_runs,
        crop_health_job=job,
        job_runner=BackgroundJobRunner(job, job_runs, max_pending=settings.max_pending_jobs),
    )
