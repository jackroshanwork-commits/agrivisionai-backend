"""
Raster processing: turns raw band bytes (as returned by ImageryProvider.fetch_bands)
into per-scene NDVI arrays, and applies a cropland mask.
"""

from __future__ import annotations

import math

import numpy as np
import rasterio
from rasterio.io import MemoryFile
from rasterio.mask import mask as rio_mask
from rasterio.warp import reproject, transform_geom
from rasterio.windows import Window, from_bounds
from rasterio.enums import Resampling

from app.domain.exceptions import ScoringError


def _iter_xy(coords):
    """Yield (x, y) from any nesting of GeoJSON coordinates."""
    if coords and isinstance(coords[0], (int, float)):
        yield coords[0], coords[1]
    else:
        for c in coords:
            yield from _iter_xy(c)


def _aoi_window(dataset, aoi_geojson: dict, pad_px: int = 2) -> Window:
    """Pixel window covering the field (plus a small margin), clipped to the raster."""
    geom = transform_geom("EPSG:4326", dataset.crs, aoi_geojson)
    pts = list(_iter_xy(geom["coordinates"]))
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    win = from_bounds(min(xs), min(ys), max(xs), max(ys), transform=dataset.transform)
    col0 = max(0, int(math.floor(win.col_off)) - pad_px)
    row0 = max(0, int(math.floor(win.row_off)) - pad_px)
    col1 = min(dataset.width, int(math.ceil(win.col_off + win.width)) + pad_px)
    row1 = min(dataset.height, int(math.ceil(win.row_off + win.height)) + pad_px)
    if col1 <= col0 or row1 <= row0:
        raise ScoringError("The field lies outside this satellite tile")
    return Window(col0, row0, col1 - col0, row1 - row0)


def band_bytes_to_array(
    band_bytes: bytes,
    aoi_geojson: dict | None = None,
) -> tuple[np.ndarray, object, object]:
    """
    Decode a raster band and return:
        array, transform, CRS

    With `aoi_geojson`, only the pixels around the field are decoded (the
    returned transform is that window's). Without it, the whole band is read.
    """
    try:
        with MemoryFile(band_bytes) as memfile:
            with memfile.open() as dataset:
                if aoi_geojson is not None:
                    window = _aoi_window(dataset, aoi_geojson)
                    array = dataset.read(1, window=window).astype("float32")
                    transform = dataset.window_transform(window)
                else:
                    array = dataset.read(1).astype("float32")
                    transform = dataset.transform
                crs = dataset.crs

                return array, transform, crs

    except rasterio.errors.RasterioIOError as exc:
        raise ScoringError(
            f"Failed to decode raster band: {exc}"
        ) from exc


def apply_cropland_mask(
    band_array: np.ndarray,
    mask_geotiff_bytes: bytes,
    aoi_geojson: dict,
    band_transform,
    band_crs,
) -> np.ndarray:
    """
    Apply the WorldCover cropland mask to the Sentinel-2 band.

    The WorldCover mask and Sentinel-2 band may have different:
      - shapes
      - CRS
      - pixel sizes
      - transforms

    Therefore the WorldCover mask is reprojected/resampled onto
    the Sentinel-2 band grid before applying the mask.
    """

    try:
        with MemoryFile(mask_geotiff_bytes) as memfile:
            with memfile.open() as mask_ds:

                # Crop the WorldCover raster to the field AOI.
                masked, _ = rio_mask(
                    mask_ds,
                    [aoi_geojson],
                    crop=False,
                )

                source_mask = masked[0].astype("uint8")

                # Destination must have exactly the same shape
                # as the Sentinel-2 band.
                destination_mask = np.zeros(
                    band_array.shape,
                    dtype="uint8",
                )

                # Reproject WorldCover mask onto Sentinel-2 grid.
                reproject(
                    source=source_mask,
                    destination=destination_mask,
                    src_transform=mask_ds.transform,
                    src_crs=mask_ds.crs,
                    dst_transform=band_transform,
                    dst_crs=band_crs,
                    resampling=Resampling.nearest,
                )

                # Any non-zero WorldCover value is treated as
                # a valid/cropland pixel, preserving the existing
                # behavior of the application.
                cropland = destination_mask > 0

    except Exception as exc:
        raise ScoringError(
            f"Failed to apply cropland mask: {exc}"
        ) from exc

    out = band_array.copy()

    # Remove non-cropland pixels.
    out[~cropland] = np.nan

    return out


def scene_ndvi_array(
    red_bytes: bytes,
    nir_bytes: bytes,
    aoi_geojson: dict | None = None,
) -> tuple[np.ndarray, object, object]:
    """
    Calculate NDVI from Sentinel-2 B04 (red) and B08 (NIR).

    Returns:
        NDVI array, transform, CRS
    """

    red, transform, crs = band_bytes_to_array(red_bytes, aoi_geojson)
    nir, nir_transform, nir_crs = band_bytes_to_array(nir_bytes, aoi_geojson)

    # B04 and B08 are both Sentinel-2 10m bands and should
    # normally have identical grids.
    if red.shape != nir.shape:
        raise ScoringError(
            f"Red band shape {red.shape} does not match "
            f"NIR band shape {nir.shape}"
        )

    denom = nir + red

    with np.errstate(divide="ignore", invalid="ignore"):
        ndvi = np.where(
            denom != 0,
            (nir - red) / denom,
            np.nan,
        )

    ndvi = np.clip(ndvi, -1.0, 1.0)

    return ndvi, transform, crs


def array_mean_min_max(
    arr: np.ndarray,
) -> tuple[float, float, float]:
    """
    Return mean, minimum and maximum of valid NDVI pixels.
    """

    valid = arr[~np.isnan(arr)]

    if valid.size == 0:
        raise ScoringError(
            "Array has no valid (non-NaN) pixels after masking"
        )

    return (
        float(valid.mean()),
        float(valid.min()),
        float(valid.max()),
    )
