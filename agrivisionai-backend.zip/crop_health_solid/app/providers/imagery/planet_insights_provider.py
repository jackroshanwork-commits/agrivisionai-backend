"""
Planet Insights Platform imagery provider (Sentinel-2 L2A).

How it works
------------
Planet Insights exposes the Sentinel Hub APIs on ``services.sentinel-hub.com``:

  * Auth     - OAuth2 *client credentials* (client id + secret -> bearer token).
  * Catalog  - STAC search: "which Sentinel-2 scenes cover this field?"
  * Process  - "give me these bands for this box, as a GeoTIFF".

The big difference from the old downloader is the last point. We never
download a whole 100 km Sentinel-2 tile; Planet cuts out just the field (plus a
little surrounding) on its servers and sends back a small GeoTIFF. That is
much faster, uses far less memory, and the file is already in the shape the
rest of the pipeline reads (`raster_processing.py`, `true_color_preview.py`).

Band names understood by `fetch_bands`
--------------------------------------
  "B04", "B08", "B04_10m", ...  one band as float32 surface reflectance (0..1)
  "TCI", "TCI_10m"              ready-made 3-band true-colour picture (uint8)

Only Sentinel-2 is used here. Planet's own satellites (PlanetScope, SkySat)
need a paid data subscription; add them later as another class that implements
`ImageryProvider` - nothing else in the app would change.
"""
from __future__ import annotations

import math
import re
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from rasterio.warp import transform_bounds

from app.config import Settings
from app.domain.exceptions import ImageryFetchError
from app.domain.geo_utils import bounding_box
from app.domain.interfaces import ImageryProvider
from app.domain.models import DateRange, SceneRef
from app.logging_config import get_logger
from app.providers.common.http_errors import RETRYABLE_HTTP_STATUS, RetryableHTTPError
from app.providers.common.retry_policies import rate_limited_retry

log = get_logger(__name__)

_COLLECTION = "sentinel-2-l2a"
_PIXEL_SIZE_M = 10.0  # Sentinel-2's sharpest bands
_MAX_SIDE_PX = 2500  # Process API limit per side
_PAD_FRAC = 0.25  # show some surroundings around the field
_MIN_PAD_M = 30.0
_SCENE_WINDOW = timedelta(minutes=30)  # +/- around the scene's sensing time
_TOKEN_SAFETY_SECONDS = 60  # refresh a token this long before it expires
_MAX_CATALOG_PAGES = 5

# "B04", "B8A", "B04_10m" ... (anything else is rejected, because the band
# name is pasted into the evalscript below).
_BAND_RE = re.compile(r"^(B(?:0[1-9]|1[0-2]|8A))(?:_\d+m)?$", re.IGNORECASE)
_TCI_RE = re.compile(r"^TCI(?:_\d+m)?$", re.IGNORECASE)

_SINGLE_BAND_EVALSCRIPT = """//VERSION=3
function setup() {
  return {
    input: [{ bands: ["%(band)s", "dataMask"] }],
    output: { bands: 1, sampleType: "FLOAT32" }
  };
}
function evaluatePixel(s) {
  return [s.dataMask ? s.%(band)s : 0];
}
"""

_TRUE_COLOR_EVALSCRIPT = """//VERSION=3
function setup() {
  return {
    input: [{ bands: ["B04", "B03", "B02", "dataMask"] }],
    output: { bands: 3, sampleType: "AUTO" }
  };
}
function evaluatePixel(s) {
  return [2.5 * s.B04, 2.5 * s.B03, 2.5 * s.B02];
}
"""


def _utm_epsg(lon: float, lat: float) -> int:
    """EPSG code of the UTM zone containing the point (Sentinel-2's own grid)."""
    zone = min(60, max(1, int((lon + 180.0) // 6.0) + 1))
    return (32600 if lat >= 0 else 32700) + zone


def _iso_z(value: datetime) -> str:
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class PlanetInsightsImageryProvider(ImageryProvider):
    """Sentinel-2 imagery through the Planet Insights Platform."""

    def __init__(self, settings: Settings, http_client: httpx.Client | None = None) -> None:
        self._settings = settings
        self._http = http_client or httpx.Client(timeout=120.0, follow_redirects=True)
        # Scenes are scored in parallel threads, so the cached token is guarded.
        self._token: str | None = None
        self._token_expires_at: float = 0.0
        self._token_lock = threading.Lock()

    # ------------------------------------------------------------------ #
    # Authentication
    # ------------------------------------------------------------------ #

    def _get_token(self) -> str:
        with self._token_lock:
            if self._token and time.monotonic() < self._token_expires_at:
                return self._token
            try:
                token, expires_in = self._request_token()
            except RetryableHTTPError as exc:
                raise ImageryFetchError(
                    f"Planet Insights authentication exhausted retries: {exc}", retryable=True
                ) from exc
            self._token = token
            self._token_expires_at = time.monotonic() + max(0, expires_in - _TOKEN_SAFETY_SECONDS)
            return token

    def _forget_token(self) -> None:
        with self._token_lock:
            self._token = None

    @rate_limited_retry(RetryableHTTPError)
    def _request_token(self) -> tuple[str, int]:
        if not self._settings.planet_client_id or not self._settings.planet_client_secret:
            raise ImageryFetchError(
                "PLANET_CLIENT_ID and PLANET_CLIENT_SECRET must both be set "
                "(create an OAuth client in your Planet Insights account)."
            )
        try:
            resp = self._http.post(
                self._settings.planet_auth_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._settings.planet_client_id,
                    "client_secret": self._settings.planet_client_secret,
                },
            )
        except httpx.HTTPError as exc:
            raise RetryableHTTPError(f"Planet Insights token request failed: {exc}") from exc
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} from Planet Insights auth")
        if resp.status_code != 200:
            raise ImageryFetchError(
                f"Planet Insights authentication failed: HTTP {resp.status_code}: {resp.text[:300]}",
                upstream_status=resp.status_code,
            )
        body = resp.json()
        token = body.get("access_token")
        if not token:
            raise ImageryFetchError("Planet Insights auth response had no access_token")
        return token, int(body.get("expires_in", 300))

    # ------------------------------------------------------------------ #
    # One authenticated HTTP call (shared by search + fetch)
    # ------------------------------------------------------------------ #

    @rate_limited_retry(RetryableHTTPError)
    def _post(self, url: str, body: dict[str, Any], *, accept: str) -> httpx.Response:
        """POST with a bearer token. Retries 429/5xx and a stale token; any
        other non-200 response is returned for the caller to describe."""
        token = self._get_token()
        try:
            resp = self._http.post(
                url,
                json=body,
                headers={"Authorization": f"Bearer {token}", "Accept": accept},
            )
        except httpx.HTTPError as exc:
            raise RetryableHTTPError(f"Planet Insights connection failed: {exc}") from exc
        if resp.status_code == 401:
            self._forget_token()  # the retry will fetch a fresh one
            raise RetryableHTTPError("HTTP 401 from Planet Insights (token expired?)")
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} from Planet Insights")
        return resp

    def _post_or_raise(self, url: str, body: dict[str, Any], *, accept: str, what: str) -> httpx.Response:
        try:
            resp = self._post(url, body, accept=accept)
        except RetryableHTTPError as exc:
            raise ImageryFetchError(f"{what} exhausted retries: {exc}", retryable=True) from exc
        if resp.status_code != 200:
            raise ImageryFetchError(
                f"{what} failed: HTTP {resp.status_code}: {resp.text[:500]}",
                upstream_status=resp.status_code,
            )
        return resp

    # ------------------------------------------------------------------ #
    # search()  -  Catalog API
    # ------------------------------------------------------------------ #

    def search(self, aoi_geojson: dict, date_range: DateRange) -> list[SceneRef]:
        url = self._settings.planet_catalog_url.rstrip("/") + "/search"
        body: dict[str, Any] = {
            "collections": [_COLLECTION],
            "intersects": aoi_geojson,
            "datetime": f"{date_range.start.isoformat()}T00:00:00Z/{date_range.end.isoformat()}T23:59:59Z",
            "limit": 100,
        }

        features: list[dict[str, Any]] = []
        for _ in range(_MAX_CATALOG_PAGES):
            data = self._post_or_raise(
                url, body, accept="application/json", what="Planet Insights catalog search"
            ).json()
            features.extend(data.get("features", []))
            next_page = (data.get("context") or {}).get("next")
            if not next_page:
                break
            body = {**body, "next": next_page}

        scenes: list[SceneRef] = []
        for feature in features:
            props = feature.get("properties", {})
            scene_id = feature.get("id")
            sensed_at = self._parse_datetime(props.get("datetime"))
            if not scene_id or sensed_at is None:
                continue
            cloud = props.get("eo:cloud_cover")
            scenes.append(
                SceneRef(
                    scene_id=scene_id,
                    collection=_COLLECTION,
                    sensed_at=sensed_at,
                    cloud_cover_pct=float(cloud) if cloud is not None else None,
                    provider="planet_insights",
                    aoi_geojson=aoi_geojson,
                )
            )
        return self._one_scene_per_day(scenes)

    @staticmethod
    def _one_scene_per_day(scenes: list[SceneRef]) -> list[SceneRef]:
        """A field on a tile border shows up once per tile, but Planet's Process
        API already merges neighbouring tiles of the same pass. Keeping the
        clearest scene per UTC day avoids paying for identical downloads twice."""
        best: dict[Any, SceneRef] = {}
        for scene in scenes:
            day = scene.sensed_at.astimezone(timezone.utc).date()
            cloud = 100.0 if scene.cloud_cover_pct is None else scene.cloud_cover_pct
            current = best.get(day)
            current_cloud = (
                None
                if current is None
                else (100.0 if current.cloud_cover_pct is None else current.cloud_cover_pct)
            )
            if current is None or cloud < current_cloud:
                best[day] = scene
        return sorted(best.values(), key=lambda s: s.sensed_at)

    @staticmethod
    def _parse_datetime(value: str | None) -> datetime | None:
        if not value:
            return None
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)

    # ------------------------------------------------------------------ #
    # fetch_bands()  -  Process API
    # ------------------------------------------------------------------ #

    def fetch_bands(self, scene: SceneRef, bands: list[str]) -> dict[str, bytes]:
        if scene.aoi_geojson is None:
            raise ImageryFetchError(
                f"Scene {scene.scene_id} carries no field area, so Planet Insights "
                "cannot clip it. Scenes must come from this provider's search()."
            )
        bounds, width, height = self._request_box(scene.aoi_geojson)
        return {band: self._fetch_one(scene, band, bounds, width, height) for band in bands}

    def _fetch_one(
        self, scene: SceneRef, band: str, bounds: dict[str, Any], width: int, height: int
    ) -> bytes:
        evalscript = self._evalscript_for(band)
        body = {
            "input": {
                "bounds": bounds,
                "data": [
                    {
                        "type": _COLLECTION,
                        "dataFilter": {
                            "timeRange": {
                                "from": _iso_z(scene.sensed_at - _SCENE_WINDOW),
                                "to": _iso_z(scene.sensed_at + _SCENE_WINDOW),
                            },
                            "mosaickingOrder": "leastCC",
                        },
                    }
                ],
            },
            "output": {
                "width": width,
                "height": height,
                "responses": [{"identifier": "default", "format": {"type": "image/tiff"}}],
            },
            "evalscript": evalscript,
        }

        resp = self._post_or_raise(
            self._settings.planet_process_url,
            body,
            accept="image/tiff",
            what=f"Planet Insights download of '{band}' for scene {scene.scene_id}",
        )
        if not resp.content:
            raise ImageryFetchError(f"Planet Insights returned an empty image for '{band}'")
        return resp.content

    def process_image(self, body: dict[str, Any], *, what: str, accept: str = "image/png") -> bytes:
        """Send any Process API request (used by the field-photo builder) with
        this provider's login, retries and error translation."""
        resp = self._post_or_raise(
            self._settings.planet_process_url, body, accept=accept, what=what
        )
        if not resp.content:
            raise ImageryFetchError(f"{what}: Planet Insights returned an empty image")
        return resp.content

    @staticmethod
    def _evalscript_for(band: str) -> str:
        name = band.strip()
        if _TCI_RE.match(name):
            return _TRUE_COLOR_EVALSCRIPT
        match = _BAND_RE.match(name)
        if not match:
            raise ImageryFetchError(
                f"Unsupported band '{band}' for Planet Insights "
                "(use B01..B12, B8A or TCI, optionally with a _10m style suffix)."
            )
        return _SINGLE_BAND_EVALSCRIPT % {"band": match.group(1).upper()}

    @staticmethod
    def _request_box(aoi_geojson: dict) -> tuple[dict[str, Any], int, int]:
        """(bounds, width_px, height_px) of the box to cut out: the field plus
        a margin, on the Sentinel-2 10 m grid in the field's UTM zone (so no
        resampling blur for 10 m bands).

        The same field always gives the same box and size, so the red and NIR
        pictures line up pixel for pixel."""
        min_lon, min_lat, max_lon, max_lat = bounding_box(aoi_geojson)
        lat_mid = (min_lat + max_lat) / 2
        m_per_deg_lat = 111_320.0
        m_per_deg_lon = 111_320.0 * max(0.01, math.cos(math.radians(lat_mid)))
        pad_lat = max((max_lat - min_lat) * _PAD_FRAC, _MIN_PAD_M / m_per_deg_lat)
        pad_lon = max((max_lon - min_lon) * _PAD_FRAC, _MIN_PAD_M / m_per_deg_lon)

        epsg = _utm_epsg((min_lon + max_lon) / 2, lat_mid)
        x0, y0, x1, y1 = transform_bounds(
            "EPSG:4326",
            f"EPSG:{epsg}",
            min_lon - pad_lon,
            min_lat - pad_lat,
            max_lon + pad_lon,
            max_lat + pad_lat,
        )

        # A very large field would exceed the API's size limit: use coarser pixels.
        longest_m = max(x1 - x0, y1 - y0)
        pixel = max(_PIXEL_SIZE_M, math.ceil(longest_m / _MAX_SIDE_PX / _PIXEL_SIZE_M) * _PIXEL_SIZE_M)
        x0, y0 = math.floor(x0 / pixel) * pixel, math.floor(y0 / pixel) * pixel
        x1, y1 = math.ceil(x1 / pixel) * pixel, math.ceil(y1 / pixel) * pixel
        bounds = {
            "bbox": [x0, y0, x1, y1],
            "properties": {"crs": f"http://www.opengis.net/def/crs/EPSG/0/{epsg}"},
        }
        return bounds, max(1, round((x1 - x0) / pixel)), max(1, round((y1 - y0) / pixel))
