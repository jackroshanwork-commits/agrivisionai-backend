"""
Sharp field photo from Planet Insights (PlanetScope ~3 m, SkySat ~0.5 m).

Give it a field's coordinates (the GeoJSON boundary) and it asks Planet's
Process API for a true-colour picture of that box, taken from *your* Planet
data collection (the `byoc-...` id you receive when you order or subscribe to
Planet imagery). Sentinel-2 is only 10 m per pixel, so a small field looks
blurry there; this is the sharp alternative.

Best effort, like every photo builder: any problem (no collection configured,
no recent picture over the field, network error) is logged and returns None, so
the next builder in a `FallbackPreviewBuilder` gets its turn and a missing
photo never fails a health score.
"""
from __future__ import annotations

import base64
import io
import math
from datetime import timedelta, timezone

from PIL import Image

from app.domain.interfaces import ScenePreviewBuilder
from app.domain.models import SceneRef, ScenePreview
from app.logging_config import get_logger
from app.providers.imagery.high_res_preview import padded_bbox
from app.providers.imagery.planet_insights_provider import PlanetInsightsImageryProvider

log = get_logger(__name__)

PLANET_SOURCE = "planet-insights"
_MAX_SIDE_PX = 2500  # Process API limit per side

# Same recipe as Planet's own true-colour examples: reflectance = value / 10000,
# times 2.5 to brighten.
_TRUE_COLOR_EVALSCRIPT = """//VERSION=3
function setup() {
  return {
    input: ["red", "green", "blue"],
    output: { bands: 3 }
  };
}
function evaluatePixel(sample) {
  return [2.5 * sample.red / 10000, 2.5 * sample.green / 10000, 2.5 * sample.blue / 10000];
}
"""


def _collection_type(collection_id: str) -> str:
    cid = collection_id.strip()
    return cid if cid.lower().startswith("byoc-") else f"byoc-{cid}"


def _pixel_size(bbox: tuple[float, float, float, float], long_side_px: int) -> tuple[int, int]:
    """(width, height) in pixels for a lon/lat box, so pixels are square on the ground."""
    min_lon, min_lat, max_lon, max_lat = bbox
    lat_mid = (min_lat + max_lat) / 2
    width_m = (max_lon - min_lon) * 111_320.0 * max(0.01, math.cos(math.radians(lat_mid)))
    height_m = (max_lat - min_lat) * 111_320.0
    scale = min(long_side_px, _MAX_SIDE_PX) / max(width_m, height_m)
    return max(64, round(width_m * scale)), max(64, round(height_m * scale))


class PlanetPreviewBuilder(ScenePreviewBuilder):
    """True-colour photo of a field's bounding box (plus surroundings)."""

    def __init__(
        self,
        imagery: PlanetInsightsImageryProvider,
        collection_id: str,
        long_side_px: int = 1280,
        lookback_days: int = 14,
        jpeg_quality: int = 88,
    ) -> None:
        self._imagery = imagery
        self._collection_type = _collection_type(collection_id)
        self._px = long_side_px
        self._lookback = timedelta(days=lookback_days)
        self._quality = jpeg_quality

    def build(self, scene: SceneRef, aoi_geojson: dict) -> ScenePreview | None:
        try:
            return self._build(scene, aoi_geojson)
        except Exception as exc:  # noqa: BLE001 - best-effort
            log.warning("planet_preview.failed", error=str(exc)[:300])
            return None

    def _build(self, scene: SceneRef, aoi_geojson: dict) -> ScenePreview | None:
        bbox = padded_bbox(aoi_geojson)
        width, height = _pixel_size(bbox, self._px)
        newest = scene.sensed_at.astimezone(timezone.utc) + timedelta(days=1)
        body = {
            "input": {
                "bounds": {
                    "bbox": list(bbox),
                    "properties": {"crs": "http://www.opengis.net/def/crs/EPSG/0/4326"},
                },
                "data": [
                    {
                        "type": self._collection_type,
                        "dataFilter": {
                            "timeRange": {
                                "from": (newest - self._lookback - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                                "to": newest.strftime("%Y-%m-%dT%H:%M:%SZ"),
                            },
                            "mosaickingOrder": "mostRecent",
                        },
                    }
                ],
            },
            "output": {
                "width": width,
                "height": height,
                "responses": [{"identifier": "default", "format": {"type": "image/png"}}],
            },
            "evalscript": _TRUE_COLOR_EVALSCRIPT,
        }
        raw = self._imagery.process_image(body, what="Planet Insights field photo")

        img = Image.open(io.BytesIO(raw)).convert("RGB")
        if not any(hi for _lo, hi in img.getextrema()):
            # All black: Planet has no picture over this field in the period.
            log.info("planet_preview.no_data", collection=self._collection_type)
            return None
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=self._quality, optimize=True)
        data_url = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        # The request box IS the image extent: [[south, west], [north, east]].
        bounds = [[bbox[1], bbox[0]], [bbox[3], bbox[2]]]
        log.info("planet_preview.built", width=img.width, height=img.height)
        return ScenePreview(data_url=data_url, bounds=bounds, source=PLANET_SOURCE)
