"""
True-colour Sentinel-2 photo of a field, shown next to the health score.

Best-effort by design: any failure is logged and returns None, so a missing
picture never invalidates an already-computed health score.
"""
from __future__ import annotations

import base64
import warnings

import numpy as np
import rasterio
from affine import Affine
from rasterio.enums import Resampling
from rasterio.io import MemoryFile
from rasterio.warp import transform as warp_transform, transform_geom
from rasterio.windows import Window, from_bounds as window_from_bounds

from app.domain.exceptions import ScoringError
from app.domain.interfaces import ImageryProvider, ScenePreviewBuilder
from app.domain.models import SceneRef, ScenePreview
from app.logging_config import get_logger

log = get_logger(__name__)

_PAD_FRAC = 0.25  # show some surroundings around the field
_MIN_PAD_PX = 8
_MAX_SIDE_PX = 800
_MIN_SIDE_PX = 1024  # small fields are enlarged to at least this many pixels


def _field_window(aoi_geojson: dict, ds) -> Window:
    """Pixel window covering the field's bounding box plus some context."""
    geom = transform_geom("EPSG:4326", ds.crs, aoi_geojson)
    ring = geom["coordinates"][0]
    xs = [c[0] for c in ring]
    ys = [c[1] for c in ring]
    win = window_from_bounds(min(xs), min(ys), max(xs), max(ys), transform=ds.transform)
    pad_x = max(_MIN_PAD_PX, win.width * _PAD_FRAC)
    pad_y = max(_MIN_PAD_PX, win.height * _PAD_FRAC)
    win = Window(win.col_off - pad_x, win.row_off - pad_y, win.width + 2 * pad_x, win.height + 2 * pad_y)
    win = win.intersection(Window(0, 0, ds.width, ds.height))  # raises if the field is off-raster
    col, row = int(np.floor(win.col_off)), int(np.floor(win.row_off))
    return Window(
        col,
        row,
        min(int(np.ceil(win.width)), ds.width - col),
        min(int(np.ceil(win.height)), ds.height - row),
    )


def _read_window(ds, win: Window, indexes: list[int]):
    """Read a window, shrinking very large ones so the image stays small."""
    scale = max(1.0, max(win.width, win.height) / _MAX_SIDE_PX)
    out_w, out_h = max(1, round(win.width / scale)), max(1, round(win.height / scale))
    data = ds.read(indexes, window=win, out_shape=(len(indexes), out_h, out_w), resampling=Resampling.average)
    t = ds.window_transform(win)
    sx, sy = win.width / out_w, win.height / out_h  # source pixels per output pixel
    return data, Affine(t.a * sx, t.b * sy, t.c, t.d * sx, t.e * sy, t.f)


def _upscale(rgb: np.ndarray, transform):
    """Enlarge a tiny crop (Lanczos + light sharpen) so it is not a blocky
    thumbnail. Only smooths: Sentinel-2 cannot show detail below 10 m.
    Returns (rgb, transform) with the pixel size updated to match."""
    from PIL import Image, ImageFilter

    _, h, w = rgb.shape
    factor = _MIN_SIDE_PX / max(h, w)
    if factor <= 1.0:
        return rgb, transform
    new_w, new_h = round(w * factor), round(h * factor)
    img = Image.fromarray(np.moveaxis(rgb, 0, -1)).resize((new_w, new_h), Image.Resampling.LANCZOS)
    img = img.filter(ImageFilter.UnsharpMask(radius=1.2, percent=60, threshold=2))
    sx, sy = w / new_w, h / new_h  # old pixels per new pixel
    new_transform = Affine(
        transform.a * sx, transform.b * sy, transform.c,
        transform.d * sx, transform.e * sy, transform.f,
    )
    return np.moveaxis(np.asarray(img), -1, 0).copy(), new_transform


def _encode(rgb: np.ndarray, transform, crs) -> tuple[str, list[list[float]]]:
    """(3, H, W) uint8 -> (JPEG data-URL, [[south, west], [north, east]])."""
    _, h, w = rgb.shape
    with MemoryFile() as mem:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", rasterio.errors.NotGeoreferencedWarning)
            with mem.open(driver="JPEG", width=w, height=h, count=3, dtype="uint8", quality=88) as dst:
                dst.write(rgb)
        jpeg = mem.read()
    # pixel (col, row) -> map x/y, written out so it works on any `affine` version
    corners = [
        (transform.a * c + transform.b * r + transform.c, transform.d * c + transform.e * r + transform.f)
        for c, r in ((0, 0), (w, 0), (0, h), (w, h))
    ]
    lons, lats = warp_transform(crs, "EPSG:4326", [c[0] for c in corners], [c[1] for c in corners])
    bounds = [[float(min(lats)), float(min(lons))], [float(max(lats)), float(max(lons))]]
    return "data:image/jpeg;base64," + base64.b64encode(jpeg).decode("ascii"), bounds


def render_true_color_preview(aoi_geojson: dict, tci_bytes=None, rgb_band_bytes=None):
    """
    Crop a Sentinel-2 true-colour image to the field (plus surroundings).
    Give `tci_bytes` (ready-made 3-band TCI) or `rgb_band_bytes` = (B04, B03, B02).
    Returns (data_url, bounds), or None if the area is empty.
    """
    if tci_bytes is not None:
        with MemoryFile(tci_bytes) as mem, mem.open() as ds:
            if ds.count < 3:
                raise ScoringError(f"TCI image has {ds.count} band(s), expected 3")
            win = _field_window(aoi_geojson, ds)
            rgb, transform = _read_window(ds, win, [1, 2, 3])
            crs = ds.crs
    elif rgb_band_bytes is not None:
        channels, transform, crs, win = [], None, None, None
        for raw in rgb_band_bytes:
            with MemoryFile(raw) as mem, mem.open() as ds:
                if win is None:
                    win, crs = _field_window(aoi_geojson, ds), ds.crs
                data, t = _read_window(ds, win, [1])
                transform = transform or t
                channels.append(data[0].astype("float32"))
        stack = np.stack(channels)
        valid = stack[stack > 0]
        if valid.size == 0:
            return None
        lo, hi = np.percentile(valid, (2, 98))
        if hi <= lo:
            return None
        rgb = (np.clip((stack - lo) / (hi - lo), 0, 1) ** (1 / 1.1) * 255).astype("uint8")
        rgb[stack == 0] = 0
    else:
        raise ScoringError("render_true_color_preview needs tci_bytes or rgb_band_bytes")
    if not rgb.any():
        return None
    rgb, transform = _upscale(rgb, transform)
    return _encode(rgb, transform, crs)


class TrueColorPreviewBuilder(ScenePreviewBuilder):
    """Builds the field photo by downloading a scene's colour bands through
    whichever ImageryProvider it was given (it never knows if that is Planet
    Insights or AWS)."""

    def __init__(self, imagery: ImageryProvider) -> None:
        self._imagery = imagery

    def build(self, scene: SceneRef, aoi_geojson: dict) -> ScenePreview | None:
        result = self._build_raw(scene, aoi_geojson)
        if result is None:
            return None
        data_url, bounds = result
        return ScenePreview(data_url=data_url, bounds=bounds)

    def _build_raw(self, scene: SceneRef, aoi_geojson: dict):
        # 1) Preferred: Sentinel-2's ready-made true-colour product (one download).
        try:
            tci = self._imagery.fetch_bands(scene, ["TCI_10m"])["TCI_10m"]
            return render_true_color_preview(aoi_geojson, tci_bytes=tci)
        except Exception as exc:  # noqa: BLE001 - best-effort
            log.warning(
                "scene_preview.tci_failed",
                scene_id=scene.scene_id,
                available_assets=sorted(scene.asset_urls.keys()),
                error=str(exc)[:300],
            )
        # 2) Fallback: build the colour image from the red / green / blue bands.
        try:
            names = ["B04_10m", "B03_10m", "B02_10m"]
            raw = self._imagery.fetch_bands(scene, names)
            return render_true_color_preview(aoi_geojson, rgb_band_bytes=tuple(raw[n] for n in names))
        except Exception as exc:  # noqa: BLE001 - best-effort
            log.warning("scene_preview.rgb_failed", scene_id=scene.scene_id, error=str(exc)[:300])
            return None
