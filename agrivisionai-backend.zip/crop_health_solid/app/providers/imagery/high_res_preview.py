"""
High-resolution field photo (sub-metre) from Esri World Imagery, plus a small
"try this, else that" wrapper.

Why this exists
---------------
Sentinel-2 pixels are 10 m wide, so a 100 m field is only ~10 pixels across and
looks blurry however it is enlarged. Esri World Imagery is a basemap built
from much sharper aerial/satellite imagery (often 0.3 - 1 m), so the same
field looks clear.

Trade-offs (be aware):
  * It is a basemap: the picture is NOT from the Sentinel scene used for the
    health score, and its capture date is unknown (so `source` says so).
  * Esri's terms allow testing / non-commercial use freely; for a paid product
    check their licence (or swap in another high-res provider with the same
    `ScenePreviewBuilder` interface - nothing else needs to change).

Best-effort by design: every failure returns None, so the next builder in a
`FallbackPreviewBuilder` gets its turn and a missing photo never fails a score.
"""
from __future__ import annotations

import base64
import io
import json
import threading

import httpx
from PIL import Image

from app.domain.geo_utils import bounding_box
from app.domain.interfaces import ScenePreviewBuilder
from app.domain.models import SceneRef, ScenePreview
from app.logging_config import get_logger
from app.providers.common.http_errors import RETRYABLE_HTTP_STATUS, RetryableHTTPError
from app.providers.common.retry_policies import standard_retry

log = get_logger(__name__)

ESRI_EXPORT_URL = (
    "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/export"
)
ESRI_SOURCE = "esri-world-imagery"
_MAX_ESRI_SIDE_PX = 2048  # stay well inside the service's image-size limit
_EARTH_RADIUS_M = 6378137.0


def _to_mercator(lon: float, lat: float) -> tuple[float, float]:
    """WGS84 lon/lat -> Web Mercator metres (what Esri's `export` expects)."""
    import math

    x = math.radians(lon) * _EARTH_RADIUS_M
    y = math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) * _EARTH_RADIUS_M
    return x, y


def padded_bbox(
    aoi_geojson: dict, pad_frac: float = 0.25, min_pad_m: float = 15.0
) -> tuple[float, float, float, float]:
    """(min_lon, min_lat, max_lon, max_lat) of the field plus some surroundings."""
    import math

    min_lon, min_lat, max_lon, max_lat = bounding_box(aoi_geojson)
    lat_mid = (min_lat + max_lat) / 2
    m_per_deg_lat = 111_320.0
    m_per_deg_lon = 111_320.0 * max(0.01, math.cos(math.radians(lat_mid)))
    pad_lat = max((max_lat - min_lat) * pad_frac, min_pad_m / m_per_deg_lat)
    pad_lon = max((max_lon - min_lon) * pad_frac, min_pad_m / m_per_deg_lon)
    return min_lon - pad_lon, min_lat - pad_lat, max_lon + pad_lon, max_lat + pad_lat


def esri_params(bbox: tuple[float, float, float, float], long_side_px: int) -> dict:
    """Query parameters for Esri's `export` endpoint (picture sized to the bbox)."""
    x0, y0 = _to_mercator(bbox[0], bbox[1])
    x1, y1 = _to_mercator(bbox[2], bbox[3])
    w_m, h_m = x1 - x0, y1 - y0
    scale = min(long_side_px, _MAX_ESRI_SIDE_PX) / max(w_m, h_m)
    width, height = max(64, round(w_m * scale)), max(64, round(h_m * scale))
    return {
        "bbox": f"{x0},{y0},{x1},{y1}",
        "bboxSR": 3857,
        "imageSR": 3857,
        "size": f"{width},{height}",
        "format": "png",
        "transparent": "false",
        "f": "image",
    }


class EsriPreviewBuilder(ScenePreviewBuilder):
    """Sharp photo of the field's bounding box (plus surroundings)."""

    def __init__(
        self,
        long_side_px: int = 1280,
        jpeg_quality: int = 88,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._px = long_side_px
        self._quality = jpeg_quality
        self._http = http_client or httpx.Client(timeout=60.0, follow_redirects=True)
        # The calculator asks for one photo per scene; the picture is the same
        # for all of them, so remember recent answers and download only once.
        self._cache: dict[str, ScenePreview | None] = {}
        self._lock = threading.Lock()

    @standard_retry(RetryableHTTPError)
    def _download(self, params: dict) -> bytes:
        try:
            resp = self._http.get(ESRI_EXPORT_URL, params=params)
        except httpx.HTTPError as exc:
            raise RetryableHTTPError(f"Esri imagery connection failed: {exc}") from exc
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} from Esri imagery")
        if resp.status_code != 200:
            raise ValueError(f"Esri imagery returned HTTP {resp.status_code}: {resp.text[:200]}")
        if not resp.headers.get("content-type", "").startswith("image"):
            # Esri reports some errors as JSON with HTTP 200.
            raise ValueError(f"Esri imagery returned an error: {resp.text[:200]}")
        return resp.content

    def build(self, scene: SceneRef, aoi_geojson: dict) -> ScenePreview | None:
        key = json.dumps(aoi_geojson, sort_keys=True)
        with self._lock:  # second thread waits here, then hits the cache
            if key in self._cache:
                return self._cache[key]
            preview = self._build(aoi_geojson)
            if len(self._cache) >= 32:
                self._cache.pop(next(iter(self._cache)))
            self._cache[key] = preview
            return preview

    def _build(self, aoi_geojson: dict) -> ScenePreview | None:
        try:
            bbox = padded_bbox(aoi_geojson)
            raw = self._download(esri_params(bbox, self._px))
            img = Image.open(io.BytesIO(raw)).convert("RGB")
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=self._quality, optimize=True)
        except Exception as exc:  # noqa: BLE001 - best-effort
            log.warning("high_res_preview.failed", error=str(exc)[:300])
            return None
        data_url = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode("ascii")
        # The request box IS the image extent: [[south, west], [north, east]].
        bounds = [[bbox[1], bbox[0]], [bbox[3], bbox[2]]]
        log.info("high_res_preview.built", width=img.width, height=img.height)
        return ScenePreview(data_url=data_url, bounds=bounds, source=ESRI_SOURCE)


class FallbackPreviewBuilder(ScenePreviewBuilder):
    """Try `primary`; if it gives nothing (or fails), try `fallback`."""

    def __init__(self, primary: ScenePreviewBuilder, fallback: ScenePreviewBuilder) -> None:
        self._primary = primary
        self._fallback = fallback

    def build(self, scene: SceneRef, aoi_geojson: dict) -> ScenePreview | None:
        try:
            preview = self._primary.build(scene, aoi_geojson)
        except Exception as exc:  # noqa: BLE001 - best-effort
            log.warning("preview.primary_failed", error=str(exc)[:300])
            preview = None
        if preview is not None:
            return preview
        return self._fallback.build(scene, aoi_geojson)
