"""
Fallback ImageryProvider reading the Sentinel-2 COG archive on the AWS Open Data
Registry (`sentinel-cogs`, public S3 bucket). Free to read from AWS compute in
the same region — no egress cost, useful when Planet Insights is degraded or its quota is used up.

This provider queries the Element84 Earth Search STAC API (which indexes the
same public bucket) rather than listing S3 directly, since STAC gives us the
same AOI/date/cloud-cover filtering Planet Insights offers.
"""
from __future__ import annotations

from datetime import datetime, timezone

import boto3
import httpx

from app.config import Settings
from app.domain.exceptions import ImageryFetchError
from app.domain.interfaces import ImageryProvider
from app.domain.models import DateRange, SceneRef
from app.logging_config import get_logger
from app.providers.common.http_errors import RETRYABLE_HTTP_STATUS, RetryableHTTPError
from app.providers.common.retry_policies import standard_retry

log = get_logger(__name__)

_EARTH_SEARCH_URL = "https://earth-search.aws.element84.com/v1/search"


class AWSOpenDataImageryProvider(ImageryProvider):
    """Alternate/fallback implementation demonstrating the provider-swap pattern
    from Section 2 — this is a full second `ImageryProvider`, not a branch inside
    PlanetInsightsImageryProvider."""

    def __init__(self, settings: Settings, http_client: httpx.Client | None = None) -> None:
        self._settings = settings
        self._http = http_client or httpx.Client(timeout=30.0)
        self._s3 = boto3.client("s3", region_name=settings.aws_region)

    @standard_retry(RetryableHTTPError)
    def _search_request(self, body: dict) -> dict:
        resp = self._http.post(_EARTH_SEARCH_URL, json=body)
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} from Earth Search STAC query")
        if resp.status_code != 200:
            raise ImageryFetchError(
                f"Earth Search STAC query failed: HTTP {resp.status_code}",
                upstream_status=resp.status_code,
                retryable=False,
            )
        return resp.json()

    def search(self, aoi_geojson: dict, date_range: DateRange) -> list[SceneRef]:
        body = {
            "collections": ["sentinel-2-l2a"],
            "intersects": aoi_geojson,
            "datetime": f"{date_range.start.isoformat()}/{date_range.end.isoformat()}",
            "query": {"eo:cloud_cover": {"lte": self._settings.cloud_cover_threshold_pct}},
            "limit": 50,
        }
        try:
            data = self._search_request(body)
        except RetryableHTTPError as exc:
            raise ImageryFetchError(
                f"Earth Search STAC query exhausted retries: {exc}", retryable=True
            ) from exc

        scenes = []
        for feature in data.get("features", []):
            props = feature.get("properties", {})
            assets = feature.get("assets", {})
            scenes.append(
                SceneRef(
                    scene_id=feature["id"],
                    collection="sentinel-2-l2a",
                    sensed_at=datetime.fromisoformat(
                        props["datetime"].replace("Z", "+00:00")
                    ).astimezone(timezone.utc),
                    cloud_cover_pct=props.get("eo:cloud_cover"),
                    provider="aws_open_data",
                    asset_urls={k: v.get("href", "") for k, v in assets.items()},
                )
            )
        return scenes

    # NOTE (fixed): this provider previously had NO retry at all on
    # fetch_bands — a transient network blip while downloading a band would
    # fail the whole run immediately, which is a worse resilience story than
    # the primary provider it's meant to be a fallback FOR. Now uses the
    # same retry-then-translate pattern as PlanetInsightsImageryProvider.
    @standard_retry(RetryableHTTPError)
    def _download(self, url: str) -> bytes:
        resp = self._http.get(url)
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} downloading {url}")
        if resp.status_code != 200:
            raise ImageryFetchError(
                f"Failed to download band from {url}: HTTP {resp.status_code}",
                upstream_status=resp.status_code,
            )
        return resp.content

    def fetch_bands(self, scene: SceneRef, bands: list[str]) -> dict[str, bytes]:
        result: dict[str, bytes] = {}
        for band in bands:
            url = scene.asset_urls.get(band)
            if not url:
                raise ImageryFetchError(f"Scene {scene.scene_id} has no asset named '{band}'")
            try:
                result[band] = self._download(url)
            except RetryableHTTPError as exc:
                raise ImageryFetchError(
                    f"Download of band '{band}' for scene {scene.scene_id} "
                    f"exhausted retries: {exc}",
                    retryable=True,
                ) from exc
        return result
