"""
SceneAnalyzer implementation built on rasterio/numpy.

This is the only class the scoring code needs to know about to get an NDVI
number; all the raster details stay in `raster_processing.py`.
"""
from __future__ import annotations

from app.domain.exceptions import ScoringError
from app.domain.interfaces import SceneAnalyzer
from app.providers.imagery.raster_processing import (
    apply_cropland_mask,
    array_mean_min_max,
    scene_ndvi_array,
)


class RasterSceneAnalyzer(SceneAnalyzer):
    def mean_ndvi(
        self,
        red_band: bytes,
        nir_band: bytes,
        aoi_geojson: dict,
        cropland_mask: bytes,
    ) -> float | None:
        ndvi, transform, crs = scene_ndvi_array(red_band, nir_band, aoi_geojson)
        masked = apply_cropland_mask(ndvi, cropland_mask, aoi_geojson, transform, crs)
        try:
            mean, _min, _max = array_mean_min_max(masked)
        except ScoringError:
            return None  # no usable pixels in this scene (e.g. tile edge)
        return mean
