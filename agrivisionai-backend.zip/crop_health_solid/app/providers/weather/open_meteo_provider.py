"""
Open-Meteo-backed WeatherForecastProvider — free, open-source, no API key
required. Fills the gap NASA POWER leaves (no forward-looking forecast).
"""
from __future__ import annotations

import httpx

from app.config import Settings
from app.domain.exceptions import WeatherDataError
from app.domain.geo_utils import polygon_centroid
from app.domain.interfaces import WeatherForecastProvider
from app.domain.models import FieldBoundary, WeatherForecast
from app.providers.common.http_errors import RETRYABLE_HTTP_STATUS, RetryableHTTPError
from app.providers.common.retry_policies import standard_retry

# Rainfall above this threshold in a single forecast day is flagged as adverse
# (heavy-rain / waterlogging risk) — tune per-region/crop in production.
_HEAVY_RAIN_MM_THRESHOLD = 50.0
_HEAT_STRESS_TEMP_C_THRESHOLD = 42.0


class OpenMeteoForecastProvider(WeatherForecastProvider):
    def __init__(self, settings: Settings, http_client: httpx.Client | None = None) -> None:
        self._settings = settings
        self._http = http_client or httpx.Client(timeout=30.0)

    # NOTE (fixed): previously `@retry(stop=..., wait=...)` with no `retry=`
    # filter, which retries on ANY exception including a permanent 4xx. Now
    # only retries on a RETRYABLE_HTTP_STATUS code.
    @standard_retry(RetryableHTTPError)
    def _request(self, params: dict) -> dict:
        resp = self._http.get(self._settings.open_meteo_base_url, params=params)
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} from Open-Meteo")
        if resp.status_code != 200:
            raise WeatherDataError(
                f"Open-Meteo request failed: HTTP {resp.status_code}",
                upstream_status=resp.status_code,
                retryable=False,
            )
        return resp.json()

    def get_forecast(self, field: FieldBoundary, days: int = 7) -> WeatherForecast:
        try:
            lon, lat = polygon_centroid(field.geojson_polygon)
        except ValueError as exc:
            raise WeatherDataError(str(exc), field_id=field.field_id) from exc

        # NOTE: requests both `temperature_2m_max` (drives the heat-stress
        # check below — that's genuinely what "stress" cares about) and
        # `temperature_2m_mean` (populates the actual "average" field) as two
        # distinct series — a max value silently mislabeled as an average was
        # a real bug caught in an earlier revalidation pass.
        try:
            body = self._request(
                {
                    "latitude": lat,
                    "longitude": lon,
                    "daily": "precipitation_sum,temperature_2m_max,temperature_2m_mean",
                    "forecast_days": days,
                    "timezone": "auto",
                }
            )
        except RetryableHTTPError as exc:
            raise WeatherDataError(
                f"Open-Meteo request exhausted retries: {exc}",
                field_id=field.field_id,
                retryable=True,
            ) from exc

        daily = body.get("daily", {})
        rainfall = daily.get("precipitation_sum", [])
        temps_max = daily.get("temperature_2m_max", [])
        temps_mean = daily.get("temperature_2m_mean", [])
        if not rainfall or not temps_max or not temps_mean:
            raise WeatherDataError("Open-Meteo response missing daily forecast", field_id=field.field_id)

        adverse = False
        reason = None
        if max(rainfall) >= _HEAVY_RAIN_MM_THRESHOLD:
            adverse, reason = True, f"heavy rainfall forecast ({max(rainfall):.0f}mm in one day)"
        elif max(temps_max) >= _HEAT_STRESS_TEMP_C_THRESHOLD:
            adverse, reason = True, f"heat stress forecast ({max(temps_max):.0f}\u00b0C)"

        return WeatherForecast(
            field_id=field.field_id,
            forecast_days=days,
            daily_rainfall_mm=rainfall,
            daily_avg_temp_c=temps_mean,
            adverse_weather_flag=adverse,
            adverse_weather_reason=reason,
        )
