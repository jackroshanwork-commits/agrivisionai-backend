"""
NASA POWER-backed WeatherHistoryProvider — free, public, no API key.
Historical/near-real-time only; see OpenMeteoForecastProvider for forecasts.
"""
from __future__ import annotations

import httpx

from app.config import Settings
from app.domain.exceptions import WeatherDataError
from app.domain.geo_utils import polygon_centroid
from app.domain.interfaces import WeatherHistoryProvider
from app.domain.models import DateRange, FieldBoundary, WeatherHistory
from app.providers.common.http_errors import RETRYABLE_HTTP_STATUS, RetryableHTTPError
from app.providers.common.retry_policies import standard_retry

# NASA POWER's documented sentinel value for a missing/invalid day (e.g. a
# satellite data gap) — must be filtered out before aggregating, or a single
# missing day can badly corrupt a sum()/mean() (see get_history() below).
_MISSING_SENTINEL = -999


class NASAPowerWeatherHistoryProvider(WeatherHistoryProvider):
    def __init__(self, settings: Settings, http_client: httpx.Client | None = None) -> None:
        self._settings = settings
        self._http = http_client or httpx.Client(timeout=30.0)

    # NOTE (fixed): previously `@retry(stop=..., wait=...)` with no `retry=`
    # filter, which retries on ANY exception including a permanent 4xx. Now
    # only retries on a RETRYABLE_HTTP_STATUS code.
    @standard_retry(RetryableHTTPError)
    def _request(self, params: dict) -> dict:
        resp = self._http.get(self._settings.nasa_power_base_url, params=params)
        if resp.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(f"HTTP {resp.status_code} from NASA POWER")
        if resp.status_code != 200:
            raise WeatherDataError(
                f"NASA POWER request failed: HTTP {resp.status_code}",
                upstream_status=resp.status_code,
                retryable=False,
            )
        return resp.json()

    def get_history(self, field: FieldBoundary, date_range: DateRange) -> WeatherHistory:
        try:
            lon, lat = polygon_centroid(field.geojson_polygon)
        except ValueError as exc:
            raise WeatherDataError(str(exc), field_id=field.field_id) from exc

        # NASA POWER's "AG" (agroclimatology) community bundles the parameters
        # most relevant to crop monitoring: PRECTOTCORR (bias-corrected
        # precipitation), T2M (2m air temp), GWETROOT (root-zone soil wetness,
        # used as our soil-moisture proxy).
        try:
            body = self._request(
                {
                    "parameters": "PRECTOTCORR,T2M,GWETROOT",
                    "community": "AG",
                    "longitude": lon,
                    "latitude": lat,
                    "start": date_range.start.strftime("%Y%m%d"),
                    "end": date_range.end.strftime("%Y%m%d"),
                    "format": "JSON",
                }
            )
        except RetryableHTTPError as exc:
            raise WeatherDataError(
                f"NASA POWER request exhausted retries: {exc}",
                field_id=field.field_id,
                retryable=True,
            ) from exc

        params = body.get("properties", {}).get("parameter", {})
        # NASA POWER returns a dict keyed by "YYYYMMDD" -> value for each
        # parameter; filter out the missing-data sentinel before aggregating
        # (see module-level comment on _MISSING_SENTINEL).
        rain_series = [v for v in params.get("PRECTOTCORR", {}).values() if v != _MISSING_SENTINEL]
        temp_series = [v for v in params.get("T2M", {}).values() if v != _MISSING_SENTINEL]
        soil_series = [v for v in params.get("GWETROOT", {}).values() if v != _MISSING_SENTINEL]

        if not rain_series or not temp_series:
            raise WeatherDataError(
                "NASA POWER response missing expected parameters",
                field_id=field.field_id,
            )

        return WeatherHistory(
            field_id=field.field_id,
            period_start=date_range.start,
            period_end=date_range.end,
            rainfall_mm_total=round(sum(rain_series), 2),
            avg_temp_c=round(sum(temp_series) / len(temp_series), 2),
            avg_soil_moisture_pct=(
                round(sum(soil_series) / len(soil_series) * 100, 2) if soil_series else None
            ),
        )
