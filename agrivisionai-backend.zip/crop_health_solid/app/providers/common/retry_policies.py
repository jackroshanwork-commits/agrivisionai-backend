"""
Shared retry-policy factory.

Before this module existed, every provider (Planet Insights, ESA WorldCover, NASA POWER,
Open-Meteo, Gemini, FCM, SNS) defined its own `@retry(...)` decorator inline,
each with slightly different but structurally identical tenacity
configuration (exponential-jitter backoff, a fixed attempt count, retry only
on a specific exception type). That's the kind of duplication where a real
bug can hide — see the token-fetch fix in this codebase's history, where
one of these inline decorators didn't actually cover the code path it was
meant to. Centralizing the *shape* of the policy here means every provider's
retry behavior is reviewed and tested once, not seven times.

Providers still choose their OWN numbers (attempt count, max wait) — a
slow-changing weather API and a rate-limited imagery API don't need the same
retry budget — but they all get that behavior from calling `retry_policy()`,
not from re-deriving the tenacity call every time.
"""
from __future__ import annotations

from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential_jitter,
)


def retry_policy(
    exception_types: type[Exception] | tuple[type[Exception], ...],
    *,
    max_attempts: int = 3,
    initial_wait_seconds: float = 1.0,
    max_wait_seconds: float = 10.0,
):
    """Returns a tenacity `@retry` decorator: exponential backoff with jitter,
    retrying only on `exception_types`, re-raising the original exception
    (not wrapping it in tenacity's own RetryError) once attempts are
    exhausted — so callers can keep catching their own specific exception
    types (e.g. `_RetryableHTTPError`) exactly as if there were no retry
    wrapper at all.

    Usage:
        @retry_policy(_RetryableHTTPError, max_attempts=4, max_wait_seconds=15)
        def _download(self, url: str) -> bytes:
            ...
    """
    return retry(
        retry=retry_if_exception_type(exception_types),
        stop=stop_after_attempt(max_attempts),
        wait=wait_exponential_jitter(initial=initial_wait_seconds, max=max_wait_seconds),
        reraise=True,
    )


# --- Named presets for the two most common call shapes in this codebase --- #
#
# Most providers fall into one of two buckets: a "standard" external API call
# (3 attempts, up to 10s backoff — NASA POWER, Open-Meteo, ESA WorldCover) or
# a "rate-limited" one that's known to need more patience (4 attempts, up to
# 15s — Planet Insights, which rate-limits per account). Using the same
# two presets by name (rather than each provider inventing its own numbers)
# also means a future tuning decision ("make Planet Insights retry more aggressively")
# is a one-line change here instead of a hunt across provider files.

def standard_retry(exception_types: type[Exception] | tuple[type[Exception], ...]):
    return retry_policy(exception_types, max_attempts=3, initial_wait_seconds=1, max_wait_seconds=10)


def rate_limited_retry(exception_types: type[Exception] | tuple[type[Exception], ...]):
    return retry_policy(exception_types, max_attempts=4, initial_wait_seconds=1, max_wait_seconds=15)
