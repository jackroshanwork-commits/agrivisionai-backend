"""
Shared "is this HTTP failure worth retrying" classification.

Every provider that makes a plain HTTP call (Planet Insights, AWS Open Data, ESA
WorldCover, NASA POWER, Open-Meteo) needs to distinguish a transient failure
(429 rate limit, 5xx server error — worth retrying) from a permanent one
(400 bad request, 401 bad credentials — retrying just wastes time before the
same failure). Centralized here so that distinction is made once and applied
consistently, rather than each provider file re-deciding which status codes
"feel" retryable.
"""
from __future__ import annotations

RETRYABLE_HTTP_STATUS = {429, 500, 502, 503, 504}


class RetryableHTTPError(Exception):
    """Raised internally by a provider when an HTTP response's status code is
    in RETRYABLE_HTTP_STATUS. Never crosses the provider's own boundary —
    each provider catches this itself (after tenacity's retries are
    exhausted, via `reraise=True`) and translates it into the appropriate
    terminal domain exception (ImageryFetchError, WeatherDataError, etc.)."""
