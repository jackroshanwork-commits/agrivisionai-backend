"""
FallbackReasoningProvider — "try the smart one, fall back to the safe one".

It IS a ReasoningProvider, so the job treats it exactly like Groq or the
rule-based provider (Liskov Substitution). The job never needs to know a
fallback exists.
"""
from __future__ import annotations

from app.domain.exceptions import CropHealthError
from app.domain.interfaces import ReasoningProvider
from app.domain.models import ReasoningInput, ReasoningResult
from app.logging_config import get_logger

log = get_logger(__name__)


class FallbackReasoningProvider(ReasoningProvider):
    def __init__(self, primary: ReasoningProvider, fallback: ReasoningProvider) -> None:
        self._primary = primary
        self._fallback = fallback

    def reason(self, reasoning_input: ReasoningInput) -> ReasoningResult:
        try:
            return self._primary.reason(reasoning_input)
        except CropHealthError as exc:
            log.warning(
                "reasoning.primary_failed_using_fallback",
                field_id=str(reasoning_input.field_id),
                provider=type(self._primary).__name__,
                error=exc.message,
            )
            return self._fallback.reason(reasoning_input)
