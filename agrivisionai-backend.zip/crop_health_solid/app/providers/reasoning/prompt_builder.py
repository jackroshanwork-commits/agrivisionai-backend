"""Builds the text prompt sent to the LLM. Pure function: no network, easy to test."""
from __future__ import annotations

from app.domain.models import ReasoningInput


def build_prompt(reasoning_input: ReasoningInput) -> str:

    hs = reasoning_input.health_score
    prev = reasoning_input.previous_health_score
    wf = reasoning_input.weather_forecast
    wh = reasoning_input.weather_history
    soil = reasoning_input.soil_health

    parts = [
        (
            "You are an agronomy assistant generating a short "
            "crop-health advisory for a smallholder farmer. "
            "Be concrete and actionable and avoid unnecessary jargon."
        ),
        (
            "Language for the farmer-facing message: "
            f"{reasoning_input.farmer_language}"
        ),
        (
            f"Current health score (0-100): {hs.health_score}, "
            f"NDVI mean: {hs.ndvi_mean:.3f}, "
            f"period {hs.period_start} to {hs.period_end}."
        ),
    ]

    if prev:
        parts.append(
            f"Previous period health score: {prev.health_score}."
        )

    if wh:
        parts.append(
            f"Recent rainfall total: {wh.rainfall_mm_total}mm, "
            f"avg temp: {wh.avg_temp_c}C, "
            f"soil moisture: {wh.avg_soil_moisture_pct}%."
        )

    if wf:
        parts.append(
            f"Forecast next {wf.forecast_days} days — "
            f"adverse weather flag: "
            f"{wf.adverse_weather_flag} "
            f"({wf.adverse_weather_reason or 'n/a'})."
        )

    if soil:
        parts.append(
            f"Soil: pH {soil.ph}, "
            f"N {soil.nitrogen_kg_ha}kg/ha, "
            f"P {soil.phosphorus_kg_ha}kg/ha, "
            f"K {soil.potassium_kg_ha}kg/ha."
        )

    parts.append(
        "Return ONLY valid JSON matching the provided schema. "
        "confidence must be a number between 0.0 and 1.0."
    )

    return "\n".join(parts)
