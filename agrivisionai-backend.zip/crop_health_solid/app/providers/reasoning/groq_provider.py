"""
Groq-backed ReasoningProvider.

Generates structured crop-health reasoning using the Groq API.
Falls back to the existing rule-based reasoning provider when Groq fails.
"""

from __future__ import annotations

import json

from app.providers.common.retry_policies import retry_policy

from app.config import Settings
from app.domain.exceptions import ReasoningCircuitOpenError, ReasoningError
from app.domain.interfaces import ReasoningProvider
from app.domain.models import ReasoningInput, ReasoningResult
from app.domain.reasoning_rules import determine_risk_level, should_notify
from app.logging_config import get_logger
from app.providers.reasoning.prompt_builder import build_prompt
from app.providers.reasoning.circuit_breaker import (
    CircuitBreaker,
    CircuitOpenError,
)

log = get_logger(__name__)


_RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "likely_cause": {
            "type": "string"
        },
        "recommended_action": {
            "type": "string"
        },
        "confidence": {
            "type": "number"
        },
        "message_farmer_language": {
            "type": "string"
        },
    },
    "required": [
        "likely_cause",
        "recommended_action",
        "confidence",
        "message_farmer_language",
    ],
    "additionalProperties": False,
}


class GroqReasoningProvider(ReasoningProvider):

    def __init__(self, settings: Settings, client=None) -> None:
        self._settings = settings

        self._breaker = CircuitBreaker(
            fail_max=settings.groq_circuit_breaker_fail_max,
            reset_timeout_seconds=(
                settings.groq_circuit_breaker_reset_timeout_seconds
            ),
        )

        # A fake client can be passed in tests; otherwise build the real one.
        self._client = client or self._build_client(settings)

    @staticmethod
    def _build_client(settings: Settings):
        from groq import Groq

        return Groq(
            api_key=settings.groq_api_key
        )

    @retry_policy(
        Exception,
        max_attempts=3,
        initial_wait_seconds=1,
        max_wait_seconds=8,
    )
    def _call_groq(self, prompt: str) -> dict:

        response = self._client.chat.completions.create(
            model=self._settings.groq_model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an expert agricultural crop-health "
                        "advisory assistant."
                    ),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            response_format={
                "type": "json_schema",
                "json_schema": {
                    "name": "crop_health_reasoning",
                    "strict": True,
                    "schema": _RESPONSE_SCHEMA,
                },
            },
        )

        content = response.choices[0].message.content

        if not content:
            raise ValueError(
                "Groq returned an empty response"
            )

        return json.loads(content)

    def reason(
        self,
        reasoning_input: ReasoningInput,
    ) -> ReasoningResult:

        try:
            self._breaker.guard()

        except CircuitOpenError as exc:

            log.warning(
                "groq.circuit_open",
                field_id=str(reasoning_input.field_id),
                breaker_state=self._breaker.state,
            )

            raise ReasoningCircuitOpenError(
                str(exc),
                field_id=reasoning_input.field_id,
                retryable=False,
            ) from exc

        prompt = build_prompt(reasoning_input)

        try:
            raw = self._call_groq(prompt)

            self._breaker.record_success()

        except Exception as exc:

            self._breaker.record_failure()

            log.error(
                "groq.call_failed",
                field_id=str(reasoning_input.field_id),
                error=str(exc),
                breaker_state=self._breaker.state,
            )

            raise ReasoningError(
                f"Groq call failed: {exc}",
                field_id=reasoning_input.field_id,
                retryable=True,
            ) from exc

        risk_level, _delta = determine_risk_level(
            reasoning_input.health_score,
            reasoning_input.previous_health_score,
            reasoning_input.weather_forecast,
            score_drop_threshold_pct=(
                self._settings.score_drop_threshold_pct
            ),
            critical_score_drop_threshold_pct=(
                self._settings.critical_score_drop_threshold_pct
            ),
        )

        try:
            confidence = float(raw["confidence"])

        except (KeyError, TypeError, ValueError) as exc:

            raise ReasoningError(
                f"Groq response missing/invalid confidence: {raw}",
                field_id=reasoning_input.field_id,
            ) from exc

        return ReasoningResult(
            field_id=reasoning_input.field_id,
            risk_level=risk_level,
            likely_cause=raw["likely_cause"],
            recommended_action=raw["recommended_action"],
            confidence=max(
                0.0,
                min(1.0, confidence),
            ),
            message_farmer_language=raw[
                "message_farmer_language"
            ],
            message_language_code=(
                reasoning_input.farmer_language
            ),
            generated_by="groq",
            should_notify=should_notify(risk_level),
        )
