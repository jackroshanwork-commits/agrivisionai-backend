"""
A small, dependency-free circuit breaker (Section 6: "Circuit breaker ... around
the Gemini call specifically, so a sustained LLM outage falls back to the
rule-based message immediately instead of retrying and delaying every job").

Deliberately not using a third-party circuit-breaker library — the state machine
needed here (closed -> open -> half-open) is ~40 lines and keeping it in-repo
avoids one more dependency for something this small. If the project later wants
distributed (multi-container) breaker state, swap this for `pybreaker` backed by
Redis/DynamoDB without changing the call site.
"""
from __future__ import annotations

import threading
import time
from enum import Enum


class _State(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitOpenError(Exception):
    """Raised by `CircuitBreaker.guard()` when the circuit is open."""


class CircuitBreaker:
    def __init__(self, fail_max: int, reset_timeout_seconds: int) -> None:
        self._fail_max = fail_max
        self._reset_timeout_seconds = reset_timeout_seconds
        self._state = _State.CLOSED
        self._fail_count = 0
        self._opened_at: float | None = None
        self._lock = threading.Lock()

    @property
    def state(self) -> str:
        return self._state.value

    def _maybe_half_open(self) -> None:
        if self._state == _State.OPEN and self._opened_at is not None:
            if time.monotonic() - self._opened_at >= self._reset_timeout_seconds:
                self._state = _State.HALF_OPEN

    def guard(self) -> None:
        """Call before attempting the protected operation. Raises CircuitOpenError
        if calls should currently be short-circuited."""
        with self._lock:
            self._maybe_half_open()
            if self._state == _State.OPEN:
                raise CircuitOpenError(
                    f"circuit open ({self._fail_count} consecutive failures); "
                    f"retry after {self._reset_timeout_seconds}s"
                )

    def record_success(self) -> None:
        with self._lock:
            self._fail_count = 0
            self._state = _State.CLOSED
            self._opened_at = None

    def record_failure(self) -> None:
        with self._lock:
            self._fail_count += 1
            if self._state == _State.HALF_OPEN or self._fail_count >= self._fail_max:
                self._state = _State.OPEN
                self._opened_at = time.monotonic()
