"""
Deterministic ReasoningProvider implementation. Used either:
  - directly, if `settings.reasoning_provider == "rule_based_only"` (e.g. local
    dev without a Gemini API key), or
  - as the fallback the job/worker calls when GeminiReasoningProvider raises
    ReasoningError / ReasoningCircuitOpenError.

Wrapping `build_rule_based_reasoning` behind the same ReasoningProvider interface
means the job layer can treat "primary" and "fallback" reasoning identically —
it just tries one provider, catches ReasoningError, and falls back to this one.
"""
from __future__ import annotations

from app.domain.interfaces import ReasoningProvider
from app.domain.models import ReasoningInput, ReasoningResult
from app.domain.reasoning_rules import build_rule_based_reasoning


class RuleBasedReasoningProvider(ReasoningProvider):
    def __init__(self, field_name_resolver=None) -> None:
        # Optional callable(field_id) -> str, for a nicer message; defaults to
        # a generic "Your field" if not supplied (e.g. in tests).
        self._field_name_resolver = field_name_resolver or (lambda field_id: "Your field")

    def reason(self, reasoning_input: ReasoningInput) -> ReasoningResult:
        field_name = self._field_name_resolver(reasoning_input.field_id)
        return build_rule_based_reasoning(
            health_score=reasoning_input.health_score,
            previous_health_score=reasoning_input.previous_health_score,
            weather_forecast=reasoning_input.weather_forecast,
            field_name=field_name,
            language_code=reasoning_input.farmer_language,
        )
