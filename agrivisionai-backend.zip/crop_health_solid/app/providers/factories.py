"""
The list of every provider this service knows how to build.

Each registered factory imports its provider lazily (inside the function), so
choosing `NOTIFICATION_PROVIDER=noop` never needs firebase-admin installed, and
choosing `rule_based_only` never needs the Groq SDK.
"""
from __future__ import annotations

from app.config import Settings
from app.domain.interfaces import (
    CroplandMaskProvider,
    ImageryProvider,
    NotificationProvider,
    ReasoningProvider,
    SoilHealthProvider,
    WeatherForecastProvider,
    WeatherHistoryProvider,
)
from app.providers.persistence.db import Database
from app.providers.registry import ProviderRegistry

imagery_registry: ProviderRegistry[ImageryProvider] = ProviderRegistry("imagery_provider")
cropland_mask_registry: ProviderRegistry[CroplandMaskProvider] = ProviderRegistry("cropland_mask_provider")
weather_history_registry: ProviderRegistry[WeatherHistoryProvider] = ProviderRegistry("weather_history_provider")
weather_forecast_registry: ProviderRegistry[WeatherForecastProvider] = ProviderRegistry("weather_provider")
soil_registry: ProviderRegistry[SoilHealthProvider] = ProviderRegistry("soil_provider")
reasoning_registry: ProviderRegistry[ReasoningProvider] = ProviderRegistry("reasoning_provider")
notification_registry: ProviderRegistry[NotificationProvider] = ProviderRegistry("notification_provider")


# --- imagery ----------------------------------------------------------- #

def _planet_insights(settings: Settings) -> ImageryProvider:
    from app.providers.imagery.planet_insights_provider import PlanetInsightsImageryProvider

    return PlanetInsightsImageryProvider(settings)


def _aws_open_data(settings: Settings) -> ImageryProvider:
    from app.providers.imagery.aws_open_data_provider import AWSOpenDataImageryProvider

    return AWSOpenDataImageryProvider(settings)


imagery_registry.register("planet_insights", _planet_insights)
imagery_registry.register("aws_open_data", _aws_open_data)


# --- cropland mask ------------------------------------------------------ #

def _worldcover(settings: Settings) -> CroplandMaskProvider:
    from app.providers.cropland_mask.worldcover_provider import ESAWorldCoverProvider

    return ESAWorldCoverProvider(settings)


cropland_mask_registry.register("esa_worldcover", _worldcover)


# --- weather ----------------------------------------------------------- #

def _nasa_power(settings: Settings) -> WeatherHistoryProvider:
    from app.providers.weather.nasa_power_provider import NASAPowerWeatherHistoryProvider

    return NASAPowerWeatherHistoryProvider(settings)


def _open_meteo(settings: Settings) -> WeatherForecastProvider:
    from app.providers.weather.open_meteo_provider import OpenMeteoForecastProvider

    return OpenMeteoForecastProvider(settings)


weather_history_registry.register("nasa_power", _nasa_power)
weather_forecast_registry.register("open_meteo", _open_meteo)


# --- soil -------------------------------------------------------------- #

def _database_soil(db: Database) -> SoilHealthProvider:
    from app.providers.persistence.soil_health_provider import DBSoilHealthProvider

    return DBSoilHealthProvider(db)


soil_registry.register("database", _database_soil)


# --- reasoning --------------------------------------------------------- #

def _groq(settings: Settings) -> ReasoningProvider:
    from app.providers.reasoning.groq_provider import GroqReasoningProvider

    return GroqReasoningProvider(settings)


def _rule_based(settings: Settings) -> ReasoningProvider:
    from app.providers.reasoning.rule_based_provider import RuleBasedReasoningProvider

    return RuleBasedReasoningProvider()


reasoning_registry.register("groq", _groq)
reasoning_registry.register("rule_based_only", _rule_based)


# --- notifications ----------------------------------------------------- #

def _fcm(settings: Settings) -> NotificationProvider:
    from app.providers.notification.fcm_provider import FCMNotificationProvider

    return FCMNotificationProvider(settings.fcm_service_account_json)


def _sns(settings: Settings) -> NotificationProvider:
    from app.providers.notification.sns_provider import SNSMobilePushNotificationProvider

    return SNSMobilePushNotificationProvider(settings.sns_platform_application_arn, settings.aws_region)


def _noop(settings: Settings) -> NotificationProvider:
    from app.providers.notification.noop_provider import NoOpNotificationProvider

    return NoOpNotificationProvider()


notification_registry.register("fcm", _fcm)
notification_registry.register("sns_mobile_push", _sns)
notification_registry.register("noop", _noop)
