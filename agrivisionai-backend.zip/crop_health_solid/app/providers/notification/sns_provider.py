"""
AWS SNS Mobile Push NotificationProvider — alternative to FCMNotificationProvider,
for teams that want push delivery to stay inside the same AWS SNS/Lambda stack
already built for OTP (Section 3 of the spec). SNS Mobile Push still ultimately
relays to FCM (or APNs) under the hood via a platform application endpoint.
"""
from __future__ import annotations

import json

import boto3
from botocore.exceptions import ClientError
from app.providers.common.retry_policies import retry_policy

from app.domain.exceptions import NotificationDeliveryError, StaleDeviceTokenError
from app.domain.interfaces import NotificationProvider
from app.domain.models import NotificationSendResult, PushNotificationPayload
from app.logging_config import get_logger

log = get_logger(__name__)

_STALE_ENDPOINT_ERRORS = {"EndpointDisabled", "InvalidParameter"}


class _RetryableSNSError(Exception):
    pass


class SNSMobilePushNotificationProvider(NotificationProvider):
    def __init__(self, platform_application_arn: str, region_name: str) -> None:
        self._platform_application_arn = platform_application_arn
        self._sns = boto3.client("sns", region_name=region_name)

    def _get_or_create_endpoint_arn(self, device_token: str) -> str:
        resp = self._sns.create_platform_endpoint(
            PlatformApplicationArn=self._platform_application_arn,
            Token=device_token,
        )
        return resp["EndpointArn"]

    @retry_policy(_RetryableSNSError, max_attempts=3, initial_wait_seconds=1, max_wait_seconds=8)
    def _publish(self, endpoint_arn: str, message: dict) -> str:
        try:
            resp = self._sns.publish(
                TargetArn=endpoint_arn,
                Message=json.dumps({"GCM": json.dumps(message)}),
                MessageStructure="json",
            )
            return resp["MessageId"]
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            if code in ("Throttling", "InternalError", "ServiceUnavailable"):
                raise _RetryableSNSError(str(exc)) from exc
            raise

    def send_push(
        self, device_token: str, payload: PushNotificationPayload
    ) -> NotificationSendResult:
        message = {
            "notification": {"title": payload.title, "body": payload.body},
            "data": {
                "field_id": str(payload.field_id),
                "risk_level": payload.risk_level.value,
                "deep_link": payload.deep_link,
                **payload.data,
            },
        }
        try:
            endpoint_arn = self._get_or_create_endpoint_arn(device_token)
            message_id = self._publish(endpoint_arn, message)
            return NotificationSendResult(
                farmer_id=payload.farmer_id,
                field_id=payload.field_id,
                delivered=True,
                provider_message_id=message_id,
            )
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            if code in _STALE_ENDPOINT_ERRORS:
                log.warning(
                    "sns.stale_token",
                    farmer_id=str(payload.farmer_id),
                    field_id=str(payload.field_id),
                    error_code=code,
                )
                return NotificationSendResult(
                    farmer_id=payload.farmer_id,
                    field_id=payload.field_id,
                    delivered=False,
                    stale_token=True,
                    error=code,
                )
            raise NotificationDeliveryError(
                f"SNS publish failed ({code}): {exc}", field_id=payload.field_id
            ) from exc
        except _RetryableSNSError as exc:
            raise NotificationDeliveryError(
                f"SNS publish exhausted retries: {exc}",
                field_id=payload.field_id,
                retryable=True,
            ) from exc
