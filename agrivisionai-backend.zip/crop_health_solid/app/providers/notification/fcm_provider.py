"""
Firebase Cloud Messaging (FCM) NotificationProvider — the default, since the
AgriVision app is Android-only on Play Store (Section 3 of the spec).

Stale-token handling: FCM's `UNREGISTERED` error means the token is dead — this
sets `stale_token=True` on the result rather than raising, so the caller (the
notification dispatcher) knows to deregister it instead of retrying the send.
"""
from __future__ import annotations

from app.providers.common.retry_policies import retry_policy

from app.domain.exceptions import NotificationDeliveryError, StaleDeviceTokenError
from app.domain.interfaces import NotificationProvider
from app.domain.models import NotificationSendResult, PushNotificationPayload
from app.logging_config import get_logger

log = get_logger(__name__)


class _RetryableFCMError(Exception):
    pass


class FCMNotificationProvider(NotificationProvider):
    def __init__(self, service_account_json: str) -> None:
        self._service_account_json = service_account_json
        self._app = self._init_app(service_account_json)

    @staticmethod
    def _init_app(service_account_json: str):
        # Lazy import: don't require firebase-admin just to import this module
        # (e.g. when running unit tests against the domain layer only).
        import json

        import firebase_admin  # type: ignore
        from firebase_admin import credentials  # type: ignore

        cred = credentials.Certificate(json.loads(service_account_json))
        try:
            return firebase_admin.get_app()
        except ValueError:
            return firebase_admin.initialize_app(cred)

    @retry_policy(_RetryableFCMError, max_attempts=3, initial_wait_seconds=1, max_wait_seconds=8)
    def _send(self, message):
        from firebase_admin import messaging  # type: ignore
        from firebase_admin.exceptions import (  # type: ignore
            InvalidArgumentError,
            UnavailableError,
        )

        try:
            return messaging.send(message)
        except UnavailableError as exc:
            raise _RetryableFCMError(str(exc)) from exc
        except InvalidArgumentError:
            raise  # unregistered/invalid token — not retryable, handled by caller

    def send_push(
        self, device_token: str, payload: PushNotificationPayload
    ) -> NotificationSendResult:
        from firebase_admin import messaging  # type: ignore
        from firebase_admin.exceptions import InvalidArgumentError  # type: ignore
        from firebase_admin.messaging import UnregisteredError  # type: ignore

        message = messaging.Message(
            token=device_token,
            notification=messaging.Notification(title=payload.title, body=payload.body),
            data={
                "field_id": str(payload.field_id),
                "risk_level": payload.risk_level.value,
                "deep_link": payload.deep_link,
                **payload.data,
            },
        )
        try:
            message_id = self._send(message)
            return NotificationSendResult(
                farmer_id=payload.farmer_id,
                field_id=payload.field_id,
                delivered=True,
                provider_message_id=message_id,
            )
        except UnregisteredError:
            log.warning(
                "fcm.stale_token",
                farmer_id=str(payload.farmer_id),
                field_id=str(payload.field_id),
            )
            return NotificationSendResult(
                farmer_id=payload.farmer_id,
                field_id=payload.field_id,
                delivered=False,
                stale_token=True,
                error="unregistered_token",
            )
        except InvalidArgumentError as exc:
            raise StaleDeviceTokenError(
                f"FCM rejected token as invalid: {exc}", field_id=payload.field_id
            ) from exc
        except _RetryableFCMError as exc:
            raise NotificationDeliveryError(
                f"FCM send exhausted retries: {exc}",
                field_id=payload.field_id,
                retryable=True,
            ) from exc
