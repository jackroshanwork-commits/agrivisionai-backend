"""
No-op NotificationProvider — logs what *would* have been sent instead of
actually calling FCM/SNS.

Added because `FCMNotificationProvider.__init__` calls `json.loads(...)` on
the service-account JSON immediately at construction time — with the empty
default in `.env.example`, selecting `NOTIFICATION_PROVIDER=fcm` without real
credentials configured would crash the whole app at startup (in
`build_providers()`, called from FastAPI's lifespan / every Lambda's
module-level init). `ReasoningProvider` already had this safety valve
(`rule_based_only`); `NotificationProvider` didn't, until now. This is the
default in `.env.example` for exactly that reason — local dev and tests
should never need real push credentials just to boot the app.
"""
from __future__ import annotations

from app.domain.interfaces import NotificationProvider
from app.domain.models import NotificationSendResult, PushNotificationPayload
from app.logging_config import get_logger

log = get_logger(__name__)


class NoOpNotificationProvider(NotificationProvider):
    def send_push(
        self, device_token: str, payload: PushNotificationPayload
    ) -> NotificationSendResult:
        log.info(
            "notification.noop_send",
            farmer_id=str(payload.farmer_id),
            field_id=str(payload.field_id),
            title=payload.title,
            risk_level=payload.risk_level.value,
        )
        return NotificationSendResult(
            farmer_id=payload.farmer_id,
            field_id=payload.field_id,
            delivered=True,
            provider_message_id="noop",
        )
