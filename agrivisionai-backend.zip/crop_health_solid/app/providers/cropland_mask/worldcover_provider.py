"""
ESA WorldCover-backed CroplandMaskProvider.

Fetches the ESA WorldCover 2021 10m land-cover raster
through the Terrascope WMS service.
"""

from __future__ import annotations

import httpx

from app.config import Settings
from app.domain.exceptions import CroplandMaskError
from app.domain.geo_utils import bounding_box
from app.domain.interfaces import CroplandMaskProvider
from app.providers.common.http_errors import (
    RETRYABLE_HTTP_STATUS,
    RetryableHTTPError,
)
from app.providers.common.retry_policies import standard_retry


# Terrascope WMS endpoint.
_WORLDCOVER_WMS_BASE = "https://titiler.terrascope.be/wms"

# ESA WorldCover 2021 layer.
_WORLDCOVER_LAYER = "esa-worldcover-map-10m-2021-v2_map"

# ESA WorldCover 2021 time dimension.
_WORLDCOVER_TIME = "2021-01-01"


class ESAWorldCoverProvider(CroplandMaskProvider):
    def __init__(
        self,
        settings: Settings,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._settings = settings

        self._http = http_client or httpx.Client(
            timeout=30.0,
            http2=False,
            follow_redirects=True,
        )

    @property
    def source_name(self) -> str:
        return "esa_worldcover_2021"

    @standard_retry(RetryableHTTPError)
    def _request_map(self, params: dict) -> bytes:
        try:
            response = self._http.get(
                _WORLDCOVER_WMS_BASE,
                params=params,
            )

        except httpx.HTTPError as exc:
            raise RetryableHTTPError(
                f"WorldCover WMS connection failed: {exc}"
            ) from exc

        if response.status_code in RETRYABLE_HTTP_STATUS:
            raise RetryableHTTPError(
                f"HTTP {response.status_code} from WorldCover WMS"
            )

        if response.status_code != 200:
            raise CroplandMaskError(
                "WorldCover WMS request failed: "
                f"HTTP {response.status_code}: "
                f"{response.text[:500]}",
                upstream_status=response.status_code,
                retryable=False,
            )

        return response.content

    def get_mask(self, aoi_geojson: dict) -> bytes:
        try:
            min_lon, min_lat, max_lon, max_lat = bounding_box(
                aoi_geojson
            )

        except ValueError as exc:
            raise CroplandMaskError(str(exc)) from exc

        # WMS 1.3.0 with EPSG:4326 uses latitude,longitude
        # axis order.
        bbox = (
            f"{min_lat},{min_lon},"
            f"{max_lat},{max_lon}"
        )

        params = {
            "SERVICE": "WMS",
            "VERSION": "1.3.0",
            "REQUEST": "GetMap",
            "LAYERS": _WORLDCOVER_LAYER,
            "STYLES": "",
            "TIME": _WORLDCOVER_TIME,
            "CRS": "EPSG:4326",
            "BBOX": bbox,
            "WIDTH": 512,
            "HEIGHT": 512,
            "FORMAT": "image/tiff; application=geotiff",
        }

        try:
            return self._request_map(params)

        except RetryableHTTPError as exc:
            raise CroplandMaskError(
                f"WorldCover WMS request exhausted retries: {exc}",
                retryable=True,
            ) from exc
