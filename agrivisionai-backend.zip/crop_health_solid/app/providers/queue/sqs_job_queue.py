"""SQS implementation of the JobQueue port."""
from __future__ import annotations

from app.domain.exceptions import JobEnqueueError
from app.domain.interfaces import JobQueue
from app.domain.models import CropHealthJobRequest


class SqsJobQueue(JobQueue):
    def __init__(self, queue_url: str, region_name: str, client=None) -> None:
        import boto3  # imported here so unit tests don't need AWS libraries

        self._queue_url = queue_url
        self._sqs = client or boto3.client("sqs", region_name=region_name)

    def enqueue(self, request: CropHealthJobRequest) -> None:
        try:
            self._sqs.send_message(
                QueueUrl=self._queue_url,
                MessageBody=request.model_dump_json(),
                MessageAttributes={
                    # The worker restores this into the logging context so one
                    # job's whole trace can be searched by a single ID.
                    "correlation_id": {"DataType": "String", "StringValue": str(request.job_id)}
                },
            )
        except Exception as exc:  # noqa: BLE001 - translate into our own error type
            raise JobEnqueueError(
                f"Could not queue job {request.job_id}: {exc}",
                field_id=request.field_id,
                job_id=request.job_id,
                retryable=True,
            ) from exc
