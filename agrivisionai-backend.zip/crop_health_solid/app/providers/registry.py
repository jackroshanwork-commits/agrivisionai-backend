"""
ProviderRegistry: a name -> factory lookup table.

This is how we follow the Open/Closed Principle: to add a new provider you
WRITE a new class and REGISTER it. You never edit an `if/elif` ladder, and no
existing provider code changes.

    imagery_registry.register("sentinel_hub", lambda settings: SentinelHubProvider(settings))

then set  IMAGERY_PROVIDER=sentinel_hub  in the environment.
"""
from __future__ import annotations

from typing import Any, Callable, Generic, TypeVar

T = TypeVar("T")


class ProviderRegistry(Generic[T]):
    def __init__(self, kind: str) -> None:
        self._kind = kind  # only used in error messages, e.g. "imagery_provider"
        self._factories: dict[str, Callable[..., T]] = {}

    def register(self, name: str, factory: Callable[..., T]) -> None:
        self._factories[name] = factory

    def create(self, name: str, *args: Any) -> T:
        try:
            factory = self._factories[name]
        except KeyError:
            # Fail fast and loudly on a typo, rather than silently using a default.
            allowed = ", ".join(sorted(self._factories)) or "(none registered)"
            raise ValueError(f"Unknown {self._kind}: {name!r}. Choose one of: {allowed}") from None
        return factory(*args)

    @property
    def names(self) -> list[str]:
        return sorted(self._factories)
