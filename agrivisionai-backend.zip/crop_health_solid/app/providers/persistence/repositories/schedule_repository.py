"""Schedule-config persistence — what `ScheduleDispatcher` reads to decide
which fields are due, and writes back to after enqueuing each one."""
from __future__ import annotations

import uuid
from datetime import datetime

from app.domain.interfaces import ScheduleRepository
from app.domain.models import ScheduleConfig
from app.providers.persistence.db import Database
from app.providers.persistence.models_orm import ScheduleORM


class SqlScheduleRepository(ScheduleRepository):
    def __init__(self, db: Database) -> None:
        self._db = db

    def get_due_schedules(self, as_of: datetime) -> list[ScheduleConfig]:
        with self._db.session() as session:
            rows = (
                session.query(ScheduleORM)
                .filter(ScheduleORM.enabled.is_(True))
                .filter(
                    (ScheduleORM.next_due_at.is_(None)) | (ScheduleORM.next_due_at <= as_of)
                )
                .all()
            )
            return [
                ScheduleConfig(
                    field_id=r.field_id,
                    cron_expression=r.cron_expression,
                    enabled=r.enabled,
                    next_due_at=r.next_due_at,
                )
                for r in rows
            ]

    def mark_schedule_run(self, field_id: uuid.UUID, next_due_at: datetime) -> None:
        with self._db.session() as session:
            row = session.query(ScheduleORM).filter_by(field_id=field_id).one_or_none()
            if row:
                row.next_due_at = next_due_at
