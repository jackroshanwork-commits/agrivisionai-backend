"""SQL implementation of the FieldRepository port: field lookup, creation and
the tier-gate check."""
from __future__ import annotations

import uuid

from app.domain.exceptions import FieldNotFoundError, TierNotEntitledError
from app.domain.interfaces import FieldRepository
from app.domain.models import FieldBoundary, SubscriptionTier
from app.providers.persistence.db import Database
from app.providers.persistence.models_orm import FieldORM

# Tier gate (Section 8, item 5): crop-health monitoring is a paid-tier feature.
_ENTITLED_TIERS = {SubscriptionTier.KISAN_PLUS, SubscriptionTier.FPO_ENTERPRISE}


class SqlFieldRepository(FieldRepository):
    def __init__(self, db: Database) -> None:
        self._db = db

    def get_field(self, field_id: uuid.UUID) -> FieldBoundary:
        with self._db.session() as session:
            row = session.get(FieldORM, field_id)
            if row is None:
                raise FieldNotFoundError(f"Field {field_id} not found", field_id=field_id)
            return FieldBoundary(
                field_id=row.field_id,
                farmer_id=row.farmer_id,
                fpo_id=row.fpo_id,
                name=row.name,
                geojson_polygon=row.geojson_polygon,
                subscription_tier=SubscriptionTier(row.subscription_tier),
            )

    def assert_entitled(self, field: FieldBoundary) -> None:
        """Tier gate: raises TierNotEntitledError if the field's account isn't on
        a paid tier that includes crop-health monitoring."""
        if field.subscription_tier not in _ENTITLED_TIERS:
            raise TierNotEntitledError(
                f"Field {field.field_id} is on tier '{field.subscription_tier.value}', "
                "which does not include crop-health monitoring",
                field_id=field.field_id,
            )

    def create_field(
        self,
        *,
        name: str,
        geojson_polygon: dict,
        farmer_id: uuid.UUID,
        subscription_tier: SubscriptionTier,
        fpo_id: uuid.UUID | None = None,
    ) -> FieldBoundary:
        row = FieldORM(
            field_id=uuid.uuid4(),
            farmer_id=farmer_id,
            fpo_id=fpo_id,
            name=name,
            geojson_polygon=geojson_polygon,
            subscription_tier=subscription_tier.value,
        )
        with self._db.session() as session:
            session.add(row)
        return FieldBoundary(
            field_id=row.field_id,
            farmer_id=row.farmer_id,
            fpo_id=row.fpo_id,
            name=row.name,
            geojson_polygon=row.geojson_polygon,
            subscription_tier=subscription_tier,
        )
