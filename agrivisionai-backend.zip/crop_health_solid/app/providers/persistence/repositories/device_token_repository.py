"""Device-token persistence for push notifications — lookup for sending, and
deregistration when a provider reports a token as stale (Section 3: "handle
stale-token cleanup ... deregister on that response instead of retrying")."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from app.domain.interfaces import DeviceTokenRepository
from app.providers.persistence.db import Database
from app.providers.persistence.models_orm import DeviceTokenORM


class SqlDeviceTokenRepository(DeviceTokenRepository):
    def __init__(self, db: Database) -> None:
        self._db = db

    def get_active_device_token(self, farmer_id: uuid.UUID) -> str | None:
        with self._db.session() as session:
            row = (
                session.query(DeviceTokenORM)
                .filter_by(farmer_id=farmer_id, active=True)
                .order_by(DeviceTokenORM.registered_at.desc())
                .first()
            )
            return row.device_token if row else None

    def deregister_device_token(self, farmer_id: uuid.UUID, device_token: str) -> None:
        with self._db.session() as session:
            row = (
                session.query(DeviceTokenORM)
                .filter_by(farmer_id=farmer_id, device_token=device_token, active=True)
                .one_or_none()
            )
            if row:
                row.active = False
                row.deregistered_at = datetime.now(timezone.utc)
