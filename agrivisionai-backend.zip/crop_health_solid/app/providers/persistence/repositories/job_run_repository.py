"""Job-run persistence: the idempotency check, the RUNNING->SUCCEEDED/FAILED
transition, and the "last successful result" lookup that powers graceful
degradation (Section 7). This is the busiest of the split-out repositories
since job-run bookkeeping is the most stateful part of the pipeline."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from app.domain.interfaces import JobRunRepository
from app.domain.models import JobStatus
from app.providers.persistence.db import Database
from app.providers.persistence.models_orm import JobRunORM


class SqlJobRunRepository(JobRunRepository):
    def __init__(self, db: Database) -> None:
        self._db = db

    def create_job_run(
        self,
        job_id: uuid.UUID,
        field_id: uuid.UUID,
        trigger_source: str,
        period_start: date,
        period_end: date,
    ) -> None:
        with self._db.session() as session:
            session.add(
                JobRunORM(
                    job_id=job_id,
                    field_id=field_id,
                    status=JobStatus.RUNNING.value,
                    trigger_source=trigger_source,
                    period_start=period_start,
                    period_end=period_end,
                    started_at=datetime.now(timezone.utc),
                )
            )

    def is_duplicate_job(self, field_id: uuid.UUID, period_start: date, period_end: date) -> bool:
        """Idempotency check (Section 7): has this field/period already succeeded?"""
        with self._db.session() as session:
            existing = (
                session.query(JobRunORM)
                .filter_by(field_id=field_id, period_start=period_start, period_end=period_end)
                .filter(JobRunORM.status == JobStatus.SUCCEEDED.value)
                .first()
            )
            return existing is not None

    def complete_job_run(
        self, job_id: uuid.UUID, status: JobStatus, result_json: dict | None, error: str | None
    ) -> None:
        with self._db.session() as session:
            row = session.get(JobRunORM, job_id)
            if row is None:
                return
            row.status = status.value
            row.result_json = result_json
            row.error = error
            row.finished_at = datetime.now(timezone.utc)
            if result_json and result_json.get("health_score"):
                row.health_score = result_json["health_score"].get("health_score")

    def get_last_successful_result(self, field_id: uuid.UUID) -> dict | None:
        """Used for graceful degradation (Section 7): serve the last successful
        score when the current run fails after retries."""
        with self._db.session() as session:
            row = (
                session.query(JobRunORM)
                .filter_by(field_id=field_id, status=JobStatus.SUCCEEDED.value)
                .order_by(JobRunORM.finished_at.desc())
                .first()
            )
            return row.result_json if row else None

    def get_job_run(self, job_id: uuid.UUID) -> dict | None:
        with self._db.session() as session:
            row = session.get(JobRunORM, job_id)
            if row is None:
                return None
            return {
                "job_id": row.job_id,
                "field_id": row.field_id,
                "status": row.status,
                "result_json": row.result_json,
                "error": row.error,
                "started_at": row.started_at,
                "finished_at": row.finished_at,
            }

    def fail_stale_runs(self, reason: str) -> int:
        with self._db.session() as session:
            rows = session.query(JobRunORM).filter(JobRunORM.status == JobStatus.RUNNING.value).all()
            for row in rows:
                row.status = JobStatus.FAILED.value
                row.error = reason
                row.finished_at = datetime.now(timezone.utc)
            return len(rows)
