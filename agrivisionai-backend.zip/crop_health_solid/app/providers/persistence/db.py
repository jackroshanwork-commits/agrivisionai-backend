"""
SQLAlchemy engine/session. Points at the same `agrivisionai-prod-db` pattern
(ap-south-1) the rest of AgriVision's stack already uses — see Section 1 of the
spec ("reuse `agrivisionai-prod-db`, `ap-south-1` schema pattern if applicable").
"""
from __future__ import annotations

from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import Settings


class Database:
    def __init__(self, settings: Settings) -> None:
        self._engine = create_engine(settings.database_url, pool_pre_ping=True, future=True)
        self._SessionLocal = sessionmaker(bind=self._engine, expire_on_commit=False, future=True)

    @contextmanager
    def session(self):
        session: Session = self._SessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    @property
    def engine(self):
        return self._engine
