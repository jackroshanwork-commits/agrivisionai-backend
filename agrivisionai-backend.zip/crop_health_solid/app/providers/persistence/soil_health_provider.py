"""
SoilHealthProvider implementation that reads AgriVision's existing soil-health
table (read-only from this service's side) — no separate soil pipeline.
"""
from __future__ import annotations

import uuid

from app.domain.interfaces import SoilHealthProvider
from app.domain.models import SoilHealth
from app.providers.persistence.db import Database
from app.providers.persistence.models_orm import SoilHealthORM


class DBSoilHealthProvider(SoilHealthProvider):
    def __init__(self, db: Database) -> None:
        self._db = db

    def get_latest(self, field_id: uuid.UUID) -> SoilHealth | None:
        with self._db.session() as session:
            row = (
                session.query(SoilHealthORM)
                .filter_by(field_id=field_id)
                .order_by(SoilHealthORM.recorded_at.desc())
                .first()
            )
            if row is None:
                return None
            return SoilHealth(
                field_id=row.field_id,
                ph=row.ph,
                nitrogen_kg_ha=row.nitrogen_kg_ha,
                phosphorus_kg_ha=row.phosphorus_kg_ha,
                potassium_kg_ha=row.potassium_kg_ha,
                organic_carbon_pct=row.organic_carbon_pct,
                recorded_at=row.recorded_at,
            )
