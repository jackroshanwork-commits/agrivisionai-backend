"""
Writes the job's user-facing outputs: NDVI/health-score tiles to S3 (served via
CloudFront), and the per-field Excel summary report (Section 1 of the spec).
"""
from __future__ import annotations

import io
import uuid

import boto3
import pandas as pd
from botocore.exceptions import ClientError

from app.config import Settings
from app.domain.exceptions import OutputStorageError
from app.domain.models import HealthScoreResult


class OutputsStorage:
    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._s3 = boto3.client("s3", region_name=settings.aws_region)

    def _cdn_url(self, bucket: str, key: str) -> str:
        if self._settings.tiles_cloudfront_domain:
            return f"https://{self._settings.tiles_cloudfront_domain}/{key}"
        return f"s3://{bucket}/{key}"

    def upload_tile(self, field_id: uuid.UUID, kind: str, geotiff_bytes: bytes, period_start) -> str:
        """kind is 'ndvi' or 'health_score'. Returns the CDN/S3 URL."""
        key = f"tiles/{field_id}/{period_start.isoformat()}/{kind}.tif"
        try:
            self._s3.put_object(
                Bucket=self._settings.tiles_bucket,
                Key=key,
                Body=geotiff_bytes,
                ContentType="image/tiff",
            )
        except ClientError as exc:
            raise OutputStorageError(
                f"Failed to upload {kind} tile for field {field_id}: {exc}",
                field_id=field_id,
            ) from exc
        return self._cdn_url(self._settings.tiles_bucket, key)

    def write_excel_report(
        self, field_id: uuid.UUID, history: list[HealthScoreResult]
    ) -> str:
        """Writes a per-field monthly summary workbook to S3, returns the S3 URL."""
        rows = [
            {
                "period_start": h.period_start,
                "period_end": h.period_end,
                "health_score": h.health_score,
                "ndvi_mean": h.ndvi_mean,
                "ndvi_min": h.ndvi_min,
                "ndvi_max": h.ndvi_max,
                "cloud_cover_pct": h.cloud_cover_pct,
                "cropland_mask_source": h.cropland_mask_source,
            }
            for h in history
        ]
        df = pd.DataFrame(rows)
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
            df.to_excel(writer, sheet_name="Monthly Health Score", index=False)

        key = f"reports/{field_id}/crop_health_report.xlsx"
        try:
            self._s3.put_object(
                Bucket=self._settings.reports_bucket,
                Key=key,
                Body=buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        except ClientError as exc:
            raise OutputStorageError(
                f"Failed to upload Excel report for field {field_id}: {exc}",
                field_id=field_id,
            ) from exc
        return f"s3://{self._settings.reports_bucket}/{key}"
