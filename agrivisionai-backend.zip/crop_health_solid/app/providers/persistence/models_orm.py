"""
SQLAlchemy ORM models. Kept separate from `app/domain/models/` (the Pydantic
DTOs) on purpose — the ORM layer is a persistence concern, not something the
domain/job logic should import directly. `repository.py` translates between
the two.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class FieldORM(Base):
    __tablename__ = "fields"

    field_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    farmer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    fpo_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    geojson_polygon: Mapped[dict] = mapped_column(JSONB, nullable=False)
    subscription_tier: Mapped[str] = mapped_column(String(30), nullable=False, default="free")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class ScheduleORM(Base):
    __tablename__ = "schedules"
    __table_args__ = (UniqueConstraint("field_id", name="uq_schedule_field"),)

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    field_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("fields.field_id"), nullable=False)
    cron_expression: Mapped[str] = mapped_column(String(100), nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    next_due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    eventbridge_schedule_arn: Mapped[str | None] = mapped_column(String(300), nullable=True)


class JobRunORM(Base):
    __tablename__ = "job_runs"

    job_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    field_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("fields.field_id"), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    trigger_source: Mapped[str] = mapped_column(String(20), nullable=False)
    # NOTE (fixed): these are calendar dates (matches domain.models.DateRange,
    # which is `date`, not `datetime`). Previously typed as `DateTime` here,
    # so every insert silently coerced a `date` into a midnight timestamp —
    # that happens to work via implicit cast in Postgres, but made the
    # is_duplicate_job() equality check fragile (a `date` and a `datetime` at
    # midnight aren't guaranteed to compare equal across every driver). Using
    # `Date` here matches the domain type exactly, no implicit coercion.
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    health_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    result_json: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DeviceTokenORM(Base):
    __tablename__ = "device_tokens"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    farmer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    device_token: Mapped[str] = mapped_column(String(500), nullable=False)
    platform: Mapped[str] = mapped_column(String(20), nullable=False, default="android")
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    registered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    deregistered_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class SoilHealthORM(Base):
    """Mirrors the record shape AgriVision's existing soil-health module already
    persists — reused here rather than rebuilt, per Section 1 of the spec."""

    __tablename__ = "soil_health_readings"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    field_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("fields.field_id"), nullable=False, index=True)
    ph: Mapped[float | None] = mapped_column(Float, nullable=True)
    nitrogen_kg_ha: Mapped[float | None] = mapped_column(Float, nullable=True)
    phosphorus_kg_ha: Mapped[float | None] = mapped_column(Float, nullable=True)
    potassium_kg_ha: Mapped[float | None] = mapped_column(Float, nullable=True)
    organic_carbon_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
