"""
Small geometry helpers shared across providers that need to turn a GeoJSON
AOI into a bounding box or centroid (cropland mask WMS request, weather API
lat/lon lookup, etc.).

Moved here from being a "private" (leading-underscore) helper inside the
ESA WorldCover provider that two unrelated weather providers were importing
directly — that's a layering violation (providers reaching into another
provider's internals) and the underscore was actively misleading about
whether it was meant to be reused. This is pure geometry math with no I/O,
so it belongs in `domain/`, not tucked inside one specific adapter.
"""
from __future__ import annotations


def flatten_coordinates(coords) -> list[list[float]]:
    """Flatten arbitrarily nested Polygon/MultiPolygon coordinate arrays
    (GeoJSON allows several levels of nesting depending on geometry type)
    into a flat list of [lon, lat] pairs.

    Example: a Polygon's `coordinates` is `[[[lon, lat], [lon, lat], ...]]`
    (one extra level of nesting for the "rings" — exterior + holes); a
    MultiPolygon adds one more level on top of that. Rather than assume a
    fixed nesting depth (which breaks the moment someone passes a
    MultiPolygon), this walks the structure recursively until it hits pairs
    of numbers.
    """
    flat: list[list[float]] = []

    def _walk(node):
        if isinstance(node, (int, float)):
            return  # a bare number — shouldn't happen at this level, ignore
        if node and isinstance(node[0], (int, float)):
            # This node is itself a [lon, lat] pair — the base case.
            flat.append(list(node))
            return
        for child in node:
            _walk(child)

    _walk(coords)
    return flat


def polygon_centroid(aoi_geojson: dict) -> tuple[float, float]:
    """Simple vertex-average centroid: (lon, lat).

    This is NOT the true geometric (area-weighted) centroid of the polygon —
    for a convex, roughly-square field boundary (the common case for a
    farmer-drawn field) the difference is negligible for the purpose this is
    used for (picking a representative point for a weather-API lookup, where
    weather grids are typically ~1-10km resolution anyway). If field
    boundaries become highly irregular/concave, swap this for `shapely`'s
    `Polygon(...).centroid`, which is already a project dependency.
    """
    pts = flatten_coordinates(aoi_geojson.get("coordinates", []))
    if not pts:
        raise ValueError("Cannot compute centroid — GeoJSON has no coordinates")
    lon = sum(p[0] for p in pts) / len(pts)
    lat = sum(p[1] for p in pts) / len(pts)
    return lon, lat


def bounding_box(aoi_geojson: dict) -> tuple[float, float, float, float]:
    """Returns (min_lon, min_lat, max_lon, max_lat) — used for WMS GetMap
    requests, which take a flat bbox rather than a full polygon geometry."""
    pts = flatten_coordinates(aoi_geojson.get("coordinates", []))
    if not pts:
        raise ValueError("Cannot compute bounding box — GeoJSON has no coordinates")
    lons = [p[0] for p in pts]
    lats = [p[1] for p in pts]
    return min(lons), min(lats), max(lons), max(lats)
