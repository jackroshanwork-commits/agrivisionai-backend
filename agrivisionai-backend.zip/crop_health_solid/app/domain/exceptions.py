"""
Custom exception hierarchy (Section 6: "don't let raw provider exceptions ...
leak past the provider boundary").

Every provider implementation must catch its own SDK/HTTP exceptions and re-raise
one of these, with enough context (field_id, job_id, upstream status) to log
usefully and to map cleanly onto an HTTP error response or a job-status value.
"""
from __future__ import annotations

import uuid
from typing import Optional


class CropHealthError(Exception):
    """Base class for every error this service raises across layer boundaries."""

    #: default value used when mapping to an HTTP response in the API layer
    http_status_code: int = 500

    def __init__(
        self,
        message: str,
        *,
        field_id: Optional[uuid.UUID] = None,
        job_id: Optional[uuid.UUID] = None,
        upstream_status: Optional[int] = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.field_id = field_id
        self.job_id = job_id
        self.upstream_status = upstream_status
        self.retryable = retryable

    def to_log_context(self) -> dict:
        """Structured fields for the JSON logger — never includes secrets/PII."""
        return {
            "error_type": type(self).__name__,
            "message": self.message,
            "field_id": str(self.field_id) if self.field_id else None,
            "job_id": str(self.job_id) if self.job_id else None,
            "upstream_status": self.upstream_status,
            "retryable": self.retryable,
        }


class ImageryFetchError(CropHealthError):
    """Raised by ImageryProvider implementations on search/fetch failure."""

    http_status_code = 502


class CroplandMaskError(CropHealthError):
    """Raised by CroplandMaskProvider implementations."""

    http_status_code = 502


class WeatherDataError(CropHealthError):
    """Raised by WeatherProvider implementations (NASA POWER / Open-Meteo)."""

    http_status_code = 502


class ScoringError(CropHealthError):
    """Raised when NDVI/health-score computation fails on otherwise-valid inputs."""

    http_status_code = 500


class ReasoningError(CropHealthError):
    """Raised by the LLM reasoning provider (Gemini) or the rule-based fallback."""

    http_status_code = 502


class ReasoningCircuitOpenError(ReasoningError):
    """Raised when the Gemini circuit breaker is open — caller should use the
    rule-based fallback immediately rather than attempting a call."""

    retryable = False


class NotificationDeliveryError(CropHealthError):
    """Raised by NotificationProvider implementations (FCM / SNS Mobile Push)."""

    http_status_code = 502


class OutputStorageError(CropHealthError):
    """Raised when writing map tiles, chart data, or the Excel report to S3 fails."""

    http_status_code = 502


class StaleDeviceTokenError(NotificationDeliveryError):
    """Raised when the push provider reports the device token as invalid/unregistered.
    Callers should deregister the token, not retry the send."""

    retryable = False


class FieldNotFoundError(CropHealthError):
    http_status_code = 404


class TierNotEntitledError(CropHealthError):
    """Raised when a job is requested for a field on a tier that doesn't include
    crop-health monitoring (see Section 8 item 5: tier gate)."""

    http_status_code = 403


class InvalidRequestError(CropHealthError):
    """The caller asked for something that can never work (bad date range, ...)."""

    http_status_code = 422


class TooManyJobsError(CropHealthError):
    """The server already has as many analyses running as it allows."""

    http_status_code = 429


class JobEnqueueError(CropHealthError):
    """A job request could not be placed on the queue."""

    http_status_code = 502
