"""
Provider interfaces ("ports" in hexagonal/ports-and-adapters terms).

Concrete implementations live under `app/providers/*` ("adapters"). Job/worker
code (`app/jobs/*`) and API code depend ONLY on these interfaces, never on a
concrete provider class directly — that's what makes the provider swap in
Section 2 of the spec ("a new implementation class plus a config change") true
in practice rather than just in a README.
"""
from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from datetime import date, datetime
from typing import Optional

from app.domain.models import (
    CropHealthJobRequest,
    DateRange,
    FieldBoundary,
    JobStatus,
    NotificationSendResult,
    PushNotificationPayload,
    ReasoningInput,
    ReasoningResult,
    SceneRef,
    ScenePreview,
    ScheduleConfig,
    SoilHealth,
    SubscriptionTier,
    WeatherForecast,
    WeatherHistory,
)


class ImageryProvider(ABC):
    """Satellite imagery discovery + fetch. Default implementation: Planet Insights
    Platform (Sentinel-2 via the Sentinel Hub Catalog + Process APIs). Swappable
    for any other provider by writing a new class and registering it."""

    @abstractmethod
    def search(self, aoi_geojson: dict, date_range: DateRange) -> list[SceneRef]:
        """Return scenes intersecting the AOI within the date range, cloud-cover permitting."""

    @abstractmethod
    def fetch_bands(self, scene: SceneRef, bands: list[str]) -> dict[str, bytes]:
        """Download the requested band assets for a scene. Returns {band_name: raw_bytes}."""


class CroplandMaskProvider(ABC):
    """Cropland classification mask for an AOI. Default: ESA WorldCover/WorldCereal."""

    @abstractmethod
    def get_mask(self, aoi_geojson: dict) -> bytes:
        """Return a raster mask (GeoTIFF bytes) for cropland pixels within the AOI."""

    @property
    @abstractmethod
    def source_name(self) -> str:
        """Identifier stored on HealthScoreResult.cropland_mask_source, e.g. 'esa_worldcover_2021'."""


class WeatherHistoryProvider(ABC):
    """Historical weather/soil-moisture data. Default: NASA POWER."""

    @abstractmethod
    def get_history(self, field: FieldBoundary, date_range: DateRange) -> WeatherHistory:
        ...


class WeatherForecastProvider(ABC):
    """Forward-looking weather forecast. Default: Open-Meteo (NASA POWER has no forecast)."""

    @abstractmethod
    def get_forecast(self, field: FieldBoundary, days: int = 7) -> WeatherForecast:
        ...


class SoilHealthProvider(ABC):
    """Reuses AgriVision's existing soil-health module/DB rather than rebuilding it."""

    @abstractmethod
    def get_latest(self, field_id: uuid.UUID) -> Optional[SoilHealth]:
        ...


class ReasoningProvider(ABC):
    """LLM-based crop-health reasoning. Default: Gemini. Must always return the
    ReasoningResult schema — never raw free text — so downstream automation
    (notification threshold, message language) can act on it reliably."""

    @abstractmethod
    def reason(self, reasoning_input: ReasoningInput) -> ReasoningResult:
        ...


class NotificationProvider(ABC):
    """Push-notification delivery. Default: Firebase Cloud Messaging (FCM), since the
    AgriVision app is Android-only on Play Store. AWS SNS Mobile Push is an equivalent
    alternative that also targets FCM under the hood."""

    @abstractmethod
    def send_push(
        self, device_token: str, payload: PushNotificationPayload
    ) -> NotificationSendResult:
        """Send a push notification. Must set `stale_token=True` on the result
        (not raise) when the provider reports the token as invalid/unregistered,
        so the caller can deregister it instead of retrying."""


# ====================================================================== #
# Raster analysis ports
# --------------------------------------------------------------------- #
# These let the scoring code ask "what is the mean NDVI of this scene?"
# without importing rasterio/numpy itself (Dependency Inversion).
# ====================================================================== #


class SceneAnalyzer(ABC):
    """Turns downloaded red/NIR bands into one NDVI number for a field."""

    @abstractmethod
    def mean_ndvi(
        self,
        red_band: bytes,
        nir_band: bytes,
        aoi_geojson: dict,
        cropland_mask: bytes,
    ) -> Optional[float]:
        """Mean NDVI over cropland pixels inside the field, or None if the
        scene has no usable pixels (e.g. the field sits on a tile edge)."""


class ScenePreviewBuilder(ABC):
    """Builds a small true-colour photo of the field. Best effort."""

    @abstractmethod
    def build(self, scene: SceneRef, aoi_geojson: dict) -> Optional[ScenePreview]:
        """Return the preview, or None if it could not be built."""


# ====================================================================== #
# Repository ports
# --------------------------------------------------------------------- #
# One small interface per concern (Interface Segregation). The code that
# only needs to read device tokens is never handed an object that can also
# create fields or delete job runs.
# ====================================================================== #


class FieldRepository(ABC):
    @abstractmethod
    def get_field(self, field_id: uuid.UUID) -> FieldBoundary:
        """Raises FieldNotFoundError if the field does not exist."""

    @abstractmethod
    def create_field(
        self,
        *,
        name: str,
        geojson_polygon: dict,
        farmer_id: uuid.UUID,
        subscription_tier: SubscriptionTier,
        fpo_id: Optional[uuid.UUID] = None,
    ) -> FieldBoundary:
        ...

    @abstractmethod
    def assert_entitled(self, field: FieldBoundary) -> None:
        """Raises TierNotEntitledError if the field's tier has no crop-health access."""


class JobRunRepository(ABC):
    """Bookkeeping for job runs: started, finished, last good result."""

    @abstractmethod
    def create_job_run(
        self,
        job_id: uuid.UUID,
        field_id: uuid.UUID,
        trigger_source: str,
        period_start: date,
        period_end: date,
    ) -> None:
        ...

    @abstractmethod
    def complete_job_run(
        self,
        job_id: uuid.UUID,
        status: JobStatus,
        result_json: Optional[dict],
        error: Optional[str],
    ) -> None:
        ...

    @abstractmethod
    def get_last_successful_result(self, field_id: uuid.UUID) -> Optional[dict]:
        ...

    @abstractmethod
    def get_job_run(self, job_id: uuid.UUID) -> Optional[dict]:
        ...

    @abstractmethod
    def is_duplicate_job(self, field_id: uuid.UUID, period_start: date, period_end: date) -> bool:
        ...

    @abstractmethod
    def fail_stale_runs(self, reason: str) -> int:
        """Mark every run still 'running' as failed (used on server start)."""


class DeviceTokenRepository(ABC):
    @abstractmethod
    def get_active_device_token(self, farmer_id: uuid.UUID) -> Optional[str]:
        ...

    @abstractmethod
    def deregister_device_token(self, farmer_id: uuid.UUID, device_token: str) -> None:
        ...


class ScheduleRepository(ABC):
    @abstractmethod
    def get_due_schedules(self, as_of: datetime) -> list[ScheduleConfig]:
        ...

    @abstractmethod
    def mark_schedule_run(self, field_id: uuid.UUID, next_due_at: datetime) -> None:
        ...


# ====================================================================== #
# Messaging port
# ====================================================================== #


class JobQueue(ABC):
    """Where job requests are sent to be processed later (SQS in AWS)."""

    @abstractmethod
    def enqueue(self, request: CropHealthJobRequest) -> None:
        """Raises if the message could not be queued."""
