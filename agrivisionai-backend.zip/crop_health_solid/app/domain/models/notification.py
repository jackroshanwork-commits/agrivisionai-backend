"""Push notification payload/result shapes — provider-agnostic (both
FCMNotificationProvider and SNSMobilePushNotificationProvider speak these)."""
from __future__ import annotations

import uuid

from pydantic import BaseModel, Field

from app.domain.models.enums import RiskLevel


class PushNotificationPayload(BaseModel):
    farmer_id: uuid.UUID
    field_id: uuid.UUID
    title: str
    body: str
    risk_level: RiskLevel
    deep_link: str = Field(..., description="e.g. agrivisionai://field/{field_id}/crop-health")
    data: dict[str, str] = Field(default_factory=dict)


class NotificationSendResult(BaseModel):
    farmer_id: uuid.UUID
    field_id: uuid.UUID
    delivered: bool
    provider_message_id: str | None = None
    stale_token: bool = False
    error: str | None = None
