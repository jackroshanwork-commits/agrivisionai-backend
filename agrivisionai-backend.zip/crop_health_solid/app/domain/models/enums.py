"""Enums shared across every domain model. Kept in their own module since
enums are referenced from almost every other models/ submodule — putting
them here avoids a tangle of cross-imports between field.py, job.py, etc."""
from __future__ import annotations

import enum


class JobStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class JobTriggerSource(str, enum.Enum):
    SCHEDULE = "schedule"
    EVENT = "event"
    MANUAL_API = "manual_api"


class SubscriptionTier(str, enum.Enum):
    FREE = "free"
    KISAN_PLUS = "kisan_plus"
    FPO_ENTERPRISE = "fpo_enterprise"


class RiskLevel(str, enum.Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class NotificationChannel(str, enum.Enum):
    PUSH = "push"  # only channel supported by this service — see Section 3 of the spec
