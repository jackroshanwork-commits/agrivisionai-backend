"""Satellite scene references and the health-score computation output."""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date, datetime, timezone

from pydantic import BaseModel, Field


class SceneRef(BaseModel):
    """A reference to a single satellite scene, provider-agnostic — this is
    what lets `app.domain.interfaces.ImageryProvider` implementations (Planet
    Insights, AWS Open Data, ...) all speak the same shape to the rest of the
    codebase."""

    scene_id: str
    collection: str  # e.g. "sentinel-2-l2a", "sentinel-1-grd"
    sensed_at: datetime
    cloud_cover_pct: float | None = None
    provider: str  # e.g. "planet_insights", "aws_open_data"
    asset_urls: dict[str, str] = Field(
        default_factory=dict, description="band/asset name -> URL or URI"
    )
    # The field this scene was searched for. Providers that clip imagery on the
    # server (Planet Insights) need it again when the bands are fetched. It is
    # carried on the scene (not cached inside the provider) because the same
    # satellite scene can be used by many fields at once.
    aoi_geojson: dict | None = None


@dataclass(frozen=True)
class ScenePreview:
    """A small true-colour photo of a field: a JPEG data-URL plus the map
    bounds [[south, west], [north, east]] it covers."""

    data_url: str
    bounds: list[list[float]]
    source: str = "sentinel-2"  # "sentinel-2" or e.g. "esri-world-imagery"


class SatelliteImage(BaseModel):
    """One satellite photo of the field (one per scene used)."""

    data_url: str
    bounds: list[list[float]]
    scene_date: date | None = None
    cloud_cover_pct: float | None = None
    scene_id: str | None = None
    source: str | None = None  # where the picture came from


class HealthScoreResult(BaseModel):
    """Output of the monthly crop-health scoring step for one field — the
    central artifact this whole service exists to produce."""

    field_id: uuid.UUID
    period_start: date
    period_end: date
    ndvi_mean: float
    ndvi_min: float
    ndvi_max: float
    health_score: float = Field(..., ge=0.0, le=100.0)
    cloud_cover_pct: float
    scenes_used: list[str] = Field(default_factory=list)
    cropland_mask_source: str
    ndvi_tile_url: str | None = None
    health_score_tile_url: str | None = None
    satellite_image_data_url: str | None = None
    satellite_image_bounds: list[list[float]] | None = None
    satellite_image_scene_date: date | None = None
    satellite_image_cloud_cover_pct: float | None = None
    satellite_images: list[SatelliteImage] = Field(default_factory=list)
    computed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
