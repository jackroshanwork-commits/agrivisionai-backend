"""Weather history (NASA POWER) and forecast (Open-Meteo) output shapes —
kept separate since they come from two different providers with different
semantics (backward-looking vs. forward-looking)."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel


class WeatherHistory(BaseModel):
    field_id: uuid.UUID
    period_start: date
    period_end: date
    rainfall_mm_total: float
    avg_temp_c: float
    avg_soil_moisture_pct: float | None = None


class WeatherForecast(BaseModel):
    field_id: uuid.UUID
    forecast_days: int
    daily_rainfall_mm: list[float]
    daily_avg_temp_c: list[float]
    adverse_weather_flag: bool = False
    adverse_weather_reason: str | None = None
