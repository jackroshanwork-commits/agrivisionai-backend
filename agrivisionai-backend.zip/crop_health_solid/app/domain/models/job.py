"""Request/result/schedule shapes for job orchestration — the top-level
objects `app.jobs.crop_health_job` and the API layer pass around. These
compose the other models/ submodules (imagery, reasoning, notification)
rather than duplicating their fields."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

from pydantic import BaseModel, Field

from app.domain.models.enums import JobStatus, JobTriggerSource
from app.domain.models.field import DateRange
from app.domain.models.imagery import HealthScoreResult
from app.domain.models.notification import NotificationSendResult
from app.domain.models.reasoning import ReasoningResult


class CropHealthJobRequest(BaseModel):
    field_id: uuid.UUID
    date_range: DateRange
    trigger_source: JobTriggerSource = JobTriggerSource.MANUAL_API
    job_id: uuid.UUID = Field(default_factory=uuid.uuid4)


class CropHealthJobResult(BaseModel):
    job_id: uuid.UUID
    field_id: uuid.UUID
    status: JobStatus
    health_score: HealthScoreResult | None = None
    reasoning: ReasoningResult | None = None
    notification: NotificationSendResult | None = None
    error: str | None = None
    started_at: datetime
    finished_at: datetime | None = None


class ScheduleConfig(BaseModel):
    field_id: uuid.UUID
    cron_expression: str = Field(..., description="e.g. 'cron(0 3 1 * ? *)' — 1st of month, 3am UTC")
    enabled: bool = True
    next_due_at: datetime | None = None
