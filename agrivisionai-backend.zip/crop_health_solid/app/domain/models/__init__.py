"""
Domain models package. Split into one submodule per concern (enums, field,
imagery, weather, soil, reasoning, notification, job) instead of one 230-line
`models.py` — easier to navigate, and a change to (say) the notification
shape touches one small file instead of a monolith shared by everything.

Every name is re-exported here so the rest of the codebase is unaffected by
the split: `from app.domain.models import HealthScoreResult` keeps working
exactly as it did when this was a single file. New code CAN import from the
specific submodule directly (`from app.domain.models.imagery import
HealthScoreResult`) if it only needs that one concern, but doesn't have to.
"""
from __future__ import annotations

from app.domain.models.enums import (
    JobStatus,
    JobTriggerSource,
    NotificationChannel,
    RiskLevel,
    SubscriptionTier,
)
from app.domain.models.field import DateRange, FieldBoundary
from app.domain.models.imagery import (
    HealthScoreResult,
    SatelliteImage,
    ScenePreview,
    SceneRef,
)
from app.domain.models.job import (
    CropHealthJobRequest,
    CropHealthJobResult,
    ScheduleConfig,
)
from app.domain.models.notification import NotificationSendResult, PushNotificationPayload
from app.domain.models.reasoning import ReasoningInput, ReasoningResult
from app.domain.models.soil import SoilHealth
from app.domain.models.weather import WeatherForecast, WeatherHistory

__all__ = [
    "JobStatus",
    "JobTriggerSource",
    "SubscriptionTier",
    "RiskLevel",
    "NotificationChannel",
    "FieldBoundary",
    "DateRange",
    "SceneRef",
    "ScenePreview",
    "SatelliteImage",
    "HealthScoreResult",
    "WeatherHistory",
    "WeatherForecast",
    "SoilHealth",
    "ReasoningInput",
    "ReasoningResult",
    "PushNotificationPayload",
    "NotificationSendResult",
    "CropHealthJobRequest",
    "CropHealthJobResult",
    "ScheduleConfig",
]
