"""Soil health snapshot — mirrors what AgriVision's existing soil-health
module already records (reused via DBSoilHealthProvider, not rebuilt)."""
from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel


class SoilHealth(BaseModel):
    field_id: uuid.UUID
    ph: float | None = None
    nitrogen_kg_ha: float | None = None
    phosphorus_kg_ha: float | None = None
    potassium_kg_ha: float | None = None
    organic_carbon_pct: float | None = None
    recorded_at: datetime | None = None
