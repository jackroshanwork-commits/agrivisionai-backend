"""Input/output shapes for the reasoning step (Section 3) — deliberately
structured (not free text) so both GeminiReasoningProvider and
RuleBasedReasoningProvider produce an identical, type-checked shape the rest
of the pipeline can rely on regardless of which one actually ran."""
from __future__ import annotations

import uuid

from pydantic import BaseModel, Field

from app.domain.models.enums import RiskLevel
from app.domain.models.imagery import HealthScoreResult
from app.domain.models.soil import SoilHealth
from app.domain.models.weather import WeatherForecast, WeatherHistory


class ReasoningInput(BaseModel):
    field_id: uuid.UUID
    farmer_language: str = Field(default="en", description="BCP-47-ish code: en, te, kn, hi, ta")
    health_score: HealthScoreResult
    previous_health_score: HealthScoreResult | None = None
    weather_history: WeatherHistory | None = None
    weather_forecast: WeatherForecast | None = None
    soil_health: SoilHealth | None = None


class ReasoningResult(BaseModel):
    """Structured output the reasoning engine (Gemini or rule-based fallback) must produce."""

    field_id: uuid.UUID
    risk_level: RiskLevel
    likely_cause: str
    recommended_action: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    message_farmer_language: str
    message_language_code: str
    generated_by: str = Field(..., description="'gemini' or 'rule_based_fallback'")
    should_notify: bool = False
