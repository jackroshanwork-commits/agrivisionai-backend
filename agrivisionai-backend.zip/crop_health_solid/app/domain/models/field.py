"""Field boundary (AOI) and date-range models — the two things almost every
other model in this package is ultimately scoped to (a field, over a period)."""
from __future__ import annotations

import uuid
from datetime import date

from pydantic import BaseModel, Field, field_validator

from app.domain.models.enums import SubscriptionTier


class FieldBoundary(BaseModel):
    """A farmer's field, identified and geolocated."""

    field_id: uuid.UUID
    farmer_id: uuid.UUID
    fpo_id: uuid.UUID | None = None
    name: str = Field(..., max_length=200)
    geojson_polygon: dict = Field(
        ..., description="GeoJSON Polygon/MultiPolygon geometry for the field AOI"
    )
    subscription_tier: SubscriptionTier

    @field_validator("geojson_polygon")
    @classmethod
    def _validate_geojson(cls, v: dict) -> dict:
        if v.get("type") not in ("Polygon", "MultiPolygon"):
            raise ValueError("geojson_polygon must be a GeoJSON Polygon or MultiPolygon")
        if "coordinates" not in v:
            raise ValueError("geojson_polygon is missing 'coordinates'")
        return v


class DateRange(BaseModel):
    start: date
    end: date

    @field_validator("end")
    @classmethod
    def _end_after_start(cls, v: date, info):
        start = info.data.get("start")
        if start and v < start:
            raise ValueError("end date must not be before start date")
        return v
