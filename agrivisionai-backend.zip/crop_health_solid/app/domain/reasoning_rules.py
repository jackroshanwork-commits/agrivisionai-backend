"""
Notification-threshold logic and the deterministic rule-based fallback message
used when Gemini is unavailable or its circuit breaker is open (Section 7:
"LLM call resilience ... fall back to a deterministic rule-based message rather
than skipping the farmer notification outright").

Pure functions — no network/AWS imports — fully unit-testable.
"""
from __future__ import annotations

from app.domain.models import (
    HealthScoreResult,
    ReasoningResult,
    RiskLevel,
    WeatherForecast,
)
from app.domain.scoring import health_score_delta_pct

# Configurable via Settings in practice; hardcoded defaults documented here.
DEFAULT_SCORE_DROP_THRESHOLD_PCT = 15.0
DEFAULT_CRITICAL_SCORE_DROP_THRESHOLD_PCT = 30.0

_TEMPLATES = {
    "en": {
        RiskLevel.CRITICAL: "Alert: {field_name} crop health dropped sharply ({delta}%). Please inspect the field soon.",
        RiskLevel.HIGH: "Warning: {field_name} crop health declined by {delta}%. Consider inspecting the field.",
        RiskLevel.MODERATE: "Note: {field_name} crop health changed by {delta}%. Monitor over the coming days.",
        RiskLevel.LOW: "{field_name} crop health looks stable.",
    },
}


def determine_risk_level(
    health_score: HealthScoreResult,
    previous_health_score: HealthScoreResult | None,
    weather_forecast: WeatherForecast | None,
    *,
    score_drop_threshold_pct: float = DEFAULT_SCORE_DROP_THRESHOLD_PCT,
    critical_score_drop_threshold_pct: float = DEFAULT_CRITICAL_SCORE_DROP_THRESHOLD_PCT,
) -> tuple[RiskLevel, float | None]:
    """Pure risk-level decision, independent of which reasoning engine produced it.
    Both the Gemini provider and the rule-based fallback should call this to decide
    should_notify, so the *threshold* behaviour is identical regardless of which
    engine wrote the message.
    """
    prev_score = previous_health_score.health_score if previous_health_score else None
    delta = health_score_delta_pct(health_score.health_score, prev_score)

    if weather_forecast and weather_forecast.adverse_weather_flag:
        # Adverse forecast alone is at least a MODERATE flag, escalated further
        # if the score has also dropped meaningfully.
        base = RiskLevel.MODERATE
    else:
        base = RiskLevel.LOW

    if delta is not None and delta < 0:
        drop = abs(delta)
        if drop >= critical_score_drop_threshold_pct:
            return RiskLevel.CRITICAL, delta
        if drop >= score_drop_threshold_pct:
            return RiskLevel.HIGH, delta

    return base, delta


def should_notify(risk_level: RiskLevel) -> bool:
    """Only notify on MODERATE and above — avoids alert fatigue on every run."""
    return risk_level in (RiskLevel.MODERATE, RiskLevel.HIGH, RiskLevel.CRITICAL)


def build_rule_based_reasoning(
    health_score: HealthScoreResult,
    previous_health_score: HealthScoreResult | None,
    weather_forecast: WeatherForecast | None,
    field_name: str,
    language_code: str = "en",
) -> ReasoningResult:
    """Deterministic fallback used when Gemini fails or its circuit breaker is open.

    Intentionally template-based rather than "smart" — the point is that it must
    always succeed and always produce the same ReasoningResult schema Gemini would,
    so downstream code (notification dispatch) never has to special-case which
    engine produced the result.
    """
    risk_level, delta = determine_risk_level(health_score, previous_health_score, weather_forecast)
    templates = _TEMPLATES.get(language_code, _TEMPLATES["en"])
    delta_display = f"{delta:+.1f}" if delta is not None else "0.0"
    message = templates[risk_level].format(field_name=field_name, delta=delta_display)

    likely_cause = "insufficient data to determine cause (automated fallback message)"
    if delta is not None and delta < 0:
        likely_cause = "recent NDVI decline versus prior period"
    if weather_forecast and weather_forecast.adverse_weather_flag:
        likely_cause = weather_forecast.adverse_weather_reason or "adverse weather forecast"

    return ReasoningResult(
        field_id=health_score.field_id,
        risk_level=risk_level,
        likely_cause=likely_cause,
        recommended_action="Inspect the field in person and consult the AgriVision advisory chatbot for next steps.",
        confidence=0.4,  # deliberately low — this is a template, not an LLM judgement
        message_farmer_language=message,
        message_language_code=language_code,
        generated_by="rule_based_fallback",
        should_notify=should_notify(risk_level),
    )
