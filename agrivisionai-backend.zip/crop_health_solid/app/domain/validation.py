"""Small, pure request-validation helpers (no I/O, easy to unit test)."""
from __future__ import annotations

from datetime import date

from app.domain.exceptions import InvalidRequestError
from app.domain.models import DateRange


def build_date_range(start: date, end: date, max_days: int) -> DateRange:
    """Validate a user-supplied period and return it as a DateRange."""
    if end < start:
        raise InvalidRequestError("End date must be on or after the start date.")
    days = (end - start).days + 1
    if days > max_days:
        raise InvalidRequestError(f"Please choose {max_days} days or fewer (you chose {days}).")
    return DateRange(start=start, end=end)
