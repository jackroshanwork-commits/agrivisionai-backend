"""
NDVI / crop-health scoring — pure functions, no AWS/SDK/network imports.

Kept deliberately dependency-light (plain floats/lists) so these are trivially
unit-testable without mocking anything. The provider layer is responsible for
turning raw raster bands into the `red`/`nir` reflectance arrays this module
consumes; that raster I/O (rasterio/numpy) lives in `app/providers/imagery/`,
not here.
"""
from __future__ import annotations

from app.domain.exceptions import ScoringError

# Cloud-cover threshold above which a scene is excluded from the composite.
DEFAULT_CLOUD_COVER_THRESHOLD_PCT = 40.0


def compute_ndvi(red: float, nir: float) -> float:
    """Single-pixel/aggregate NDVI: (NIR - RED) / (NIR + RED), clamped to [-1, 1]."""
    denom = nir + red
    if denom == 0:
        raise ScoringError("NDVI denominator (NIR + RED) is zero — invalid reflectance input")
    ndvi = (nir - red) / denom
    return max(-1.0, min(1.0, ndvi))


def filter_scenes_by_cloud_cover(
    scene_cloud_covers: list[tuple[str, float]],
    threshold_pct: float = DEFAULT_CLOUD_COVER_THRESHOLD_PCT,
) -> list[str]:
    """Given [(scene_id, cloud_cover_pct), ...], return scene_ids under the threshold.

    Raises ScoringError if nothing survives the filter — the caller (job/worker)
    decides whether that means "use SAR fallback" or "fail the job".
    """
    survivors = [sid for sid, cc in scene_cloud_covers if cc <= threshold_pct]
    if not survivors:
        raise ScoringError(
            f"No scenes under {threshold_pct}% cloud cover out of "
            f"{len(scene_cloud_covers)} candidates"
        )
    return survivors


def composite_ndvi(ndvi_values: list[float]) -> tuple[float, float, float]:
    """Gap-filled monthly composite: mean/min/max over the surviving per-scene NDVI values.

    "Gap-filled" here means: scenes excluded by cloud cover simply don't contribute —
    the composite is computed over whatever valid observations remain in the period,
    rather than requiring every day to have a clean observation.
    """
    if not ndvi_values:
        raise ScoringError("composite_ndvi called with no NDVI values (all scenes filtered out)")
    return (
        sum(ndvi_values) / len(ndvi_values),
        min(ndvi_values),
        max(ndvi_values),
    )


def ndvi_to_health_score(ndvi_mean: float) -> float:
    """Map NDVI [-1, 1] onto a farmer-facing 0-100 health score.

    NDVI < 0.2 is typically bare soil/water/non-vegetation; NDVI > 0.7 is dense,
    healthy vegetation. This linear mapping is intentionally simple and should be
    tuned per-crop once field-validated data is available (AgriVision already has
    ICAR-IARI-validated imagery that could calibrate per-crop curves later).
    """
    floor, ceiling = 0.15, 0.75
    clamped = max(floor, min(ceiling, ndvi_mean))
    score = (clamped - floor) / (ceiling - floor) * 100.0
    return round(score, 2)


def health_score_delta_pct(current: float, previous: float | None) -> float | None:
    """Percentage change vs. the previous period's score, or None if no prior score."""
    if previous is None or previous == 0:
        return None
    return round((current - previous) / previous * 100.0, 2)
