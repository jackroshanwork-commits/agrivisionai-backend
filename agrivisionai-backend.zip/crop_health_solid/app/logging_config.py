"""
Structured JSON logging with a correlation/job ID propagated via contextvars
(Section 6: "a correlation/job ID generated at trigger time and propagated
through every downstream call ... so one job run's full trace is greppable in
CloudWatch by a single ID").

Usage:
    from app.logging_config import configure_logging, get_logger, correlation_id_ctx

    configure_logging()
    log = get_logger(__name__)

    token = correlation_id_ctx.set(str(job_id))
    try:
        log.info("job.started", field_id=str(field_id))
    finally:
        correlation_id_ctx.reset(token)

When invoking via SQS, put the correlation ID in the message attribute
`correlation_id` so the worker Lambda can restore it into the contextvar before
processing — that's how the ID survives the dispatcher -> SQS -> Lambda hop.
"""
from __future__ import annotations

import contextvars
import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any

correlation_id_ctx: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "correlation_id", default=None
)

# Fields that must never be logged in plaintext, even if accidentally passed in
# kwargs — belt-and-suspenders alongside code review (Section 6: "never log
# secrets, API keys, or farmer PII ... in plaintext").
_REDACTED_KEYS = {
    "api_key",
    "client_secret",
    "device_token",
    "phone_number",
    "password",
    "authorization",
    "fcm_service_account_json",
}


class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "correlation_id": correlation_id_ctx.get(),
        }
        extra = getattr(record, "extra_fields", None)
        if extra:
            for k, v in extra.items():
                if k.lower() in _REDACTED_KEYS:
                    payload[k] = "***REDACTED***"
                else:
                    payload[k] = v
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


class _StructuredLoggerAdapter(logging.LoggerAdapter):
    """Lets call sites do `log.info("job.started", field_id=..., job_id=...)`
    instead of manually building a dict every time."""

    def process(self, msg, kwargs):
        extra_fields = {k: v for k, v in kwargs.items() if k not in ("exc_info", "stack_info")}
        for k in list(kwargs.keys()):
            if k not in ("exc_info", "stack_info"):
                kwargs.pop(k)
        kwargs["extra"] = {"extra_fields": extra_fields}
        return msg, kwargs


def configure_logging(level: str = "INFO") -> None:
    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(_JsonFormatter())
    root.addHandler(handler)


def get_logger(name: str) -> _StructuredLoggerAdapter:
    return _StructuredLoggerAdapter(logging.getLogger(name), {})
