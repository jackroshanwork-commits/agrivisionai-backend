"""
SQS-triggered worker Lambda. Consumes CropHealthJobRequest messages queued by
the schedule dispatcher or the S3-event handler; both paths call the same
`CropHealthJob.run()`.

The container is built once per Lambda execution environment (module level) so
a warm container reuses connections/clients across invocations.
"""
from __future__ import annotations

from app.config import get_settings
from app.container import build_container
from app.domain.models import CropHealthJobRequest
from app.logging_config import configure_logging, correlation_id_ctx, get_logger

_settings = get_settings()
configure_logging(_settings.log_level)
_container = build_container(_settings)
log = get_logger(__name__)


def handler(event: dict, context) -> dict:
    """SQS batch handler. Returns `batchItemFailures` so one bad message
    doesn't block the rest of the batch."""
    failures = []
    for record in event.get("Records", []):
        message_id = record["messageId"]
        correlation_id = (
            record.get("messageAttributes", {}).get("correlation_id", {}).get("stringValue")
        )
        token = correlation_id_ctx.set(correlation_id) if correlation_id else None
        try:
            request = CropHealthJobRequest.model_validate_json(record["body"])
            _container.crop_health_job.run(request)
        except Exception:  # noqa: BLE001 - must not crash the whole batch
            log.exception("worker.message_failed", message_id=message_id)
            failures.append({"itemIdentifier": message_id})
        finally:
            if token is not None:
                correlation_id_ctx.reset(token)

    return {"batchItemFailures": failures}
