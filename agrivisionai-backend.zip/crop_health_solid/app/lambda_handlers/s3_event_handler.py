"""
S3 `ObjectCreated` handler: the "new imagery arrived" trigger.

It does NOT process imagery. It works out which field/date is affected and
queues a job on the same queue the schedule dispatcher uses, so the worker is
the single consumer for both trigger paths.

Object key convention: `raw/{field_id}/{scene_date}/...`
"""
from __future__ import annotations

import re
import uuid
from datetime import date

from app.config import get_settings
from app.container import build_job_queue
from app.domain.models import CropHealthJobRequest, DateRange, JobTriggerSource
from app.logging_config import configure_logging, get_logger

_settings = get_settings()
configure_logging(_settings.log_level)
_queue = build_job_queue(_settings)
log = get_logger(__name__)

_KEY_PATTERN = re.compile(r"^raw/(?P<field_id>[0-9a-fA-F-]{36})/(?P<scene_date>\d{4}-\d{2}-\d{2})/")


def parse_imagery_key(key: str) -> tuple[uuid.UUID, date] | None:
    """Pure function: pull (field_id, scene_date) out of an S3 key, or None."""
    match = _KEY_PATTERN.match(key)
    if not match:
        return None
    return uuid.UUID(match.group("field_id")), date.fromisoformat(match.group("scene_date"))


def handler(event: dict, context) -> dict:
    enqueued = 0
    for record in event.get("Records", []):
        key = record.get("s3", {}).get("object", {}).get("key", "")
        parsed = parse_imagery_key(key)
        if parsed is None:
            log.warning("s3_event.key_pattern_mismatch", key=key)
            continue

        field_id, scene_date = parsed
        _queue.enqueue(
            CropHealthJobRequest(
                field_id=field_id,
                date_range=DateRange(start=scene_date.replace(day=1), end=scene_date),
                trigger_source=JobTriggerSource.EVENT,
            )
        )
        enqueued += 1
        log.info("s3_event.enqueued", field_id=str(field_id), key=key)

    return {"enqueued": enqueued}
