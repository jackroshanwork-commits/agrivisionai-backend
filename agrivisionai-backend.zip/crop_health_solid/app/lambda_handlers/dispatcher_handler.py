"""
EventBridge-triggered dispatcher Lambda. Runs on ONE fixed cadence (e.g. daily),
NOT one schedule per field. It only builds what it needs: the schedule table
and the queue.
"""
from __future__ import annotations

from app.config import get_settings
from app.container import build_schedule_dispatcher
from app.logging_config import configure_logging

_settings = get_settings()
configure_logging(_settings.log_level)
_dispatcher = build_schedule_dispatcher(_settings)


def handler(event: dict, context) -> dict:
    return {"enqueued": _dispatcher.run()}
