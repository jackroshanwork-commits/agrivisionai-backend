"""
Lambda entrypoint for API Gateway, via Mangum. This is the handler referenced
by the CDK stack's API Lambda (infra/crop_health_stack.py).
"""
from mangum import Mangum

from app.main import app

handler = Mangum(app)
