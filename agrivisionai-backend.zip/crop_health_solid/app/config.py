"""
Application configuration (the ONLY place that reads environment variables).

Beginner note
-------------
Only two kinds of code are allowed to look at `Settings`:
  1. the composition root (`app/container.py`) which wires everything together
  2. provider adapters (Planet Insights, Groq, FCM, ...) that need their own credentials

Business logic (`app/jobs/*`, `app/domain/*`) never imports this file. It
receives plain values (like `cloud_cover_threshold_pct`) through its
constructor instead. That keeps the business logic easy to test.

In AWS, secret fields (API keys, passwords) should come from Secrets Manager,
not from a committed `.env` file.
"""
from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- Application ---------------------------------------------------- #
    app_name: str = "crop-health-service"
    environment: str = "development"
    log_level: str = "INFO"
    cors_allow_origins: str = "*"  # comma-separated list

    # --- API limits ----------------------------------------------------- #
    max_pending_jobs: int = 3
    max_range_days: int = 31

    # --- Database ------------------------------------------------------- #
    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/crop_health"

    # --- Which implementation to use for each port ---------------------- #
    # (see app/providers/factories.py for the allowed names)
    imagery_provider: Literal["planet_insights", "aws_open_data"] = "planet_insights"
    cropland_mask_provider: str = "esa_worldcover"
    weather_history_provider: str = "nasa_power"
    weather_provider: str = "open_meteo"  # the forecast provider
    soil_provider: str = "database"
    reasoning_provider: str = "groq"  # "groq" or "rule_based_only"
    # "noop" only logs, so the app boots without push credentials.
    notification_provider: str = "noop"  # "noop", "fcm" or "sns_mobile_push"

    # --- Planet Insights Platform (Sentinel Hub APIs) -------------------- #
    # Create an OAuth client in the Planet Insights dashboard (Account ->
    # Developers / OAuth clients) and put its id + secret here.
    planet_client_id: str = ""
    planet_client_secret: str = ""
    planet_auth_url: str = (
        "https://services.sentinel-hub.com/auth/realms/main/protocol/openid-connect/token"
    )
    planet_catalog_url: str = "https://services.sentinel-hub.com/api/v1/catalog/1.0.0"
    planet_process_url: str = "https://services.sentinel-hub.com/api/v1/process"
    # Sharp (3 m PlanetScope / ~0.5 m SkySat) field photo. This is the id of the
    # data collection you got when you ordered or subscribed to Planet imagery,
    # e.g. "byoc-1a2b3c...". Leave empty if you have no Planet data subscription.
    planet_imagery_collection_id: str = ""
    planet_photo_lookback_days: int = 14  # use the newest picture this many days back

    # --- Field photo ---------------------------------------------------- #
    # "planet": your Planet Insights photo first (needs PLANET_IMAGERY_COLLECTION_ID),
    #           then Esri, then Sentinel-2. With no collection id this is the
    #           same as "esri_then_sentinel".
    # "esri_then_sentinel": sharp basemap photo, Sentinel-2 if that fails.
    # "sentinel": only the Sentinel-2 photo (10 m/pixel, upscaled).
    # "esri": only the sharp photo.
    preview_source: Literal["planet", "esri_then_sentinel", "sentinel", "esri"] = "planet"
    preview_long_side_px: int = 1280

    # --- Scoring -------------------------------------------------------- #
    cloud_cover_threshold_pct: float = 20.0
    score_drop_threshold_pct: float = 20.0
    critical_score_drop_threshold_pct: float = 30.0

    # --- Groq (LLM reasoning) ------------------------------------------- #
    groq_api_key: str = ""
    groq_model: str = "openai/gpt-oss-20b"
    groq_circuit_breaker_fail_max: int = 3
    groq_circuit_breaker_reset_timeout_seconds: int = 60

    # --- Weather -------------------------------------------------------- #
    open_meteo_base_url: str = "https://api.open-meteo.com/v1/forecast"
    nasa_power_base_url: str = "https://power.larc.nasa.gov/api/temporal/daily"

    # --- Notifications -------------------------------------------------- #
    fcm_service_account_json: str = ""
    sns_platform_application_arn: str = ""

    # --- AWS ------------------------------------------------------------ #
    aws_region: str = "ap-south-1"
    job_queue_url: str = ""
    imagery_cache_bucket: str = ""
    tiles_bucket: str = ""
    reports_bucket: str = ""
    tiles_cloudfront_domain: str = ""


@lru_cache
def get_settings() -> Settings:
    """One shared Settings object per process."""
    return Settings()
