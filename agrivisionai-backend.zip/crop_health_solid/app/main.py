from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routers import fields, health, jobs
from app.config import get_settings
from app.container import build_container
from app.domain.exceptions import CropHealthError
from app.logging_config import configure_logging, get_logger

log = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)
    log.info("app.startup", environment=settings.environment)
    app.state.container = build_container(settings)
    try:
        n = app.state.container.job_runs.fail_stale_runs("Interrupted by a server restart")
        if n:
            log.warning("startup.stale_runs_failed", count=n)
    except Exception as exc:  # noqa: BLE001 - never block startup on cleanup
        log.error("startup.stale_cleanup_failed", error=str(exc))
    yield
    log.info("app.shutdown")


app = FastAPI(title="AgriVision Crop Health Service", version="1.0.0", lifespan=lifespan)

_origins = [o.strip() for o in get_settings().cors_allow_origins.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_origins,
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(CropHealthError)
async def handle_crop_health_error(_: Request, exc: CropHealthError) -> JSONResponse:
    """One place that turns our domain errors into HTTP responses."""
    return JSONResponse(status_code=exc.http_status_code, content={"detail": exc.message})


app.include_router(health.router)
app.include_router(fields.router)
app.include_router(jobs.router)
