from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.api.deps import get_fields
from app.domain.interfaces import FieldRepository
from app.domain.models import SubscriptionTier

router = APIRouter(prefix="/fields", tags=["fields"])


class LatLng(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)


class RegisterFieldBody(BaseModel):
    name: str = Field(default="Field drawn on map", max_length=200)
    polygon: list[LatLng] = Field(..., min_length=3)
    farmer_id: uuid.UUID | None = None
    subscription_tier: SubscriptionTier = SubscriptionTier.KISAN_PLUS


class RegisterFieldResponse(BaseModel):
    field_id: uuid.UUID
    farmer_id: uuid.UUID
    name: str
    subscription_tier: SubscriptionTier


@router.post("", response_model=RegisterFieldResponse, status_code=201)
def register_field(
    body: RegisterFieldBody,
    fields: FieldRepository = Depends(get_fields),
) -> RegisterFieldResponse:
    ring = [[p.longitude, p.latitude] for p in body.polygon]
    if ring[0] != ring[-1]:
        ring.append(ring[0])
    if len(ring) < 4:
        raise HTTPException(status_code=422, detail="polygon needs at least 3 distinct points")

    field = fields.create_field(
        name=body.name,
        geojson_polygon={"type": "Polygon", "coordinates": [ring]},
        farmer_id=body.farmer_id or uuid.uuid4(),
        subscription_tier=body.subscription_tier,
    )
    return RegisterFieldResponse(
        field_id=field.field_id,
        farmer_id=field.farmer_id,
        name=field.name,
        subscription_tier=field.subscription_tier,
    )
