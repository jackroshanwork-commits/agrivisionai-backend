"""
HTTP routes for crop-health jobs.

These functions only translate HTTP <-> use case: validate input, call a
service, shape the response. Threading, limits and persistence live in
`BackgroundJobRunner` / `CropHealthJob`. Errors (CropHealthError) are turned
into HTTP responses by one handler in `app/main.py`, so no try/except here.
"""
from __future__ import annotations

import uuid
from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.deps import get_app_settings, get_fields, get_job_runner, get_job_runs
from app.config import Settings
from app.domain.interfaces import FieldRepository, JobRunRepository
from app.domain.models import CropHealthJobRequest, CropHealthJobResult, JobTriggerSource
from app.domain.validation import build_date_range
from app.jobs.background_runner import BackgroundJobRunner

router = APIRouter(prefix="/jobs/crop-health", tags=["crop-health"])


class RunJobRequestBody(BaseModel):
    field_id: uuid.UUID
    start_date: date
    end_date: date


class StartJobResponse(BaseModel):
    job_id: uuid.UUID
    field_id: uuid.UUID
    status: str


def _to_job_request(
    body: RunJobRequestBody, fields: FieldRepository, settings: Settings
) -> CropHealthJobRequest:
    """Validate the body and make sure the field exists (404 early if not)."""
    date_range = build_date_range(body.start_date, body.end_date, settings.max_range_days)
    fields.get_field(body.field_id)
    return CropHealthJobRequest(
        field_id=body.field_id,
        date_range=date_range,
        trigger_source=JobTriggerSource.MANUAL_API,
    )


@router.post("/start", response_model=StartJobResponse, status_code=202)
def start_job(
    body: RunJobRequestBody,
    fields: FieldRepository = Depends(get_fields),
    runner: BackgroundJobRunner = Depends(get_job_runner),
    settings: Settings = Depends(get_app_settings),
) -> StartJobResponse:
    """Start an analysis and return immediately; poll GET /jobs/{job_id}."""
    request = _to_job_request(body, fields, settings)
    runner.submit(request)
    return StartJobResponse(job_id=request.job_id, field_id=request.field_id, status="running")


@router.post("/run", response_model=CropHealthJobResult, status_code=202)
def trigger_job(
    body: RunJobRequestBody,
    fields: FieldRepository = Depends(get_fields),
    runner: BackgroundJobRunner = Depends(get_job_runner),
    settings: Settings = Depends(get_app_settings),
) -> CropHealthJobResult:
    """Start an analysis and wait for the result."""
    request = _to_job_request(body, fields, settings)
    try:
        return runner.submit(request).result()
    except Exception as exc:
        if hasattr(exc, "http_status_code"):  # a CropHealthError: main.py maps it
            raise
        raise HTTPException(
            status_code=500, detail="The analysis failed unexpectedly. Please try again."
        ) from exc


@router.get("/jobs/{job_id}")
def get_job(
    job_id: uuid.UUID,
    job_runs: JobRunRepository = Depends(get_job_runs),
    runner: BackgroundJobRunner = Depends(get_job_runner),
) -> dict:
    row = job_runs.get_job_run(job_id)
    if row is None:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    if row["status"] == "running" or runner.is_active(job_id):
        return {"job_id": str(job_id), "field_id": str(row["field_id"]), "status": "running"}
    if row["result_json"]:
        return row["result_json"]
    return {
        "job_id": str(job_id),
        "field_id": str(row["field_id"]),
        "status": row["status"],
        "error": row["error"],
    }


@router.get("/fields/{field_id}/latest", response_model=CropHealthJobResult | None)
def get_latest_result(
    field_id: uuid.UUID,
    job_runs: JobRunRepository = Depends(get_job_runs),
) -> dict | None:
    result = job_runs.get_last_successful_result(field_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"No results yet for field {field_id}")
    return result
