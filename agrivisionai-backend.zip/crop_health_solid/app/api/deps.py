"""
FastAPI dependency wiring. The Container is built once at startup (see
`app/main.py`) and stored on `app.state`. Route functions ask for the small
piece they need, e.g. `fields: FieldRepository = Depends(get_fields)`,
instead of receiving one giant object.
"""
from __future__ import annotations

from fastapi import Request

from app.config import Settings, get_settings
from app.container import Container
from app.domain.interfaces import FieldRepository, JobRunRepository
from app.jobs.background_runner import BackgroundJobRunner


def get_container(request: Request) -> Container:
    return request.app.state.container


def get_fields(request: Request) -> FieldRepository:
    return get_container(request).fields


def get_job_runs(request: Request) -> JobRunRepository:
    return get_container(request).job_runs


def get_job_runner(request: Request) -> BackgroundJobRunner:
    return get_container(request).job_runner


def get_app_settings() -> Settings:
    return get_settings()
