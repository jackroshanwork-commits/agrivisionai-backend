"""
Local dev convenience: creates all tables from the ORM models directly
(`Base.metadata.create_all`) — good enough for `docker-compose up` + a quick
`python scripts/init_db.py`. A real deployment should use Alembic migrations
against the shared `agrivisionai-prod-db` instead of this script, since the
fields/soil_health tables are expected to already exist there.

Usage:
    python scripts/init_db.py
"""
from __future__ import annotations

import sys
from pathlib import Path

# Allow running as `python scripts/init_db.py` from the repo root — Python
# only puts this script's own directory (scripts/) on sys.path, not the repo
# root, so `import app...` below fails otherwise (ModuleNotFoundError: app).
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import get_settings
from app.providers.persistence.db import Database
from app.providers.persistence.models_orm import Base


def main() -> None:
    settings = get_settings()
    db = Database(settings)
    Base.metadata.create_all(db.engine)
    print(f"Tables created against {settings.database_url}")


if __name__ == "__main__":
    main()
