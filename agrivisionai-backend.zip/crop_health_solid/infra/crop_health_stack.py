"""
CDK (Python) stack for the crop-health service (Section 8, item 3).

Deliberately scoped to the AWS wiring only — application code lives under
`app/`. Deploy with `cdk deploy` from the repo root (see README).

Design notes / assumptions called out explicitly (Section 10 of the spec asks
for these to be stated, not buried):
  - Runs the worker Lambda on ECS Fargate would be an alternative to the plain
    Lambda used below if raster processing for very large fields exceeds
    Lambda's 15-minute timeout / ephemeral storage; this stack ships the
    Lambda version and documents the Fargate swap as a follow-up, since most
    single-field monthly composites fit comfortably inside Lambda's limits.
  - The schedule dispatcher runs on ONE fixed daily EventBridge rule (not one
    rule per field) — the dispatcher Lambda itself decides which fields are
    due, per the spec's explicit warning against per-field schedules.
  - Each Lambda gets its own least-privilege role — the notification/worker
    Lambda does not get S3 write access it doesn't need, etc. (Section 6:
    Security).
"""
from __future__ import annotations

from aws_cdk import (
    Duration,
    RemovalPolicy,
    Stack,
    aws_apigateway as apigw,
    aws_events as events,
    aws_events_targets as targets,
    aws_iam as iam,
    aws_lambda as _lambda,
    aws_s3 as s3,
    aws_s3_notifications as s3n,
    aws_secretsmanager as secretsmanager,
    aws_sqs as sqs,
)
from constructs import Construct


class CropHealthStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # --- Secrets (Planet Insights, Groq, FCM credentials — Section 6: Security) --- #
        provider_secrets = secretsmanager.Secret(
            self,
            "ProviderSecrets",
            description="Planet Insights client id/secret, Groq API key, FCM service account JSON",
        )

        # --- S3 buckets --- #
        imagery_cache_bucket = s3.Bucket(
            self,
            "ImageryCacheBucket",
            removal_policy=RemovalPolicy.RETAIN,
            lifecycle_rules=[s3.LifecycleRule(expiration=Duration.days(90))],
        )
        tiles_bucket = s3.Bucket(self, "TilesBucket", removal_policy=RemovalPolicy.RETAIN)
        reports_bucket = s3.Bucket(self, "ReportsBucket", removal_policy=RemovalPolicy.RETAIN)

        # --- SQS: job queue + DLQ (Section 6: retry/DLQ) --- #
        job_dlq = sqs.Queue(self, "CropHealthJobDLQ", retention_period=Duration.days(14))
        job_queue = sqs.Queue(
            self,
            "CropHealthJobQueue",
            visibility_timeout=Duration.minutes(6),
            dead_letter_queue=sqs.DeadLetterQueue(max_receive_count=5, queue=job_dlq),
        )

        common_env = {
            "IMAGERY_CACHE_BUCKET": imagery_cache_bucket.bucket_name,
            "TILES_BUCKET": tiles_bucket.bucket_name,
            "REPORTS_BUCKET": reports_bucket.bucket_name,
            "JOB_QUEUE_URL": job_queue.queue_url,
            "JOB_DLQ_URL": job_dlq.queue_url,
            "AWS_REGION_NAME": self.region,
            "ENVIRONMENT": "prod",
        }

        lambda_code = _lambda.Code.from_asset(
            ".", exclude=["infra", "tests", ".venv", "__pycache__", "*.md"]
        )

        # --- API Lambda (Mangum-wrapped FastAPI) --- #
        api_lambda = _lambda.Function(
            self,
            "CropHealthApiLambda",
            runtime=_lambda.Runtime.PYTHON_3_12,
            handler="app.lambda_handlers.api_handler.handler",
            code=lambda_code,
            memory_size=512,
            timeout=Duration.seconds(30),
            environment=common_env,
        )
        provider_secrets.grant_read(api_lambda)
        job_queue.grant_send_messages(api_lambda)  # only send — API never consumes

        apigw.LambdaRestApi(self, "CropHealthApi", handler=api_lambda, proxy=True)

        # --- Worker Lambda (SQS-triggered, does the actual raster/LLM/push work) --- #
        worker_lambda = _lambda.Function(
            self,
            "CropHealthWorkerLambda",
            runtime=_lambda.Runtime.PYTHON_3_12,
            handler="app.lambda_handlers.worker_handler.handler",
            code=lambda_code,
            memory_size=1536,  # raster processing (rasterio/numpy) needs headroom
            timeout=Duration.minutes(5),
            environment=common_env,
        )
        provider_secrets.grant_read(worker_lambda)
        job_queue.grant_consume_messages(worker_lambda)
        imagery_cache_bucket.grant_read_write(worker_lambda)
        tiles_bucket.grant_write(worker_lambda)
        reports_bucket.grant_write(worker_lambda)
        worker_lambda.add_event_source(
            _lambda.EventSourceMapping(
                self,
                "WorkerQueueSource",
                target=worker_lambda,
                event_source_arn=job_queue.queue_arn,
                batch_size=5,
                report_batch_item_failures=True,
            )
        )

        # --- Dispatcher Lambda (schedule path) — ONE fixed-cadence rule, not
        #     one per field; see module docstring. --- #
        dispatcher_lambda = _lambda.Function(
            self,
            "CropHealthDispatcherLambda",
            runtime=_lambda.Runtime.PYTHON_3_12,
            handler="app.lambda_handlers.dispatcher_handler.handler",
            code=lambda_code,
            memory_size=256,
            timeout=Duration.minutes(2),
            environment=common_env,
        )
        job_queue.grant_send_messages(dispatcher_lambda)
        # Dispatcher only needs read on the fields/schedules tables via RDS —
        # RDS access is via the shared agrivisionai-prod-db security group /
        # Secrets Manager DB credential, wired outside this stack since the DB
        # is an existing shared resource (see README).

        events.Rule(
            self,
            "DispatcherDailySchedule",
            schedule=events.Schedule.cron(minute="0", hour="3"),  # 03:00 UTC daily
            targets=[targets.LambdaFunction(dispatcher_lambda)],
        )

        # --- S3 event trigger (event path) --- #
        s3_event_lambda = _lambda.Function(
            self,
            "CropHealthS3EventLambda",
            runtime=_lambda.Runtime.PYTHON_3_12,
            handler="app.lambda_handlers.s3_event_handler.handler",
            code=lambda_code,
            memory_size=256,
            timeout=Duration.seconds(30),
            environment=common_env,
        )
        job_queue.grant_send_messages(s3_event_lambda)
        imagery_cache_bucket.grant_read(s3_event_lambda)
        imagery_cache_bucket.add_event_notification(
            s3.EventType.OBJECT_CREATED,
            s3n.LambdaDestination(s3_event_lambda),
            s3.NotificationKeyFilter(prefix="raw/"),
        )
