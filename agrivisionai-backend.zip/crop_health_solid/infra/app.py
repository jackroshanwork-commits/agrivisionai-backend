#!/usr/bin/env python3
import aws_cdk as cdk

from infra.crop_health_stack import CropHealthStack

app = cdk.App()
CropHealthStack(
    app,
    "AgriVisionCropHealthStack",
    env=cdk.Environment(region="ap-south-1"),
)
app.synth()
