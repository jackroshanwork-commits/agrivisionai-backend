# Prompt: FastAPI Crop-Health Monitoring Job — AWS Scheduled + Event-Triggered

Use this prompt with a code-generation assistant (Claude Code, Cursor, etc.) to scaffold the service.

---

## PROMPT

You are a senior Python/AWS backend engineer. Build a production-ready **FastAPI** service that runs a **satellite crop-health monitoring job**, deployable on **AWS**, invocable both on a **schedule** (config-driven, per farm/field) and via an **event trigger** (new imagery available / new field boundary submitted / manual API call). Reference workflow to replicate functionally (not clone visually): https://earthsai.vercel.app/crop-health — draw a farm boundary, pick a date range, mask cropland, compute a monthly crop-health score, and produce map layers + chart data + an Excel report.

### 1. Functional requirements
- Accept a **field boundary** (GeoJSON polygon) and a **date range** as job input.
- Mask the area of interest to cropland only (exclude non-agricultural pixels).
- Pull satellite imagery for the AOI/date range from **Sentinel-2** (optical, NDVI/NDRE) and **Sentinel-1** (SAR, for cloud-cover fallback) via the **Copernicus Data Space Ecosystem (CDSE)** — the free, open-data EU program, not a paid third-party reseller — plus supplementary data from the **NASA POWER API** (rainfall, soil moisture, temperature — historical/near-real-time) and the **Open-Meteo API** (free, open-source, no API key, for multi-day **weather forecast** — NASA POWER does not provide forward-looking forecasts).
- Pull **soil health data** from AgriVision's existing soil health module/DB (or the same advisory pipeline that already feeds the app's fertilizer recommendations) — reuse rather than rebuild.
- Cropland masking should use a free, open dataset (e.g., **ESA WorldCover** or **ESA WorldCereal**, both public/open) rather than a paid land-classification API.
- Compute a **monthly crop-health score** per field (NDVI-based composite, cloud-masked, gap-filled).
- Generate outputs:
  - Map tile layers (GeoTIFF → COG → S3, served via CloudFront) for NDVI and health-score overlays.
  - Time-series chart data (JSON) of monthly health score, rainfall, soil moisture.
  - An **Excel report** (openpyxl/pandas) summarizing per-field monthly metrics.
- Persist job runs, field metadata, and results to **PostgreSQL** (reuse `agrivisionai-prod-db`, `ap-south-1` schema pattern if applicable).

### 2. Provider abstraction (commercial requirement)
This feature will sit behind a paid tier (Kisan Plus / FPO Enterprise), so the imagery source must be swappable without a rewrite:
- Define an `ImageryProvider` interface (e.g., `search(aoi, date_range) -> [SceneRef]`, `fetch(scene_ref) -> raster bands`) with a single **CDSE-backed implementation** for now.
- All CDSE-specific code (STAC queries, auth, band naming) stays inside that implementation — the job/worker logic and scoring math must not import CDSE directly.
- Provider choice is a config value (env var / DB setting), not a code branch, so switching to a paid provider (Sentinel Hub, Planet) later is a new implementation class plus a config change.
- Same pattern for the **cropland mask source** (`CroplandMaskProvider` interface) — start with ESA WorldCover/WorldCereal, but keep the door open to swapping in an in-house classifier later (AgriVision already has field-boundary and crop-type data from the app that could train one).

### 3. LLM crop-health reasoning & per-farmer push notification
After the score/outputs step, add a reasoning stage that turns raw signals into a farmer-facing advisory and decides whether to notify:
- **Inputs to the reasoning step**: NDVI time series + current value, the health-score heatmap/tile output, soil health data, weather history (NASA POWER), and weather forecast (Open-Meteo).
- **Reasoning engine**: call **Gemini** (reuse the same model already powering AgriVision's advisory chatbot, for consistency of tone/quality) with a structured prompt containing the above inputs; have it return **structured JSON** (risk level, likely cause, recommended action, confidence) plus a **plain-language message in the farmer's language** (Telugu/Kannada/Hindi/Tamil/English, matching existing multilingual materials) — don't let it free-text without a schema, or downstream automation can't act on it reliably.
- **Note on cost**: Gemini is a paid Google API, not free/open-source — flagged deliberately as an exception to the free/open constraint above, because AgriVision already depends on it for the chatbot. If a fully free/open stack is ever required end-to-end, the swappable alternative is a self-hosted open-weight model (e.g., Llama or Mistral via Bedrock or an in-house inference endpoint) — note this as a documented alternative, not the default.
- **Notification threshold**: only trigger an alert when the reasoning output crosses a configurable severity threshold (e.g., health-score drop beyond X%, disease-risk flag, adverse weather forecast in the next N days) — not on every run, to avoid alert fatigue on a paying farmer's phone.
- **Delivery channel: push notification, not SMS/WhatsApp.** On a threshold-crossing result, publish an event (EventBridge or SNS) keyed to that farmer/field ID, consumed by a dedicated notifier that sends a **mobile push notification** to the farmer's device — implement via a `NotificationProvider` interface with a default implementation on **Firebase Cloud Messaging (FCM)** (the app is Android on Play Store, so FCM is the natural fit) or, equivalently, **AWS SNS Mobile Push** targeting an FCM platform application if you want to stay inside the AWS SNS/Lambda notification stack already built for OTP. Store the farmer's device/registration token against their field/account record; handle stale-token cleanup (FCM/SNS returns an invalid-token error on send — deregister on that response instead of retrying indefinitely).
- Include the push payload's **data fields** (field ID, risk level, deep link into the app's crop-health screen for that field) alongside the display title/body, so tapping the notification opens the right screen — not just plain text.
- This reasoning + notification step should be **decoupled from the scoring job** (its own SQS-fed Lambda/step), so a slow or failed LLM call or push-send never blocks or delays the core NDVI/score computation and outputs.

### 4. Trigger mechanisms (both required)
- **Schedule config**: a per-field/per-FPO schedule (e.g., "run monthly on the 1st", cron expression) stored in the DB or a config table, materialized into **Amazon EventBridge Scheduler** rules that invoke the job (one schedule per active field, or a single dispatcher Lambda that fans out to all due fields).
- **Event trigger**: an **EventBridge rule** (or S3 `ObjectCreated` event / SNS topic) that fires the same job when new imagery lands in an S3 bucket, or when a client calls a `POST /jobs/crop-health/run` FastAPI endpoint for an ad-hoc run.
- Both paths should invoke the **same underlying job function** — don't duplicate logic between "scheduled" and "event" code paths.

### 5. Tech stack
- **FastAPI** for the HTTP API (job trigger endpoint, status/results endpoints, health check).
- **Mangum** adapter to run FastAPI on **AWS Lambda** behind **API Gateway** (or ECS Fargate if the imagery-processing step is too long/memory-heavy for Lambda — decide based on expected runtime and note the trade-off).
- **EventBridge Scheduler** for cron-based schedule config; **EventBridge Rules / S3 events** for event triggers.
- **SQS** as a buffer/dead-letter queue between trigger and worker, so retries don't hammer the imagery API.
- **S3** for raw imagery cache, processed COGs, and generated Excel reports; **CloudFront** for tile serving.
- **RDS PostgreSQL** (PostGIS enabled) for field boundaries, job runs, and computed metrics.
- **SNS** (optional) to notify on job completion/failure.
- **Imagery access — free/open-source only, no paid imagery API:**
  - **Copernicus Data Space Ecosystem (CDSE)** STAC API (`https://catalogue.dataspace.copernicus.eu`) to discover and fetch Sentinel-1/2 scenes — free registration, no usage billing, open data license.
  - **`pystac-client`** (open source, Apache 2.0) to query the STAC catalog; **`odc-stac`** or **`stackstac`** (open source) to load matched scenes directly into xarray for processing, instead of a paid tiling/processing backend.
  - Alternative/fallback source: the **Sentinel-2 COG archive on the AWS Open Data Registry** (`sentinel-cogs`, public S3 bucket, free to read from AWS compute in the same region) — useful since the job already runs on AWS, avoiding external egress entirely.
  - Do **not** use Sentinel Hub (paid beyond trial) or Google Earth Engine in commercial mode (see note below) — all imagery access here should route through free, open infrastructure.
- **rasterio / rio-cogeo / numpy** for raster processing (NDVI/NDRE math, cloud masking, compositing) — this replaces GEE's server-side compute; expect to run it inside your own Lambda/Fargate task, not a hosted processing engine.
- **geopandas / shapely** for AOI/cropland masking.
- **google-genai / Vertex AI SDK** (or the same Gemini client library AgriVision's chatbot already uses) for the LLM reasoning step.
- **firebase-admin** (Python SDK, for FCM push) or `boto3` SNS Mobile Push client — pick one per the `NotificationProvider` decision above.
- Infra as code: **AWS CDK (Python)** or **SAM** — pick one and scaffold it.

### 6. Production-grade architecture & code quality
This is a production system behind paying customers, not a script — structure it accordingly:
- **Layered architecture** with clear boundaries: `api/` (FastAPI routers + Pydantic request/response schemas only — no business logic), `domain/` (scoring math, reasoning-threshold logic — pure functions, no AWS/SDK imports), `providers/` (the `ImageryProvider`, `CroplandMaskProvider`, `NotificationProvider`, LLM-client implementations — all I/O lives here, behind interfaces defined in `domain/`), `infra/` (CDK/SAM stack, IAM, wiring). This is a ports-and-adapters (hexagonal) split, not a flat `main.py` with everything inline — it's what makes the provider swaps in Section 2 and this section's testing strategy actually work.
- **Dependency injection**: providers are constructed once (from config) and passed into the job/worker functions — never instantiated ad hoc inside business logic, so tests can substitute fakes.
- **Shared models module**: one `schemas/` (or `models/`) package for DTOs used across API, job, and provider boundaries (e.g., `FieldBoundary`, `SceneRef`, `HealthScoreResult`, `ReasoningResult`, `PushNotificationPayload`) — no duplicate/near-duplicate models redefined per file.
- **Custom exception hierarchy**: a base `CropHealthError`, with subclasses like `ImageryFetchError`, `CroplandMaskError`, `ScoringError`, `ReasoningError`, `NotificationDeliveryError`. Each carries enough context (field ID, job ID, upstream status) to log usefully and to map cleanly to an HTTP error response or a job-status value — don't let raw provider exceptions (e.g., `requests.HTTPError`, FCM SDK errors) leak past the provider boundary.
- **Structured JSON logging** with a **correlation/job ID** generated at trigger time and propagated through every downstream call (dispatcher → SQS message attributes → Lambda → provider calls → notification send), so one job run's full trace is greppable in CloudWatch by a single ID. Log at appropriate levels (`INFO` for lifecycle events, `WARNING` for retried failures, `ERROR` for exhausted retries/DLQ) — never log secrets, API keys, or farmer PII (phone numbers, device tokens) in plaintext.
- **Retry policy per external dependency**, not a single global retry: exponential backoff + jitter for CDSE/Open-Meteo/Gemini/FCM calls individually, since they fail differently (rate limits vs. timeouts vs. invalid-token errors) — invalid push tokens should deregister, not retry.
- **Circuit breaker** (or a simple failure-rate check) around the Gemini call specifically, so a sustained LLM outage falls back to the rule-based message (per Section 7) immediately instead of retrying and delaying every job in the queue.
- **Config via a typed settings object** (`pydantic-settings`), loaded from environment variables / AWS Secrets Manager — no hardcoded endpoints, thresholds, or credentials in code.
- **Tests**: unit tests for domain/scoring logic with no AWS dependency; provider tests using recorded fixtures (e.g., `vcrpy` or saved STAC/Gemini responses) rather than live calls in CI; integration tests against `moto`/LocalStack for the AWS wiring (S3, SQS, EventBridge). Include at least one test per custom exception path (what happens when CDSE times out, when Gemini returns malformed JSON, when a push token is stale).
- **Observability**: emit CloudWatch custom metrics for job success/failure rate, per-provider latency, and notification delivery rate; a CloudWatch alarm on DLQ depth and on notification failure rate, so a broken push pipeline is caught operationally, not just discovered when a farmer complains.
- **Security**: least-privilege IAM per Lambda (the reasoning/notification Lambda shouldn't have S3 write access it doesn't need, etc.), secrets in Secrets Manager (not env-var plaintext) for the CDSE, Gemini, and FCM credentials, and input validation on every FastAPI endpoint (Pydantic models with constraints, not just type hints).

### 7. Operational resilience
- Idempotent job runs (safe to re-trigger for the same field/month without duplicating results or double-sending a push notification).
- **Graceful degradation on provider outage**: if the imagery provider fails after retries, the API/UI should be able to serve the *last successful* score for that field with a "refresh pending" flag, rather than erroring out to a paying customer.
- **LLM call resilience**: timeout + retry on the Gemini call, and if it fails entirely (or the circuit breaker in Section 6 is open), fall back to a deterministic rule-based message (e.g., templated "health score dropped X%" text) rather than skipping the farmer notification outright.
- Include a `docker-compose.yml` for local dev (FastAPI + local Postgres/PostGIS) so the job can be tested without deploying.
- Cost awareness: batch/fan-out design should avoid one Lambda invocation per field per minute — dispatcher pattern that checks "which fields are due" and enqueues only those.

### 8. Deliverables to generate
1. FastAPI app structure (`app/main.py`, routers, Pydantic schemas for job request/response).
2. Job/worker module (imagery fetch → cropland mask → NDVI/health score → outputs) callable from both the API and the Lambda event handlers, written against the `ImageryProvider`/`CroplandMaskProvider` interfaces — not against CDSE calls directly.
3. CDK/SAM stack: API Gateway + Lambda (or Fargate task), EventBridge Scheduler + Rule, S3 buckets, SQS queue, RDS/PostGIS reference (or connection to existing DB), IAM roles scoped to least privilege.
4. Schedule-config table/model + a small "dispatcher" that turns DB schedule rows into EventBridge Scheduler entries (or evaluates due fields directly).
5. Tier gate: a check (feature flag / subscription-tier lookup) so the job only runs for fields belonging to paid (Kisan Plus / FPO Enterprise) accounts, not the free tier.
6. `README.md` with local run instructions, deployment steps (`cdk deploy` / `sam deploy`), and a short "how to add a new imagery/cropland-mask provider" note demonstrating the abstraction actually works.
7. LLM reasoning module (prompt template, structured-output schema, threshold config) + push-notification dispatcher (`NotificationProvider` implementation, device-token store, stale-token cleanup) that resolves a field to its farmer's device and fires the push event.

### 9. Cost constraint
Every library and service in this build must be **free and open source**, or a free-tier/no-cost public service (Copernicus Data Space Ecosystem, NASA POWER, ESA WorldCover, AWS Open Data), for the default (CDSE) provider implementation. The `ImageryProvider` abstraction exists specifically so a paid provider (Sentinel Hub, Planet) can be swapped in later — as a new implementation, not a rewrite — once usage/reliability numbers justify the spend. No proprietary SaaS processing layer for now; raster processing compute runs on your own AWS resources (Lambda/Fargate), so size the compute step accordingly and call out expected runtime/memory in the response.

### 10. Output format
Produce the code as a working repo structure (file tree + full file contents), not snippets. Call out any assumption you had to make (e.g., Lambda vs. Fargate for the raster-processing step, STAC catalog query parameters) explicitly at the top of the response.

---

*Notes for reuse: swap in the real RDS endpoint and your S3 bucket names before deploying; register a free CDSE account for API credentials. If field boundaries already exist in the AgriVision mobile app (Kotlin/MapLibre/JTS/Room), point the FastAPI ingestion endpoint at that existing boundary-export format instead of expecting raw GeoJSON from scratch.*

*Revisit the paid-provider swap once FPO Enterprise accounts scale (rough trigger: ~30–50 paid FPO accounts, or post-funding) — the abstraction layer is what makes that a config change instead of a re-architecture. ESA WorldCover is frozen at 2020/2021; treat the current cropland mask as a placeholder and consider training an in-house classifier off the field-boundary/crop-type data already collected in the app once volume supports it.*
