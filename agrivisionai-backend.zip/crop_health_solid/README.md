# AgriVision Crop Health Service

FastAPI service that computes a monthly, per-field crop-health score from
Sentinel-2 imagery, asks an LLM (with a rule-based fallback) for advice, and
pushes a notification to the farmer when something needs attention.
Deployable on AWS (Lambda + SQS + EventBridge), runnable locally with Docker.

> New to the code? Start with **[docs/SOLID_GUIDE.md](docs/SOLID_GUIDE.md)**.
> It explains the structure and the SOLID principles using this project.

## Assumptions called out explicitly

- **Lambda, not Fargate, for the worker.** A single field's monthly composite
  (a handful of Sentinel-2 scenes, cropland-masked) comfortably fits inside
  Lambda's 15-minute timeout and the 1.5GB memory allocated in the CDK stack.
  If a customer's field is unusually large, or you start backfilling many
  months at once, that math changes — swap `CropHealthWorkerLambda` for an ECS
  Fargate task in `infra/crop_health_stack.py` at that point; the job function
  itself (`app/jobs/crop_health_job.py`) doesn't change either way.
- **Planet Insights imagery**: `planet_insights_provider.py` finds scenes with
  the Catalog API (`sentinel-2-l2a`) and gets each band from the Process API,
  already cut to the field, so full Sentinel-2 tiles are never downloaded. You
  need a Planet Insights OAuth client (`PLANET_CLIENT_ID` /
  `PLANET_CLIENT_SECRET`). Sentinel-1 SAR fallback (for persistent cloud cover)
  is wired into the `ImageryProvider` interface but not implemented — add a
  second `search()` path keyed on `sentinel-1-grd` when you need it. Planet's
  own satellites (PlanetScope/SkySat) need a paid data subscription and would
  be a separate provider class.
- **Sharp field photo from Planet**: set `PLANET_IMAGERY_COLLECTION_ID` (the
  `byoc-...` id you get when you order or subscribe to PlanetScope/SkySat) and
  `PREVIEW_SOURCE=planet`. `planet_preview.py` then cuts the field's box out of
  that collection (newest picture in the last `PLANET_PHOTO_LOOKBACK_DAYS`
  days). If it is unset, or Planet has no picture, the photo falls back to
  Esri, then Sentinel-2.
- **Reprojection between the cropland mask and the NDVI raster grid is not
  implemented** (`raster_processing.apply_cropland_mask` raises `ScoringError`
  if the grids don't already match) — in production this needs
  `rasterio.warp.reproject` to align the ESA WorldCover grid to each scene's
  native grid before masking. Flagged loudly rather than silently wrong.
- **Tile GeoTIFF generation and upload is stubbed** in `crop_health_job.py`
  (`ndvi_tile_url`/`health_score_tile_url` are `None` today) — the raster
  arrays are computed but not yet re-encoded as GeoTIFF and pushed through
  `OutputsStorage.upload_tile`. Wire that in once the tile-serving format
  (single-band vs. RGB-composite, color ramp) is decided.

## How a job runs

`CropHealthJob.run()` (in `app/jobs/crop_health_job.py`) is the single
implementation used by every trigger:

1. load the field  2. remember the previous score  3. calculate the new score
4. save it  5. gather weather/soil + ask the reasoning engine  6. notify the farmer
7. save and return the result

| Trigger | Entry point |
|---|---|
| Schedule (daily EventBridge) | `lambda_handlers/dispatcher_handler.py` -> queue |
| New imagery in S3 | `lambda_handlers/s3_event_handler.py` -> queue |
| Worker (SQS) | `lambda_handlers/worker_handler.py` |
| Manual API | `POST /jobs/crop-health/start` (background) or `/run` (wait) |

## Project layout

```
app/domain/          rules, data shapes and interfaces (no I/O)
app/jobs/            use cases (job, score calculator, notifier, dispatcher, ...)
app/providers/       real tools: Planet Insights, Groq, FCM, SQS, Postgres, ...
app/api/             HTTP routes
app/lambda_handlers/ AWS entry points
app/container.py     the only place that chooses and connects real classes
tests/               unit tests (fakes in tests/fakes.py)
```

## Run it

```bash
cp .env.example .env            # then fill in what you need
docker compose up -d db
pip install -r requirements.txt
python scripts/init_db.py
uvicorn app.main:app --reload
```

No API keys yet? Use `REASONING_PROVIDER=rule_based_only` and
`NOTIFICATION_PROVIDER=noop`.

## Test it

```bash
pytest            # ~115 tests, a few seconds, no network or AWS needed
```

## Adding a provider

Write a class that implements the interface in `app/domain/interfaces.py`,
register it in `app/providers/factories.py`, set the matching env var.
Step-by-step example: [docs/SOLID_GUIDE.md](docs/SOLID_GUIDE.md#3-o--openclosed).
