from __future__ import annotations

import base64
import io

import httpx
import numpy as np
import respx
from affine import Affine
from PIL import Image

from app.domain.models import ScenePreview
from app.providers.imagery import high_res_preview as hr
from app.providers.imagery.true_color_preview import _upscale
from tests.fakes import FakePreviewBuilder, make_scene

AOI = {
    "type": "Polygon",
    "coordinates": [[[78.119, 9.924], [78.1205, 9.924], [78.1205, 9.9255], [78.119, 9.9255], [78.119, 9.924]]],
}


def _png(w=400, h=400) -> bytes:
    buf = io.BytesIO()
    Image.fromarray(np.full((h, w, 3), 90, "uint8")).save(buf, format="PNG")
    return buf.getvalue()


def test_padded_bbox_is_bigger_than_field():
    min_lon, min_lat, max_lon, max_lat = hr.padded_bbox(AOI)
    assert min_lon < 78.119 and max_lon > 78.1205 and min_lat < 9.924 and max_lat > 9.9255


def test_esri_params_keep_aspect_and_cap_size():
    p = hr.esri_params((78.0, 9.0, 78.002, 9.001), 5000)
    w, h = map(int, p["size"].split(","))
    assert max(w, h) == 2048 and w > h and p["bboxSR"] == 3857


@respx.mock
def test_builds_preview_and_downloads_once_for_two_scenes():
    route = respx.get(hr.ESRI_EXPORT_URL).mock(
        return_value=httpx.Response(200, content=_png(), headers={"content-type": "image/png"})
    )
    builder = hr.EsriPreviewBuilder(http_client=httpx.Client())
    a = builder.build(make_scene("a", 5), AOI)
    b = builder.build(make_scene("b", 5), AOI)
    assert a is b and route.call_count == 1
    assert a.source == hr.ESRI_SOURCE and a.data_url.startswith("data:image/jpeg;base64,")
    (south, west), (north, east) = a.bounds
    assert south < north and west < east
    Image.open(io.BytesIO(base64.b64decode(a.data_url.split(",")[1])))  # valid JPEG


@respx.mock
def test_json_error_with_http_200_gives_none():
    respx.get(hr.ESRI_EXPORT_URL).mock(
        return_value=httpx.Response(200, json={"error": "bad"}, headers={"content-type": "application/json"})
    )
    assert hr.EsriPreviewBuilder(http_client=httpx.Client()).build(make_scene("a", 5), AOI) is None


def test_fallback_used_when_primary_fails_or_returns_none():
    class Boom(FakePreviewBuilder):
        def build(self, scene, aoi):
            raise RuntimeError("x")

    class Nothing(FakePreviewBuilder):
        def build(self, scene, aoi):
            return None

    for primary in (Boom(), Nothing()):
        got = hr.FallbackPreviewBuilder(primary, FakePreviewBuilder()).build(make_scene("s", 1), AOI)
        assert isinstance(got, ScenePreview) and got.data_url.endswith("s")


def test_sentinel_upscale_enlarges_and_keeps_extent():
    rgb = np.random.default_rng(0).integers(0, 255, (3, 30, 40)).astype("uint8")
    t = Affine(10, 0, 500000, 0, -10, 1100000)
    big, t2 = _upscale(rgb, t)
    assert max(big.shape[1:]) == 1024
    # same ground extent before and after
    assert abs(t2.a * big.shape[2] - t.a * 40) < 1e-6
    assert abs(t2.e * big.shape[1] - t.e * 30) < 1e-6
