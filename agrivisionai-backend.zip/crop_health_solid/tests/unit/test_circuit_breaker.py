from __future__ import annotations

import time

import pytest

from app.providers.reasoning.circuit_breaker import CircuitBreaker, CircuitOpenError


def test_circuit_starts_closed():
    cb = CircuitBreaker(fail_max=3, reset_timeout_seconds=60)
    assert cb.state == "closed"
    cb.guard()  # should not raise


def test_circuit_opens_after_fail_max_consecutive_failures():
    cb = CircuitBreaker(fail_max=3, reset_timeout_seconds=60)
    for _ in range(3):
        cb.record_failure()
    assert cb.state == "open"
    with pytest.raises(CircuitOpenError):
        cb.guard()


def test_circuit_success_resets_failure_count():
    cb = CircuitBreaker(fail_max=3, reset_timeout_seconds=60)
    cb.record_failure()
    cb.record_failure()
    cb.record_success()
    cb.record_failure()  # only 1 consecutive failure now, should not open
    assert cb.state == "closed"
    cb.guard()  # does not raise


def test_circuit_half_opens_after_reset_timeout():
    cb = CircuitBreaker(fail_max=1, reset_timeout_seconds=0)  # immediate reset for test speed
    cb.record_failure()
    assert cb.state == "open"
    time.sleep(0.01)
    cb.guard()  # should transition to half-open and not raise
    assert cb.state == "half_open"


def test_half_open_failure_reopens_circuit():
    cb = CircuitBreaker(fail_max=1, reset_timeout_seconds=0)
    cb.record_failure()
    time.sleep(0.01)
    cb.guard()  # -> half_open
    cb.record_failure()
    assert cb.state == "open"
