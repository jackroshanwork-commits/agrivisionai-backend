"""CropHealthJob tests: the whole use case, with fakes instead of real services."""
from __future__ import annotations

import uuid
from datetime import date

import pytest

from app.domain.models import (
    CropHealthJobRequest,
    DateRange,
    JobStatus,
    RiskLevel,
)
from app.jobs.crop_health_job import CropHealthJob
from app.jobs.farmer_notifier import FarmerNotifier
from app.jobs.health_score_calculator import HealthScoreCalculator
from app.jobs.reasoning_context import ReasoningContextGatherer
from app.jobs.score_history import ScoreHistory
from app.providers.reasoning.fallback_provider import FallbackReasoningProvider
from tests.fakes import (
    FakeAnalyzer,
    FakeCroplandMask,
    FakeImagery,
    FakePreviewBuilder,
    FakeSoil,
    FakeWeatherForecast,
    FakeWeatherHistory,
    FailingImagery,
    InMemoryDeviceTokenRepository,
    InMemoryFieldRepository,
    InMemoryJobRunRepository,
    RecordingNotifier,
    StubReasoner,
    make_scene,
)

PERIOD = DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))


class Setup:
    """Builds a CropHealthJob out of fakes. Override only what a test cares about."""

    def __init__(self, field, *, imagery=None, ndvi=(0.6,), reasoner=None, push=None,
                 history=None, forecast=None, token="token-123", job_runs=None):
        self.job_runs = job_runs or InMemoryJobRunRepository()
        self.analyzer = FakeAnalyzer(list(ndvi))
        self.push = push or RecordingNotifier()
        self.reasoner = reasoner or StubReasoner()
        self.device_tokens = InMemoryDeviceTokenRepository(token)
        calculator = HealthScoreCalculator(
            imagery=imagery or FakeImagery([make_scene("s1", 5.0)]),
            cropland_mask=FakeCroplandMask(),
            scene_analyzer=self.analyzer,
            preview_builder=FakePreviewBuilder(),
            cloud_cover_threshold_pct=20.0,
        )
        self.job = CropHealthJob(
            fields=InMemoryFieldRepository(field),
            job_runs=self.job_runs,
            score_history=ScoreHistory(self.job_runs),
            calculator=calculator,
            context_gatherer=ReasoningContextGatherer(
                history or FakeWeatherHistory(), forecast or FakeWeatherForecast(), FakeSoil()
            ),
            reasoner=self.reasoner,
            notifier=FarmerNotifier(self.device_tokens, self.push),
        )

    def run(self, field_id):
        return self.job.run(CropHealthJobRequest(field_id=field_id, date_range=PERIOD))


def test_happy_path_scores_reasons_and_notifies(sample_field):
    s = Setup(sample_field)
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.SUCCEEDED
    assert result.health_score.ndvi_mean == pytest.approx(0.6)
    assert result.reasoning.risk_level == RiskLevel.HIGH
    assert result.notification.delivered is True
    assert len(s.push.sent) == 1


def test_unknown_field_fails_cleanly(sample_field):
    s = Setup(sample_field)
    result = s.run(uuid.uuid4())

    assert result.status == JobStatus.FAILED
    assert "not found" in result.error
    assert result.health_score is None


def test_no_notification_when_reasoning_says_not_needed(sample_field):
    s = Setup(sample_field, reasoner=StubReasoner(risk=RiskLevel.LOW, should_notify=False))
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.SUCCEEDED
    assert result.notification is None
    assert s.push.sent == []


def test_no_device_token_is_not_an_error(sample_field):
    s = Setup(sample_field, token=None)
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.SUCCEEDED
    assert result.notification is None


def test_scoring_failure_serves_last_good_score_with_error(sample_field):
    s = Setup(sample_field)
    first = s.run(sample_field.field_id)  # saves a good score

    broken = Setup(sample_field, imagery=FailingImagery(), job_runs=s.job_runs)  # same history
    result = broken.run(sample_field.field_id)

    assert result.status == JobStatus.FAILED
    assert "serving last successful score" in result.error
    assert result.health_score.health_score == first.health_score.health_score


def test_scoring_failure_without_history_has_no_score(sample_field):
    s = Setup(sample_field, imagery=FailingImagery())
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.FAILED
    assert result.health_score is None


def test_optional_data_failures_do_not_fail_the_job(sample_field):
    s = Setup(
        sample_field,
        history=FakeWeatherHistory(fail=True),
        forecast=FakeWeatherForecast(fail=True),
    )
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.SUCCEEDED
    assert s.reasoner.inputs[0].weather_history is None
    assert s.reasoner.inputs[0].weather_forecast is None


def test_reasoning_failure_keeps_the_score(sample_field):
    s = Setup(sample_field, reasoner=StubReasoner(fail=True))
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.SUCCEEDED
    assert result.health_score is not None
    assert result.reasoning is None


def test_fallback_reasoner_takes_over_when_primary_fails(sample_field):
    reasoner = FallbackReasoningProvider(
        primary=StubReasoner(fail=True, name="primary"),
        fallback=StubReasoner(name="fallback"),
    )
    s = Setup(sample_field, reasoner=reasoner)
    result = s.run(sample_field.field_id)

    assert result.reasoning.generated_by == "fallback"


def test_stale_token_is_deregistered(sample_field):
    s = Setup(sample_field, push=RecordingNotifier(stale=True))
    s.run(sample_field.field_id)

    assert s.device_tokens.deregistered == ["token-123"]


def test_notification_failure_does_not_fail_the_job(sample_field):
    s = Setup(sample_field, push=RecordingNotifier(fail=True))
    result = s.run(sample_field.field_id)

    assert result.status == JobStatus.SUCCEEDED
    assert result.notification.delivered is False


def test_previous_score_is_the_OLD_one_not_the_one_just_calculated(sample_field):
    """Regression: the previous score must be read before the new one is saved,
    otherwise every run would be compared with itself (always a 0% change)."""
    s = Setup(sample_field, ndvi=(0.6,))
    first = s.run(sample_field.field_id)
    s.analyzer.queue(0.3)  # a much worse second month
    s.run(sample_field.field_id)

    seen_previous = s.reasoner.inputs[1].previous_health_score
    assert seen_previous.health_score == first.health_score.health_score


def test_final_result_is_persisted(sample_field):
    s = Setup(sample_field)
    result = s.run(sample_field.field_id)

    final = s.job_runs.completions[-1]
    assert final["job_id"] == result.job_id
    assert final["status"] == JobStatus.SUCCEEDED
    assert final["result_json"]["reasoning"] is not None
