from __future__ import annotations

from datetime import date

import pytest

from app.domain.models import HealthScoreResult, RiskLevel, WeatherForecast
from app.domain.reasoning_rules import (
    build_rule_based_reasoning,
    determine_risk_level,
    should_notify,
)


def _score(field_id, value, period_start=date(2026, 7, 1)):
    return HealthScoreResult(
        field_id=field_id,
        period_start=period_start,
        period_end=date(2026, 7, 31),
        ndvi_mean=0.5,
        ndvi_min=0.4,
        ndvi_max=0.6,
        health_score=value,
        cloud_cover_pct=10.0,
        scenes_used=["s1"],
        cropland_mask_source="esa_worldcover_2021",
    )


def test_determine_risk_level_stable_score_is_low(field_id, calm_forecast):
    current = _score(field_id, 70.0)
    previous = _score(field_id, 71.0)
    risk, delta = determine_risk_level(current, previous, calm_forecast)
    assert risk == RiskLevel.LOW


def test_determine_risk_level_moderate_drop_is_high(field_id, calm_forecast):
    current = _score(field_id, 60.0)
    previous = _score(field_id, 75.0)  # -20% drop
    risk, delta = determine_risk_level(
        current, previous, calm_forecast,
        score_drop_threshold_pct=15.0, critical_score_drop_threshold_pct=30.0,
    )
    assert risk == RiskLevel.HIGH
    assert delta == pytest.approx(-20.0, abs=0.1)


def test_determine_risk_level_severe_drop_is_critical(field_id, calm_forecast):
    current = _score(field_id, 40.0)
    previous = _score(field_id, 80.0)  # -50% drop
    risk, delta = determine_risk_level(
        current, previous, calm_forecast,
        score_drop_threshold_pct=15.0, critical_score_drop_threshold_pct=30.0,
    )
    assert risk == RiskLevel.CRITICAL


def test_determine_risk_level_adverse_forecast_escalates_from_low(field_id):
    current = _score(field_id, 70.0)
    previous = _score(field_id, 71.0)
    adverse = WeatherForecast(
        field_id=field_id,
        forecast_days=7,
        daily_rainfall_mm=[80.0, 0, 0, 0, 0, 0, 0],
        daily_avg_temp_c=[30] * 7,
        adverse_weather_flag=True,
        adverse_weather_reason="heavy rainfall forecast",
    )
    risk, _ = determine_risk_level(current, previous, adverse)
    assert risk == RiskLevel.MODERATE


def test_determine_risk_level_no_previous_score_defaults_to_low(field_id, calm_forecast):
    current = _score(field_id, 70.0)
    risk, delta = determine_risk_level(current, None, calm_forecast)
    assert risk == RiskLevel.LOW
    assert delta is None


@pytest.mark.parametrize(
    "risk,expected",
    [
        (RiskLevel.LOW, False),
        (RiskLevel.MODERATE, True),
        (RiskLevel.HIGH, True),
        (RiskLevel.CRITICAL, True),
    ],
)
def test_should_notify_thresholds(risk, expected):
    assert should_notify(risk) is expected


def test_rule_based_fallback_always_succeeds_and_matches_schema(field_id, calm_forecast):
    current = _score(field_id, 55.0)
    previous = _score(field_id, 80.0)  # big drop -> should be HIGH/CRITICAL and notify
    result = build_rule_based_reasoning(
        health_score=current,
        previous_health_score=previous,
        weather_forecast=calm_forecast,
        field_name="North Paddy Field",
    )
    assert result.generated_by == "rule_based_fallback"
    assert result.field_id == field_id
    assert 0.0 <= result.confidence <= 1.0
    assert "North Paddy Field" in result.message_farmer_language
    assert result.should_notify is True


def test_rule_based_fallback_stable_field_does_not_notify(field_id, calm_forecast):
    current = _score(field_id, 70.0)
    previous = _score(field_id, 71.0)
    result = build_rule_based_reasoning(
        health_score=current,
        previous_health_score=previous,
        weather_forecast=calm_forecast,
        field_name="Stable Field",
    )
    assert result.risk_level == RiskLevel.LOW
    assert result.should_notify is False
