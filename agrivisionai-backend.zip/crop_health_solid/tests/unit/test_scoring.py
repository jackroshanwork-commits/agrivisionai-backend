from __future__ import annotations

import pytest

from app.domain.exceptions import ScoringError
from app.domain.scoring import (
    composite_ndvi,
    compute_ndvi,
    filter_scenes_by_cloud_cover,
    health_score_delta_pct,
    ndvi_to_health_score,
)


def test_compute_ndvi_healthy_vegetation():
    # NIR >> RED is characteristic of healthy vegetation
    ndvi = compute_ndvi(red=0.1, nir=0.5)
    assert ndvi == pytest.approx(0.667, abs=0.01)


def test_compute_ndvi_bare_soil_or_water():
    ndvi = compute_ndvi(red=0.3, nir=0.25)
    assert ndvi < 0


def test_compute_ndvi_clamped_to_valid_range():
    # Pathological inputs shouldn't produce values outside [-1, 1]
    ndvi = compute_ndvi(red=-10, nir=5)
    assert -1.0 <= ndvi <= 1.0


def test_compute_ndvi_zero_denominator_raises():
    with pytest.raises(ScoringError):
        compute_ndvi(red=0.0, nir=0.0)


def test_filter_scenes_by_cloud_cover_keeps_clear_scenes():
    scenes = [("a", 10.0), ("b", 60.0), ("c", 35.0)]
    survivors = filter_scenes_by_cloud_cover(scenes, threshold_pct=40.0)
    assert survivors == ["a", "c"]


def test_filter_scenes_by_cloud_cover_all_excluded_raises():
    scenes = [("a", 90.0), ("b", 95.0)]
    with pytest.raises(ScoringError):
        filter_scenes_by_cloud_cover(scenes, threshold_pct=40.0)


def test_composite_ndvi_computes_mean_min_max():
    mean, mn, mx = composite_ndvi([0.4, 0.6, 0.5])
    assert mean == pytest.approx(0.5)
    assert mn == 0.4
    assert mx == 0.6


def test_composite_ndvi_empty_raises():
    with pytest.raises(ScoringError):
        composite_ndvi([])


@pytest.mark.parametrize(
    "ndvi_mean,expected_low,expected_high",
    [
        (0.15, 0, 1),      # floor -> near 0
        (0.75, 99, 100),   # ceiling -> near 100
        (0.45, 45, 55),    # midpoint -> roughly mid-range
    ],
)
def test_ndvi_to_health_score_bounds(ndvi_mean, expected_low, expected_high):
    score = ndvi_to_health_score(ndvi_mean)
    assert expected_low <= score <= expected_high


def test_ndvi_to_health_score_out_of_range_input_is_clamped():
    assert ndvi_to_health_score(-1.0) == ndvi_to_health_score(0.15)
    assert ndvi_to_health_score(1.0) == ndvi_to_health_score(0.75)


def test_health_score_delta_pct_positive_change():
    assert health_score_delta_pct(current=60.0, previous=50.0) == pytest.approx(20.0)


def test_health_score_delta_pct_no_previous_returns_none():
    assert health_score_delta_pct(current=60.0, previous=None) is None


def test_health_score_delta_pct_zero_previous_returns_none():
    assert health_score_delta_pct(current=60.0, previous=0.0) is None
