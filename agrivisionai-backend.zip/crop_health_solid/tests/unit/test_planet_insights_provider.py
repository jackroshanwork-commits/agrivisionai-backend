"""Tests for the Planet Insights imagery provider. No real network: every
call to Planet is answered by `respx`."""
from __future__ import annotations

import json
from datetime import date, datetime, timezone

import httpx
import pytest
import respx
from rasterio.io import MemoryFile

from app.config import Settings
from app.domain.exceptions import ImageryFetchError
from app.domain.models import DateRange, SceneRef
from app.providers.common import retry_policies
from app.providers.factories import imagery_registry
from app.providers.imagery.planet_insights_provider import PlanetInsightsImageryProvider

AUTH = "https://auth.test/token"
CATALOG = "https://planet.test/catalog/1.0.0"
PROCESS = "https://planet.test/process"

# A ~200 m x 200 m field near Madurai, India (UTM zone 44N).
AOI = {
    "type": "Polygon",
    "coordinates": [[[78.1000, 9.9000], [78.1020, 9.9000], [78.1020, 9.9020], [78.1000, 9.9020], [78.1000, 9.9000]]],
}


@pytest.fixture(autouse=True)
def no_retry_sleep(monkeypatch):
    """Retries must not slow the tests down."""
    import tenacity

    monkeypatch.setattr(tenacity.nap.time, "sleep", lambda _s: None)


def make_settings(**overrides) -> Settings:
    values = dict(
        planet_client_id="id",
        planet_client_secret="secret",
        planet_auth_url=AUTH,
        planet_catalog_url=CATALOG,
        planet_process_url=PROCESS,
    )
    values.update(overrides)
    return Settings(_env_file=None, **values)


def token_route(mock: respx.MockRouter, expires_in: int = 3600):
    return mock.post(AUTH).respond(200, json={"access_token": "tok", "expires_in": expires_in})


def feature(scene_id: str, when: str, cloud: float | None):
    props = {"datetime": when}
    if cloud is not None:
        props["eo:cloud_cover"] = cloud
    return {"id": scene_id, "properties": props}


def scene(day: int = 10) -> SceneRef:
    return SceneRef(
        scene_id="S2_X",
        collection="sentinel-2-l2a",
        sensed_at=datetime(2026, 9, day, 5, 10, 0, tzinfo=timezone.utc),
        cloud_cover_pct=5.0,
        provider="planet_insights",
        aoi_geojson=AOI,
    )


def tiny_tiff() -> bytes:
    import numpy as np
    from rasterio.transform import from_origin

    with MemoryFile() as mem:
        with mem.open(
            driver="GTiff", width=2, height=2, count=1, dtype="float32",
            crs="EPSG:32644", transform=from_origin(500000, 1100000, 10, 10),
        ) as dst:
            dst.write(np.ones((1, 2, 2), dtype="float32"))
        return mem.read()


def geotiff_for_request(request: httpx.Request, value: float) -> httpx.Response:
    """Answer like Planet would: a GeoTIFF exactly covering the requested box."""
    import numpy as np
    from rasterio.transform import from_origin

    body = json.loads(request.content)
    x0, y0, x1, y1 = body["input"]["bounds"]["bbox"]
    w, h = body["output"]["width"], body["output"]["height"]
    epsg = body["input"]["bounds"]["properties"]["crs"].rsplit("/", 1)[-1]
    with MemoryFile() as mem:
        with mem.open(
            driver="GTiff", width=w, height=h, count=1, dtype="float32",
            crs=f"EPSG:{epsg}", transform=from_origin(x0, y1, (x1 - x0) / w, (y1 - y0) / h),
        ) as dst:
            dst.write(np.full((1, h, w), value, dtype="float32"))
        return httpx.Response(200, content=mem.read(), headers={"content-type": "image/tiff"})


# ------------------------------ registry ----------------------------------- #

def test_registered_under_planet_insights_name():
    provider = imagery_registry.create("planet_insights", make_settings())
    assert isinstance(provider, PlanetInsightsImageryProvider)


def test_cdse_is_gone():
    with pytest.raises(ValueError, match="Unknown"):
        imagery_registry.create("cdse", make_settings())


# -------------------------------- search ----------------------------------- #

@respx.mock
def test_search_sends_aoi_and_dates_and_maps_scenes():
    token_route(respx.mock)
    route = respx.post(f"{CATALOG}/search").respond(
        200,
        json={
            "features": [
                feature("A", "2026-09-05T05:10:00Z", 3.5),
                feature("B", "2026-09-10T05:10:00Z", None),
            ],
            "context": {},
        },
    )
    provider = PlanetInsightsImageryProvider(make_settings())
    scenes = provider.search(AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30)))

    body = json.loads(route.calls.last.request.content)
    assert body["collections"] == ["sentinel-2-l2a"]
    assert body["intersects"] == AOI
    assert body["datetime"] == "2026-09-01T00:00:00Z/2026-09-30T23:59:59Z"
    assert route.calls.last.request.headers["authorization"] == "Bearer tok"

    assert [s.scene_id for s in scenes] == ["A", "B"]
    assert scenes[0].cloud_cover_pct == 3.5
    assert scenes[1].cloud_cover_pct is None  # unknown stays unknown
    assert all(s.provider == "planet_insights" and s.aoi_geojson == AOI for s in scenes)


@respx.mock
def test_search_follows_pagination():
    token_route(respx.mock)
    route = respx.post(f"{CATALOG}/search")
    route.side_effect = [
        httpx.Response(200, json={"features": [feature("A", "2026-09-05T05:10:00Z", 1)], "context": {"next": 7}}),
        httpx.Response(200, json={"features": [feature("B", "2026-09-06T05:10:00Z", 2)], "context": {}}),
    ]
    scenes = PlanetInsightsImageryProvider(make_settings()).search(
        AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))
    )
    assert [s.scene_id for s in scenes] == ["A", "B"]
    assert json.loads(route.calls[1].request.content)["next"] == 7


@respx.mock
def test_search_keeps_clearest_scene_per_day():
    token_route(respx.mock)
    respx.post(f"{CATALOG}/search").respond(
        200,
        json={
            "features": [
                feature("tile1", "2026-09-05T05:10:00Z", 40),
                feature("tile2", "2026-09-05T05:10:02Z", 10),
                feature("other-day", "2026-09-10T05:10:00Z", 50),
            ]
        },
    )
    scenes = PlanetInsightsImageryProvider(make_settings()).search(
        AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))
    )
    assert [s.scene_id for s in scenes] == ["tile2", "other-day"]


@respx.mock
def test_search_error_is_translated():
    token_route(respx.mock)
    respx.post(f"{CATALOG}/search").respond(400, text="bad request")
    with pytest.raises(ImageryFetchError, match="HTTP 400") as err:
        PlanetInsightsImageryProvider(make_settings()).search(
            AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))
        )
    assert err.value.upstream_status == 400


@respx.mock
def test_search_retries_then_reports_retryable():
    token_route(respx.mock)
    route = respx.post(f"{CATALOG}/search").respond(503)
    with pytest.raises(ImageryFetchError) as err:
        PlanetInsightsImageryProvider(make_settings()).search(
            AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))
        )
    assert err.value.retryable is True
    assert route.call_count == 4  # rate_limited_retry: 4 attempts


# ------------------------------- download ---------------------------------- #

@respx.mock
def test_fetch_band_builds_process_request_and_returns_bytes():
    token_route(respx.mock)
    route = respx.post(PROCESS).respond(200, content=tiny_tiff(), headers={"content-type": "image/tiff"})
    out = PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["B04", "B08"])

    assert set(out) == {"B04", "B08"} and all(out.values())
    first = json.loads(route.calls[0].request.content)
    assert first["input"]["data"][0]["type"] == "sentinel-2-l2a"
    assert first["input"]["data"][0]["dataFilter"]["timeRange"] == {
        "from": "2026-09-10T04:40:00Z",
        "to": "2026-09-10T05:40:00Z",
    }
    assert first["input"]["bounds"]["properties"]["crs"].endswith("/32644")  # UTM 44N (78-84 deg E)
    assert 's.dataMask ? s.B04' in first["evalscript"]
    assert first["output"]["responses"][0]["format"]["type"] == "image/tiff"
    assert route.calls[0].request.headers["accept"] == "image/tiff"


@respx.mock
def test_red_and_nir_requests_share_the_same_grid():
    token_route(respx.mock)
    route = respx.post(PROCESS).respond(200, content=tiny_tiff())
    PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["B04", "B08"])
    red, nir = (json.loads(c.request.content) for c in route.calls)
    assert red["input"]["bounds"] == nir["input"]["bounds"]
    assert red["output"]["width"] == nir["output"]["width"]
    assert red["output"]["height"] == nir["output"]["height"]


@respx.mock
def test_request_box_is_on_the_10m_grid_and_covers_the_field():
    token_route(respx.mock)
    route = respx.post(PROCESS).respond(200, content=tiny_tiff())
    PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["B04"])
    body = json.loads(route.calls[0].request.content)
    x0, y0, x1, y1 = body["input"]["bounds"]["bbox"]
    assert all(v % 10 == 0 for v in (x0, y0, x1, y1))
    assert body["output"]["width"] == round((x1 - x0) / 10)
    assert body["output"]["height"] == round((y1 - y0) / 10)
    assert 20 <= body["output"]["width"] <= 80  # ~200 m field + margin, at 10 m/pixel


@respx.mock
def test_true_colour_alias_uses_rgb_evalscript():
    token_route(respx.mock)
    route = respx.post(PROCESS).respond(200, content=tiny_tiff())
    PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["TCI_10m"])
    assert "B03" in json.loads(route.calls[0].request.content)["evalscript"]


def test_unsupported_band_rejected_before_any_request():
    with respx.mock(assert_all_called=False) as mock:
        token_route(mock)
        with pytest.raises(ImageryFetchError, match="Unsupported band"):
            PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ['B04"]); evil("'])
        assert not mock.calls


def test_scene_without_aoi_is_rejected():
    s = scene().model_copy(update={"aoi_geojson": None})
    with pytest.raises(ImageryFetchError, match="no field area"):
        PlanetInsightsImageryProvider(make_settings()).fetch_bands(s, ["B04"])


@respx.mock
def test_download_error_is_translated_with_status():
    token_route(respx.mock)
    respx.post(PROCESS).respond(403, text="no access")
    with pytest.raises(ImageryFetchError, match="HTTP 403") as err:
        PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["B04"])
    assert err.value.upstream_status == 403


# --------------------------------- auth ------------------------------------ #

@respx.mock
def test_token_is_reused_until_it_expires():
    auth = token_route(respx.mock, expires_in=3600)
    respx.post(PROCESS).respond(200, content=tiny_tiff())
    provider = PlanetInsightsImageryProvider(make_settings())
    provider.fetch_bands(scene(), ["B04", "B08"])
    provider.fetch_bands(scene(), ["B04"])
    assert auth.call_count == 1


@respx.mock
def test_expired_token_is_refreshed(monkeypatch):
    auth = token_route(respx.mock, expires_in=30)  # shorter than the safety margin
    respx.post(PROCESS).respond(200, content=tiny_tiff())
    provider = PlanetInsightsImageryProvider(make_settings())
    provider.fetch_bands(scene(), ["B04"])
    provider.fetch_bands(scene(), ["B04"])
    assert auth.call_count == 2


@respx.mock
def test_401_drops_the_token_and_retries_with_a_new_one():
    auth = respx.post(AUTH)
    auth.side_effect = [
        httpx.Response(200, json={"access_token": "old", "expires_in": 3600}),
        httpx.Response(200, json={"access_token": "new", "expires_in": 3600}),
    ]
    process = respx.post(PROCESS)
    process.side_effect = [httpx.Response(401), httpx.Response(200, content=tiny_tiff())]
    out = PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["B04"])
    assert out["B04"]
    assert process.calls[0].request.headers["authorization"] == "Bearer old"
    assert process.calls[1].request.headers["authorization"] == "Bearer new"


def test_missing_credentials_give_a_clear_error():
    provider = PlanetInsightsImageryProvider(make_settings(planet_client_id="", planet_client_secret=""))
    with pytest.raises(ImageryFetchError, match="PLANET_CLIENT_ID"):
        provider.search(AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30)))


@respx.mock
def test_bad_credentials_are_reported_not_retried():
    auth = respx.post(AUTH).respond(401, text="invalid_client")
    with pytest.raises(ImageryFetchError, match="authentication failed") as err:
        PlanetInsightsImageryProvider(make_settings()).search(
            AOI, DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))
        )
    assert err.value.upstream_status == 401
    assert auth.call_count == 1


# ----------------- output is readable by the real NDVI code ------------------ #

@respx.mock
def test_downloaded_bands_feed_the_real_ndvi_code():
    from app.providers.imagery.raster_processing import array_mean_min_max, scene_ndvi_array

    token_route(respx.mock)
    # red reflectance 0.05, NIR 0.45  ->  NDVI = (0.45-0.05)/(0.45+0.05) = 0.8
    respx.post(PROCESS).mock(
        side_effect=lambda request: geotiff_for_request(
            request, 0.05 if "s.dataMask ? s.B04" in json.loads(request.content)["evalscript"] else 0.45
        )
    )
    bands = PlanetInsightsImageryProvider(make_settings()).fetch_bands(scene(), ["B04", "B08"])
    ndvi, _transform, crs = scene_ndvi_array(bands["B04"], bands["B08"], AOI)
    mean, low, high = array_mean_min_max(ndvi)
    assert mean == pytest.approx(0.8, abs=1e-4) and low == pytest.approx(0.8, abs=1e-4)
    assert crs.to_epsg() == 32644


# ------------------------- Planet high-res field photo ----------------------- #

def _png(color: tuple[int, int, int], size=(64, 48)) -> bytes:
    import io

    from PIL import Image

    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, format="PNG")
    return buf.getvalue()


def _photo_builder(**kw):
    from app.providers.imagery.planet_preview import PlanetPreviewBuilder

    return PlanetPreviewBuilder(PlanetInsightsImageryProvider(make_settings()), "abc123", **kw)


@respx.mock
def test_photo_is_requested_from_the_collection_for_the_field_coordinates():
    from app.providers.imagery.planet_preview import PLANET_SOURCE

    token_route(respx.mock)
    route = respx.post(PROCESS).respond(200, content=_png((40, 120, 60)), headers={"content-type": "image/png"})
    preview = _photo_builder(long_side_px=800, lookback_days=10).build(scene(), AOI)

    body = json.loads(route.calls[0].request.content)
    assert body["input"]["data"][0]["type"] == "byoc-abc123"  # prefix added
    assert body["input"]["data"][0]["dataFilter"]["mosaickingOrder"] == "mostRecent"
    min_lon, min_lat, max_lon, max_lat = body["input"]["bounds"]["bbox"]
    assert min_lon < 78.1000 and max_lon > 78.1020 and min_lat < 9.9000 and max_lat > 9.9020  # field + margin
    assert max(body["output"]["width"], body["output"]["height"]) == 800
    assert '"red"' in body["evalscript"] and "10000" in body["evalscript"]

    assert preview is not None and preview.source == PLANET_SOURCE
    assert preview.data_url.startswith("data:image/jpeg;base64,")
    assert preview.bounds == [[min_lat, min_lon], [max_lat, max_lon]]


@respx.mock
def test_photo_with_no_planet_data_returns_none_so_fallback_runs():
    token_route(respx.mock)
    respx.post(PROCESS).respond(200, content=_png((0, 0, 0)))  # Planet draws black where it has nothing
    assert _photo_builder().build(scene(), AOI) is None


@respx.mock
def test_photo_error_returns_none_instead_of_raising():
    token_route(respx.mock)
    respx.post(PROCESS).respond(403, text="no access to collection")
    assert _photo_builder().build(scene(), AOI) is None


def _container_settings(**kw):
    return make_settings(
        reasoning_provider="rule_based_only", notification_provider="noop", job_queue_url="x", **kw
    )


def test_container_uses_planet_photo_first_when_collection_is_set():
    from app.container import build_preview_builder
    from app.providers.imagery.high_res_preview import FallbackPreviewBuilder
    from app.providers.imagery.planet_preview import PlanetPreviewBuilder

    settings = _container_settings(planet_imagery_collection_id="byoc-1")
    builder = build_preview_builder(settings, PlanetInsightsImageryProvider(settings))
    assert isinstance(builder, FallbackPreviewBuilder)
    assert isinstance(builder._primary, PlanetPreviewBuilder)


def test_container_skips_planet_photo_without_a_collection():
    from app.container import build_preview_builder
    from app.providers.imagery.high_res_preview import FallbackPreviewBuilder
    from app.providers.imagery.planet_preview import PlanetPreviewBuilder

    settings = _container_settings()
    builder = build_preview_builder(settings, PlanetInsightsImageryProvider(settings))
    assert isinstance(builder, FallbackPreviewBuilder)
    assert not isinstance(builder._primary, PlanetPreviewBuilder)  # Esri, as before
