"""API tests: real FastAPI routes + real error handler, fake services behind them."""
from __future__ import annotations

import threading
import uuid

import pytest

pytest.importorskip("rasterio")  # app.main imports the full container (needs the geo libs)

from fastapi.testclient import TestClient  # noqa: E402

from app.container import Container  # noqa: E402
from app.jobs.background_runner import BackgroundJobRunner  # noqa: E402
from app.main import app  # noqa: E402
from tests.fakes import InMemoryFieldRepository, InMemoryJobRunRepository  # noqa: E402


class BlockingJob:
    def __init__(self):
        self.release = threading.Event()

    def run(self, request):
        self.release.wait(timeout=5)


@pytest.fixture
def api(sample_field):
    job_runs, job = InMemoryJobRunRepository(), BlockingJob()
    app.state.container = Container(
        fields=InMemoryFieldRepository(sample_field),
        job_runs=job_runs,
        crop_health_job=job,
        job_runner=BackgroundJobRunner(job, job_runs, max_pending=1),
    )
    yield TestClient(app), job, sample_field  # no `with`: lifespan (and its real DB) is skipped
    job.release.set()


def _body(field_id, start="2026-09-01", end="2026-09-30"):
    return {"field_id": str(field_id), "start_date": start, "end_date": end}


def test_start_returns_202_and_job_is_running(api):
    client, _, field = api
    r = client.post("/jobs/crop-health/start", json=_body(field.field_id))

    assert r.status_code == 202
    job_id = r.json()["job_id"]
    assert client.get(f"/jobs/crop-health/jobs/{job_id}").json()["status"] == "running"


def test_unknown_field_is_404(api):
    client, _, _ = api
    r = client.post("/jobs/crop-health/start", json=_body(uuid.uuid4()))
    assert r.status_code == 404


def test_bad_dates_are_422(api):
    client, _, field = api
    r = client.post("/jobs/crop-health/start", json=_body(field.field_id, "2026-09-30", "2026-09-01"))
    assert r.status_code == 422


def test_busy_server_is_429(api):
    client, _, field = api
    assert client.post("/jobs/crop-health/start", json=_body(field.field_id)).status_code == 202
    assert client.post("/jobs/crop-health/start", json=_body(field.field_id)).status_code == 429


def test_unknown_job_is_404(api):
    client, _, _ = api
    assert client.get(f"/jobs/crop-health/jobs/{uuid.uuid4()}").status_code == 404
