from __future__ import annotations

import pytest

from app.domain.geo_utils import bounding_box, flatten_coordinates, polygon_centroid

SQUARE_POLYGON = {
    "type": "Polygon",
    "coordinates": [
        [[78.80, 14.47], [78.81, 14.47], [78.81, 14.48], [78.80, 14.48], [78.80, 14.47]]
    ],
}

MULTI_POLYGON = {
    "type": "MultiPolygon",
    "coordinates": [
        [[[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]],
        [[[2.0, 2.0], [3.0, 2.0], [3.0, 3.0], [2.0, 3.0], [2.0, 2.0]]],
    ],
}


def test_flatten_coordinates_polygon():
    flat = flatten_coordinates(SQUARE_POLYGON["coordinates"])
    assert len(flat) == 5  # closed ring: first point repeated as last
    assert flat[0] == [78.80, 14.47]


def test_flatten_coordinates_multipolygon_handles_extra_nesting():
    flat = flatten_coordinates(MULTI_POLYGON["coordinates"])
    assert len(flat) == 10  # 5 points per ring x 2 polygons


def test_flatten_coordinates_empty_returns_empty_list():
    assert flatten_coordinates([]) == []


def test_polygon_centroid_is_within_bounding_box():
    lon, lat = polygon_centroid(SQUARE_POLYGON)
    assert 78.80 <= lon <= 78.81
    assert 14.47 <= lat <= 14.48


def test_polygon_centroid_empty_geometry_raises():
    with pytest.raises(ValueError):
        polygon_centroid({"coordinates": []})


def test_bounding_box_matches_known_square():
    min_lon, min_lat, max_lon, max_lat = bounding_box(SQUARE_POLYGON)
    assert min_lon == pytest.approx(78.80)
    assert max_lon == pytest.approx(78.81)
    assert min_lat == pytest.approx(14.47)
    assert max_lat == pytest.approx(14.48)


def test_bounding_box_multipolygon_spans_both_polygons():
    min_lon, min_lat, max_lon, max_lat = bounding_box(MULTI_POLYGON)
    assert min_lon == 0.0
    assert max_lon == 3.0
    assert min_lat == 0.0
    assert max_lat == 3.0
