from __future__ import annotations

import threading
import uuid
from datetime import date

import pytest

from app.domain.exceptions import InvalidRequestError, TooManyJobsError
from app.domain.models import CropHealthJobRequest, DateRange, JobStatus
from app.domain.validation import build_date_range
from app.jobs.background_runner import BackgroundJobRunner
from app.providers.registry import ProviderRegistry
from tests.fakes import InMemoryJobRunRepository


# ------------------------------ registry ----------------------------------- #

def test_registry_builds_registered_provider():
    registry: ProviderRegistry[str] = ProviderRegistry("thing")
    registry.register("a", lambda x: f"A-{x}")
    assert registry.create("a", 1) == "A-1"


def test_registry_unknown_name_lists_choices():
    registry: ProviderRegistry[str] = ProviderRegistry("thing")
    registry.register("a", lambda: "A")
    with pytest.raises(ValueError, match="Unknown thing: 'b'.*a"):
        registry.create("b")


# ----------------------------- validation ---------------------------------- #

def test_valid_range():
    r = build_date_range(date(2026, 9, 1), date(2026, 9, 30), max_days=31)
    assert r.end == date(2026, 9, 30)


def test_end_before_start_rejected():
    with pytest.raises(InvalidRequestError):
        build_date_range(date(2026, 9, 30), date(2026, 9, 1), max_days=31)


def test_range_too_long_rejected():
    with pytest.raises(InvalidRequestError, match="31 days or fewer"):
        build_date_range(date(2026, 1, 1), date(2026, 3, 1), max_days=31)


# ------------------------------- runner ------------------------------------ #

class BlockingJob:
    """A fake job that waits until the test lets it finish."""

    def __init__(self):
        self.release = threading.Event()

    def run(self, request):
        self.release.wait(timeout=5)
        return "done"


def _request():
    return CropHealthJobRequest(
        field_id=uuid.uuid4(),
        date_range=DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30)),
    )


def test_runner_rejects_when_busy_then_recovers():
    job, job_runs = BlockingJob(), InMemoryJobRunRepository()
    runner = BackgroundJobRunner(job, job_runs, max_pending=1)

    first = _request()
    future = runner.submit(first)
    assert runner.is_active(first.job_id)

    with pytest.raises(TooManyJobsError):
        runner.submit(_request())

    job.release.set()
    assert future.result(timeout=5) == "done"
    assert not runner.is_active(first.job_id)
    runner.submit(_request()).result(timeout=5)  # capacity is free again


def test_runner_marks_run_failed_on_unexpected_crash():
    class CrashingJob:
        def run(self, request):
            raise RuntimeError("boom")

    job_runs = InMemoryJobRunRepository()
    runner = BackgroundJobRunner(CrashingJob(), job_runs, max_pending=1)
    request = _request()

    with pytest.raises(RuntimeError):
        runner.submit(request).result(timeout=5)

    assert job_runs.completions[-1]["status"] == JobStatus.FAILED
    assert "failed unexpectedly" in job_runs.completions[-1]["error"]
