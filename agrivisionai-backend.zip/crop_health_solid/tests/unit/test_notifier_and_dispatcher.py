from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from app.domain.models import RiskLevel, ScheduleConfig
from app.jobs.farmer_notifier import FarmerNotifier, build_push_payload
from app.jobs.schedule_dispatcher import ScheduleDispatcher, last_full_month, next_due_at
from tests.fakes import (
    InMemoryDeviceTokenRepository,
    InMemoryScheduleRepository,
    RecordingJobQueue,
    RecordingNotifier,
    StubReasoner,
)


def _reasoning(field_id):
    return StubReasoner(risk=RiskLevel.CRITICAL).reason(
        type("I", (), {"field_id": field_id})()
    )


def test_payload_title_and_deep_link(sample_field):
    payload = build_push_payload(sample_field, _reasoning(sample_field.field_id))

    assert payload.title == "Test Field: crop health critical"
    assert payload.deep_link == f"agrivisionai://field/{sample_field.field_id}/crop-health"
    assert payload.data["generated_by"] == "stub"


def test_notifier_returns_none_without_device(sample_field):
    notifier = FarmerNotifier(InMemoryDeviceTokenRepository(None), RecordingNotifier())
    assert notifier.notify(sample_field, _reasoning(sample_field.field_id)) is None


# --------------------------- dispatcher ------------------------------------ #

def test_last_full_month():
    r = last_full_month(date(2026, 10, 13))
    assert (r.start, r.end) == (date(2026, 9, 1), date(2026, 9, 30))


def test_last_full_month_across_new_year():
    r = last_full_month(date(2026, 1, 5))
    assert (r.start, r.end) == (date(2025, 12, 1), date(2025, 12, 31))


def test_next_due_at_follows_cron():
    as_of = datetime(2026, 10, 13, tzinfo=timezone.utc)
    assert next_due_at("0 3 1 * *", as_of) == datetime(2026, 11, 1, 3, 0, tzinfo=timezone.utc)


def _schedule(field_id):
    return ScheduleConfig(field_id=field_id, cron_expression="0 3 1 * *")


def test_dispatcher_queues_each_due_field_and_marks_it():
    a, b = uuid.uuid4(), uuid.uuid4()
    schedules, queue = InMemoryScheduleRepository([_schedule(a), _schedule(b)]), RecordingJobQueue()

    count = ScheduleDispatcher(schedules, queue).run(datetime(2026, 10, 13, tzinfo=timezone.utc))

    assert count == 2
    assert {r.field_id for r in queue.requests} == {a, b}
    assert {fid for fid, _ in schedules.marked} == {a, b}


def test_one_failing_field_does_not_stop_the_others():
    good, bad = uuid.uuid4(), uuid.uuid4()
    schedules = InMemoryScheduleRepository([_schedule(bad), _schedule(good)])
    queue = RecordingJobQueue(fail_for={bad})

    count = ScheduleDispatcher(schedules, queue).run(datetime(2026, 10, 13, tzinfo=timezone.utc))

    assert count == 1
    assert [fid for fid, _ in schedules.marked] == [good]  # the failed one is retried next run
