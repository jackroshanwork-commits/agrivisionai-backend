from __future__ import annotations

from datetime import date

import pytest

from app.domain.exceptions import ImageryFetchError, ScoringError
from app.domain.models import DateRange
from app.jobs.health_score_calculator import HealthScoreCalculator
from tests.fakes import (
    FakeAnalyzer,
    FakeCroplandMask,
    FakeImagery,
    FakePreviewBuilder,
    make_scene,
)

PERIOD = DateRange(start=date(2026, 9, 1), end=date(2026, 9, 30))


def make_calculator(scenes, means, *, preview_fail=False, threshold=20.0):
    imagery = FakeImagery(scenes)
    calc = HealthScoreCalculator(
        imagery=imagery,
        cropland_mask=FakeCroplandMask(),
        scene_analyzer=FakeAnalyzer(means),
        preview_builder=FakePreviewBuilder(fail=preview_fail),
        cloud_cover_threshold_pct=threshold,
        max_workers=1,  # one at a time keeps the fake's "in order" answers predictable
    )
    return calc, imagery


def test_combines_scenes_into_one_score(sample_field):
    calc, _ = make_calculator([make_scene("a", 5), make_scene("b", 10)], [0.4, 0.6])
    result = calc.calculate(sample_field, PERIOD)

    assert result.ndvi_mean == pytest.approx(0.5)
    assert result.ndvi_min == pytest.approx(0.4)
    assert result.ndvi_max == pytest.approx(0.6)
    assert result.cloud_cover_pct == 7.5
    assert result.cropland_mask_source == "fake_mask"
    assert sorted(result.scenes_used) == ["a", "b"]


def test_cloudy_scenes_are_not_downloaded(sample_field):
    calc, imagery = make_calculator([make_scene("clear", 5), make_scene("cloudy", 90)], [0.5])
    calc.calculate(sample_field, PERIOD)

    assert "cloudy" not in imagery.fetched


def test_a_perfectly_clear_scene_is_kept(sample_field):
    """Regression: 0% cloud cover used to be treated as 100% (0.0 is falsy)."""
    calc, imagery = make_calculator([make_scene("zero", 0.0)], [0.5])
    result = calc.calculate(sample_field, PERIOD)

    assert result.scenes_used == ["zero"]


def test_unknown_cloud_cover_counts_as_cloudy(sample_field):
    calc, _ = make_calculator([make_scene("unknown", None)], [0.5])
    with pytest.raises(ScoringError):
        calc.calculate(sample_field, PERIOD)


def test_no_scenes_raises_imagery_error(sample_field):
    calc, _ = make_calculator([], [])
    with pytest.raises(ImageryFetchError):
        calc.calculate(sample_field, PERIOD)


def test_scenes_without_usable_pixels_are_skipped(sample_field):
    calc, _ = make_calculator([make_scene("edge", 5), make_scene("ok", 5)], [None, 0.5])
    result = calc.calculate(sample_field, PERIOD)

    assert result.scenes_used == ["ok"]


def test_all_scenes_unusable_raises(sample_field):
    calc, _ = make_calculator([make_scene("edge", 5)], [None])
    with pytest.raises(ScoringError):
        calc.calculate(sample_field, PERIOD)


def test_failed_photo_never_fails_the_score(sample_field):
    calc, _ = make_calculator([make_scene("a", 5)], [0.5], preview_fail=True)
    result = calc.calculate(sample_field, PERIOD)

    assert result.satellite_images == []
    assert result.satellite_image_data_url is None


def test_photos_are_attached_when_available(sample_field):
    calc, _ = make_calculator([make_scene("a", 5, day=3), make_scene("b", 2, day=20)], [0.4, 0.6])
    result = calc.calculate(sample_field, PERIOD)

    assert len(result.satellite_images) == 2
    # the single "headline" photo is the clearest scene (b: 2% cloud)
    assert result.satellite_image_cloud_cover_pct == 2
