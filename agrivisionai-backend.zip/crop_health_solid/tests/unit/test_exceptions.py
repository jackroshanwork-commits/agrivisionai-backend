from __future__ import annotations

import uuid

from app.domain.exceptions import (
    CropHealthError,
    ImageryFetchError,
    NotificationDeliveryError,
    ReasoningCircuitOpenError,
    ReasoningError,
    StaleDeviceTokenError,
    TierNotEntitledError,
)


def test_subclasses_are_crop_health_error():
    assert issubclass(ImageryFetchError, CropHealthError)
    assert issubclass(ReasoningCircuitOpenError, ReasoningError)
    assert issubclass(StaleDeviceTokenError, NotificationDeliveryError)


def test_to_log_context_never_includes_raw_exception_repr_only_declared_fields():
    field_id = uuid.uuid4()
    job_id = uuid.uuid4()
    exc = ImageryFetchError(
        "Planet Insights timed out", field_id=field_id, job_id=job_id, upstream_status=504, retryable=True
    )
    ctx = exc.to_log_context()
    assert ctx["error_type"] == "ImageryFetchError"
    assert ctx["field_id"] == str(field_id)
    assert ctx["job_id"] == str(job_id)
    assert ctx["upstream_status"] == 504
    assert ctx["retryable"] is True


def test_tier_not_entitled_maps_to_403():
    exc = TierNotEntitledError("not on paid tier")
    assert exc.http_status_code == 403


def test_stale_token_is_not_retryable_by_default():
    exc = StaleDeviceTokenError("token invalid")
    assert exc.retryable is False


def test_circuit_open_error_is_not_retryable():
    exc = ReasoningCircuitOpenError("circuit open")
    assert exc.retryable is False
