from __future__ import annotations

import uuid
from datetime import date, datetime

import pytest

from app.domain.models import (
    FieldBoundary,
    HealthScoreResult,
    SubscriptionTier,
    WeatherForecast,
)

SAMPLE_POLYGON = {
    "type": "Polygon",
    "coordinates": [
        [
            [78.80, 14.47],
            [78.81, 14.47],
            [78.81, 14.48],
            [78.80, 14.48],
            [78.80, 14.47],
        ]
    ],
}


@pytest.fixture
def field_id() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def sample_field(field_id) -> FieldBoundary:
    return FieldBoundary(
        field_id=field_id,
        farmer_id=uuid.uuid4(),
        fpo_id=None,
        name="Test Field",
        geojson_polygon=SAMPLE_POLYGON,
        subscription_tier=SubscriptionTier.KISAN_PLUS,
    )


@pytest.fixture
def sample_health_score(field_id) -> HealthScoreResult:
    return HealthScoreResult(
        field_id=field_id,
        period_start=date(2026, 7, 1),
        period_end=date(2026, 7, 31),
        ndvi_mean=0.55,
        ndvi_min=0.40,
        ndvi_max=0.65,
        health_score=66.67,
        cloud_cover_pct=12.0,
        scenes_used=["scene-1", "scene-2"],
        cropland_mask_source="esa_worldcover_2021",
    )


@pytest.fixture
def calm_forecast(field_id) -> WeatherForecast:
    return WeatherForecast(
        field_id=field_id,
        forecast_days=7,
        daily_rainfall_mm=[2.0, 0.0, 1.5, 0.0, 3.0, 0.0, 0.0],
        daily_avg_temp_c=[32.0, 33.0, 31.0, 34.0, 30.0, 33.0, 32.0],
        adverse_weather_flag=False,
    )
