"""
Tiny in-memory fakes used by the tests.

Because the business logic depends on interfaces (ports), a test can hand it
these simple fakes instead of a real database, satellite API or push service.
No network, no AWS, no mocking library: the tests run in milliseconds.
"""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from app.domain.exceptions import (
    FieldNotFoundError,
    ImageryFetchError,
    JobEnqueueError,
    NotificationDeliveryError,
    ReasoningError,
    WeatherDataError,
)
from app.domain.interfaces import (
    CroplandMaskProvider,
    DeviceTokenRepository,
    FieldRepository,
    ImageryProvider,
    JobQueue,
    JobRunRepository,
    NotificationProvider,
    ReasoningProvider,
    SceneAnalyzer,
    ScenePreviewBuilder,
    ScheduleRepository,
    SoilHealthProvider,
    WeatherForecastProvider,
    WeatherHistoryProvider,
)
from app.domain.models import (
    JobStatus,
    NotificationSendResult,
    ReasoningResult,
    RiskLevel,
    SceneRef,
    ScenePreview,
    ScheduleConfig,
    WeatherForecast,
    WeatherHistory,
)


# ---------------------------- repositories ---------------------------------- #

class InMemoryFieldRepository(FieldRepository):
    def __init__(self, *fields):
        self._fields = {f.field_id: f for f in fields}

    def get_field(self, field_id):
        if field_id not in self._fields:
            raise FieldNotFoundError(f"Field {field_id} not found", field_id=field_id)
        return self._fields[field_id]

    def create_field(self, **kwargs):
        raise NotImplementedError

    def assert_entitled(self, field):
        pass


class InMemoryJobRunRepository(JobRunRepository):
    def __init__(self):
        self.runs: dict[uuid.UUID, dict] = {}
        self.completions: list[dict] = []
        self.last_result_for_field: dict[uuid.UUID, dict] = {}

    def create_job_run(self, job_id, field_id, trigger_source, period_start, period_end):
        self.runs[job_id] = {"job_id": job_id, "field_id": field_id, "status": "running"}

    def complete_job_run(self, job_id, status, result_json, error):
        self.completions.append(
            {"job_id": job_id, "status": status, "result_json": result_json, "error": error}
        )
        if status == JobStatus.SUCCEEDED and result_json and result_json.get("health_score"):
            # Behaves like the real repository: the newest succeeded run wins.
            self.last_result_for_field[uuid.UUID(result_json["field_id"])] = result_json

    def get_last_successful_result(self, field_id):
        return self.last_result_for_field.get(field_id)

    def get_job_run(self, job_id):
        return self.runs.get(job_id)

    def is_duplicate_job(self, field_id, period_start, period_end):
        return False

    def fail_stale_runs(self, reason):
        return 0


class InMemoryDeviceTokenRepository(DeviceTokenRepository):
    def __init__(self, token: str | None = "token-123"):
        self.token = token
        self.deregistered: list[str] = []

    def get_active_device_token(self, farmer_id):
        return self.token

    def deregister_device_token(self, farmer_id, device_token):
        self.deregistered.append(device_token)


class InMemoryScheduleRepository(ScheduleRepository):
    def __init__(self, due: list[ScheduleConfig]):
        self.due = due
        self.marked: list[tuple[uuid.UUID, datetime]] = []

    def get_due_schedules(self, as_of):
        return self.due

    def mark_schedule_run(self, field_id, next_due_at):
        self.marked.append((field_id, next_due_at))


class RecordingJobQueue(JobQueue):
    def __init__(self, fail_for: set[uuid.UUID] | None = None):
        self.requests = []
        self._fail_for = fail_for or set()

    def enqueue(self, request):
        if request.field_id in self._fail_for:
            raise JobEnqueueError("queue down", field_id=request.field_id)
        self.requests.append(request)


# ------------------------------ providers ----------------------------------- #

def make_scene(scene_id: str, cloud: float | None, day: int = 10) -> SceneRef:
    return SceneRef(
        scene_id=scene_id,
        collection="sentinel-2-l2a",
        sensed_at=datetime(2026, 9, day, 5, 0, tzinfo=timezone.utc),
        cloud_cover_pct=cloud,
        provider="fake",
    )


class FakeImagery(ImageryProvider):
    def __init__(self, scenes: list[SceneRef]):
        self.scenes = scenes
        self.fetched: list[str] = []

    def search(self, aoi_geojson, date_range):
        return self.scenes

    def fetch_bands(self, scene, bands):
        self.fetched.append(scene.scene_id)
        return {b: b"raw" for b in bands}


class FailingImagery(ImageryProvider):
    def search(self, aoi_geojson, date_range):
        raise ImageryFetchError("Planet Insights is down")

    def fetch_bands(self, scene, bands):
        raise AssertionError("not reached")


class FakeCroplandMask(CroplandMaskProvider):
    source_name = "fake_mask"

    def get_mask(self, aoi_geojson):
        return b"mask"


class FakeAnalyzer(SceneAnalyzer):
    """Returns a fixed NDVI per call, in order (None = no usable pixels)."""

    def __init__(self, means: list[float | None]):
        self._means = list(means)

    def queue(self, *means: float | None) -> None:
        """Replace the answers it will give next."""
        self._means = list(means)

    def mean_ndvi(self, red_band, nir_band, aoi_geojson, cropland_mask):
        return self._means.pop(0)


class FakePreviewBuilder(ScenePreviewBuilder):
    def __init__(self, fail: bool = False):
        self._fail = fail

    def build(self, scene, aoi_geojson):
        if self._fail:
            raise RuntimeError("no photo today")
        return ScenePreview(data_url=f"data:image/jpeg;base64,{scene.scene_id}", bounds=[[0, 0], [1, 1]])


class FakeWeatherHistory(WeatherHistoryProvider):
    def __init__(self, fail=False):
        self._fail = fail

    def get_history(self, field, date_range):
        if self._fail:
            raise WeatherDataError("NASA POWER down")
        return WeatherHistory(
            field_id=field.field_id,
            period_start=date_range.start,
            period_end=date_range.end,
            rainfall_mm_total=50.0,
            avg_temp_c=30.0,
            avg_soil_moisture_pct=20.0,
        )


class FakeWeatherForecast(WeatherForecastProvider):
    def __init__(self, fail=False):
        self._fail = fail

    def get_forecast(self, field, days=7):
        if self._fail:
            raise WeatherDataError("Open-Meteo down")
        return WeatherForecast(
            field_id=field.field_id,
            forecast_days=days,
            daily_rainfall_mm=[0.0] * days,
            daily_avg_temp_c=[30.0] * days,
            adverse_weather_flag=False,
        )


class FakeSoil(SoilHealthProvider):
    def get_latest(self, field_id):
        return None


class StubReasoner(ReasoningProvider):
    """Returns a result with the chosen risk level, or raises when told to."""

    def __init__(self, risk=RiskLevel.HIGH, should_notify=True, fail=False, name="stub"):
        self._risk, self._notify, self._fail, self._name = risk, should_notify, fail, name
        self.inputs = []

    def reason(self, reasoning_input):
        self.inputs.append(reasoning_input)
        if self._fail:
            raise ReasoningError("LLM down", field_id=reasoning_input.field_id)
        return ReasoningResult(
            field_id=reasoning_input.field_id,
            risk_level=self._risk,
            likely_cause="test cause",
            recommended_action="inspect",
            confidence=0.9,
            message_farmer_language="Please check your field",
            message_language_code="en",
            generated_by=self._name,
            should_notify=self._notify,
        )


class RecordingNotifier(NotificationProvider):
    def __init__(self, stale=False, fail=False):
        self.sent = []
        self._stale, self._fail = stale, fail

    def send_push(self, device_token, payload):
        if self._fail:
            raise NotificationDeliveryError("FCM down", field_id=payload.field_id)
        self.sent.append((device_token, payload))
        return NotificationSendResult(
            farmer_id=payload.farmer_id,
            field_id=payload.field_id,
            delivered=not self._stale,
            stale_token=self._stale,
        )
