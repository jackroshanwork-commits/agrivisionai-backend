# SOLID guide for this project (beginner friendly)

This guide explains **what changed and why**, using the real files in this
project. You don't need to know SOLID already.

> **One-sentence summary:** every class now does *one* job, gets the tools it
> needs from the outside instead of creating them, and talks to *small
> interfaces* instead of concrete tools. That makes the code easy to read, test
> and change.

---

## 1. The map: where does what live?

```
app/
  domain/        Rules and shapes. No internet, no database, no AWS.
    interfaces.py   "Ports": lists of what a tool must be able to do
    models/         Data shapes (FieldBoundary, HealthScoreResult, ...)
    scoring.py, reasoning_rules.py   Pure maths / decision rules
    validation.py   Request checks (date range)

  jobs/          Use cases: "what happens when a job runs"
    crop_health_job.py        The story, step by step
    health_score_calculator.py  Satellite images -> score
    reasoning_context.py      Collects weather + soil + previous score
    farmer_notifier.py        Sends the push notification
    schedule_dispatcher.py    Queues the jobs that are due today
    background_runner.py      Runs jobs on a thread for the API
    score_history.py          "What was the last good score?"

  providers/     Adapters: the real tools (Planet Insights, Groq, FCM, Postgres, SQS ...)
    factories.py   Which providers exist (name -> class)
    registry.py    The lookup table behind it

  api/           HTTP only: validate input, call a service, return JSON
  lambda_handlers/  AWS entry points (thin)
  container.py   The ONE file that picks real classes and connects them
```

**Rule of thumb for reading the code:** arrows only point *inward*.

```
api / lambda_handlers  ->  jobs  ->  domain (interfaces)  <-  providers
                                                     (providers implement them)
```

`jobs` never imports `providers`. `domain` imports nothing from the others.

---

## 2. S — Single Responsibility

> *A class should have one reason to change.*

**Before.** `run_crop_health_job()` was a 563-line file with one huge function that loaded the
field, computed the score, saved it, fetched weather, fetched soil, called the
LLM, handled the fallback, sent notifications, and logged everything.
`routers/jobs.py` mixed HTTP with thread pools and a global counter.
`scoring_pipeline.py` searched, filtered, downloaded, calculated, built photos
and built the result in one function.

**Now.** Each of those is its own small class:

| Job | Class |
|---|---|
| Decide the order of steps | `CropHealthJob` |
| Imagery -> score | `HealthScoreCalculator` |
| Gather weather / soil | `ReasoningContextGatherer` |
| Send the push | `FarmerNotifier` |
| Run in the background, limit load | `BackgroundJobRunner` |
| Turn errors into HTTP responses | one handler in `main.py` |

**How to spot a violation:** if you describe a class with the word "and"
("it loads the field *and* sends notifications *and* ..."), split it.

---

## 3. O — Open/Closed

> *Add new behaviour by adding code, not by editing old code.*

**Before.** `providers_container.py` had `if/elif` ladders. A new imagery
provider meant editing that function.

**Now.** Providers are *registered*:

```python
# app/providers/factories.py
imagery_registry.register("planet_insights", _planet_insights)
imagery_registry.register("aws_open_data", _aws_open_data)
```

### Try it: add a new notification provider

1. Write the class (new file, touches nothing else):

```python
# app/providers/notification/email_provider.py
from app.domain.interfaces import NotificationProvider

class EmailNotificationProvider(NotificationProvider):
    def send_push(self, device_token, payload):
        ...  # send the email, return a NotificationSendResult
```

2. Register it (one line in `factories.py`):

```python
notification_registry.register("email", lambda settings: EmailNotificationProvider())
```

3. Set `NOTIFICATION_PROVIDER=email`. Done. `CropHealthJob`, the API and the
   tests are untouched.

A typo like `REASONING_PROVIDER=gemni` now stops the app at startup with a
message that lists the valid names.

---

## 4. L — Liskov Substitution

> *Anything that implements an interface must be usable wherever that
> interface is expected, without surprises.*

Every provider follows the "contract" written in its interface docstring, for
example:

* `FieldRepository.get_field` **raises** `FieldNotFoundError`; it never
  returns `None`.
* `NotificationProvider.send_push` returns `stale_token=True` for a dead
  token instead of raising.

The best example is `FallbackReasoningProvider`. It *is* a `ReasoningProvider`
that wraps two others ("try Groq, else rules"). `CropHealthJob` just calls
`reasoner.reason(...)` and has no idea a fallback exists. Previously the job
contained the try/except and a special concrete `reasoning_fallback` field.

**How to spot a violation:** code like `if isinstance(x, SomeConcreteClass)`
or "this implementation can't really do what the interface says".

---

## 5. I — Interface Segregation

> *Don't force code to depend on things it doesn't use.*

**Before.** One `CropHealthRepository` facade had 14 methods (fields,
schedules, job runs, tokens, soil) and one `ProvidersContainer` held
everything. The notification code could see (and call) job-run deletion.

**Now.** Small interfaces, each with only what one kind of client needs:

* `FieldRepository`, `JobRunRepository`, `DeviceTokenRepository`,
  `ScheduleRepository`, `JobQueue`
* `FarmerNotifier` receives **only** a `DeviceTokenRepository` and a
  `NotificationProvider`.
* The dispatcher Lambda builds **only** the schedule table and the queue. It no
  longer creates the imagery, LLM and push clients it never uses.

---

## 6. D — Dependency Inversion

> *High-level code should depend on interfaces, not on concrete tools.*

**Before.** `jobs/` imported the DI container, `rasterio` helper modules from
`providers/`, and even called `boto3.client("sqs")` directly.

**Now.** Every class receives what it needs through `__init__`:

```python
class FarmerNotifier:
    def __init__(self, device_tokens: DeviceTokenRepository,
                 provider: NotificationProvider): ...
```

The *only* file that creates real classes is `app/container.py`. Business code
never reads `Settings` either; it gets plain values (e.g.
`cloud_cover_threshold_pct`).

**The big payoff is testing.** Because the job only needs interfaces, the
tests give it tiny in-memory fakes (`tests/fakes.py`). No database, no
network, no mocking library, and 84 tests run in about 3 seconds.

---

## 7. Cheat sheet

| Principle | Ask yourself | Where to see it |
|---|---|---|
| **S**ingle responsibility | Can I describe this class without "and"? | `jobs/*.py` |
| **O**pen/closed | Can I add a feature without editing old code? | `providers/factories.py` |
| **L**iskov | Can I swap implementations safely? | `FallbackReasoningProvider` |
| **I**nterface segregation | Does it only get what it uses? | `domain/interfaces.py` |
| **D**ependency inversion | Does it ask for an interface, not a tool? | `container.py` |

---

## 8. Behaviour changes (please read)

The refactor keeps behaviour the same **except** these deliberate fixes, each
covered by a test:

1. **Score comparison bug.** The "previous score" was read *after* the new
   score had been saved, so every run was compared with itself (always 0%
   change) and drop alerts could never fire. It is now read *before* saving.
   *(test: `test_previous_score_is_the_OLD_one...`)*
2. **0% cloud scenes were thrown away.** `cloud_cover_pct or 100.0` treats
   `0.0` as missing. Now only `None` counts as unknown.
   *(test: `test_a_perfectly_clear_scene_is_kept`)*
3. **Missing settings.** The code read `fcm_service_account_json`,
   `sns_platform_application_arn`, `job_queue_url`, `tiles_bucket`,
   `reports_bucket` and `tiles_cloudfront_domain`, but `Settings` didn't define
   them, which would crash on startup. They now exist. The default
   `notification_provider` is `noop` (what the old docstrings said it was), so
   the app boots without push credentials.
4. **One place for HTTP errors.** Routers no longer repeat try/except; the
   handler in `main.py` maps `CropHealthError.http_status_code` to the response.

## 9. Things I noticed but did NOT change

These are product decisions, so I left them for you:

* **Scheduled / event runs are never saved.** Only the API calls
  `create_job_run`; `complete_job_run` silently does nothing if the row is
  missing, so worker runs leave no history (and no "previous score" for the
  next month). Fix: call `job_runs.create_job_run(...)` at the top of the
  worker handler.
* **The tier gate is never enforced.** `FieldRepository.assert_entitled()`
  exists but nothing calls it, so free-tier fields can run jobs.
* `OutputsStorage` (S3 tile upload) is not built by the container because
  nothing uses it yet (tile output is still a stub, see the README).
* `google-genai` in `requirements.txt` looks unused now that Groq is the LLM.
